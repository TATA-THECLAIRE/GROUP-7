class ApiConfig {
  // Production deployment URL only
  static const String BASE_URL = 'https://attendease-backend-x31p.onrender.com';
  
  // API endpoints - all include /api prefix as required by backend
  static const String healthEndpoint = '/api/health';
  
  // Authentication endpoints
  static const String authEndpoint = '/api/auth';
  static const String registerEndpoint = '/api/auth/register';
  static const String loginEndpoint = '/api/auth/login';
  static const String logoutEndpoint = '/api/auth/logout';
  static const String logoutAllEndpoint = '/api/auth/logout-all';
  static const String verify2FAEndpoint = '/api/auth/verify-2fa';
  static const String send2FAEndpoint = '/api/auth/send-2fa';
  static const String validateEmailEndpoint = '/api/auth/validate-email';
  static const String refreshTokenEndpoint = '/api/auth/refresh';
  static const String changePasswordEndpoint = '/api/auth/change-password';
  static const String resetPasswordEndpoint = '/api/auth/reset-password';
  static const String forgotPasswordEndpoint = '/api/auth/forgot-password';
  
  // Session management endpoints
  static const String sessionsEndpoint = '/api/auth/sessions';
  static const String revokeSessionEndpoint = '/api/auth/sessions'; // + /{session_id}
  static const String cleanupSessionsEndpoint = '/api/auth/sessions/cleanup';
  
  // User management endpoints
  static const String usersEndpoint = '/api/users';
  static const String studentsEndpoint = '/api/students';
  static const String lecturersEndpoint = '/api/lecturers';
  static const String adminsEndpoint = '/api/admins';
  static const String profileEndpoint = '/api/users/profile';
  static const String updateProfileEndpoint = '/api/users/profile';
  
  // Academic structure endpoints
  static const String departmentsEndpoint = '/api/departments';
  static const String coursesEndpoint = '/api/courses';
  static const String semestersEndpoint = '/api/semesters';
  static const String academicYearsEndpoint = '/api/academic-years';
  
  // Course management endpoints
  static const String courseAssignmentsEndpoint = '/api/course-assignments';
  static const String studentEnrollmentsEndpoint = '/api/student-enrollments';
  static const String courseStudentsEndpoint = '/api/courses'; // + /{course_id}/students
  static const String studentCoursesEndpoint = '/api/students'; // + /{student_id}/courses
  
  // Attendance system endpoints
  static const String attendanceEndpoint = '/api/attendance-records';
  static const String attendanceSessionsEndpoint = '/api/attendance-sessions';
  static const String startSessionEndpoint = '/api/attendance-sessions/start';
  static const String endSessionEndpoint = '/api/attendance-sessions/end';
  static const String checkInEndpoint = '/api/attendance-records/check-in';
  static const String attendanceHistoryEndpoint = '/api/attendance-records/history';
  
  // Geofencing endpoints
  static const String geofenceAreasEndpoint = '/api/geofence-areas';
  static const String validateLocationEndpoint = '/api/geofence-areas/validate';
  
  // Notification endpoints
  static const String notificationsEndpoint = '/api/notifications';
  static const String markNotificationReadEndpoint = '/api/notifications'; // + /{notification_id}/read
  static const String markAllNotificationsReadEndpoint = '/api/notifications/mark-all-read';
  
  // Dashboard and reporting endpoints
  static const String dashboardEndpoint = '/api/dashboard';
  static const String reportsEndpoint = '/api/reports';
  static const String attendanceReportsEndpoint = '/api/reports/attendance';
  static const String studentReportsEndpoint = '/api/reports/students';
  static const String lecturerReportsEndpoint = '/api/reports/lecturers';
  static const String courseReportsEndpoint = '/api/reports/courses';
  
  // System administration endpoints
  static const String systemSettingsEndpoint = '/api/system-settings';
  static const String auditLogsEndpoint = '/api/audit-logs';
  static const String systemHealthEndpoint = '/api/system/health';
  
  // UB FET specific endpoints
  static const String ubSetupEndpoint = '/api/ub-setup';
  static const String validateMatricleEndpoint = '/api/ub-setup/matricle/validate';
  static const String ubDepartmentsEndpoint = '/api/ub-setup/departments';
  static const String ubCoursesEndpoint = '/api/ub-setup/courses';
  
  // File upload endpoints
  static const String uploadProfileImageEndpoint = '/api/users/profile/image';
  static const String uploadStudentListEndpoint = '/api/courses/upload-students';
  static const String downloadTemplateEndpoint = '/api/templates/student-upload';
  
  // Timeouts
  static const Duration connectTimeout = Duration(seconds: 30);
  static const Duration receiveTimeout = Duration(seconds: 30);
  static const Duration sendTimeout = Duration(seconds: 30);
  
  // Request headers
  static const String authHeaderKey = 'Authorization';
  static const String sessionHeaderKey = 'X-Session-Token';
  static const String contentTypeKey = 'Content-Type';
  static const String acceptKey = 'Accept';
  static const String userAgentKey = 'User-Agent';
  
  // Content types
  static const String jsonContentType = 'application/json';
  static const String formDataContentType = 'multipart/form-data';
  static const String urlEncodedContentType = 'application/x-www-form-urlencoded';
  
  // Build full URL for endpoint
  static String buildUrl(String endpoint) {
    return '$BASE_URL$endpoint';
  }
  
  // Build URL with path parameters
  static String buildUrlWithParams(String endpoint, Map<String, dynamic> params) {
    String url = '$BASE_URL$endpoint';
    params.forEach((key, value) {
      url = url.replaceAll('{$key}', value.toString());
    });
    return url;
  }
  
  // Build URL with query parameters
  static String buildUrlWithQuery(String endpoint, Map<String, dynamic> queryParams) {
    String url = '$BASE_URL$endpoint';
    if (queryParams.isNotEmpty) {
      final queryString = queryParams.entries
          .map((e) => '${Uri.encodeComponent(e.key)}=${Uri.encodeComponent(e.value.toString())}')
          .join('&');
      url += '?$queryString';
    }
    return url;
  }
  
  // Get session-specific endpoints
  static String getRevokeSessionUrl(String sessionId) {
    return buildUrl('$revokeSessionEndpoint/$sessionId');
  }
  
  static String getCourseStudentsUrl(String courseId) {
    return buildUrl('$courseStudentsEndpoint/$courseId/students');
  }
  
  static String getStudentCoursesUrl(String studentId) {
    return buildUrl('$studentCoursesEndpoint/$studentId/courses');
  }
  
  static String getMarkNotificationReadUrl(String notificationId) {
    return buildUrl('$markNotificationReadEndpoint/$notificationId/read');
  }
  
  static String getEndSessionUrl(String sessionId) {
    return buildUrl('$endSessionEndpoint/$sessionId');
  }
  
  // Get all available endpoints for debugging
  static Map<String, String> getAllEndpoints() {
    return {
      // Health and system
      'health': healthEndpoint,
      'system_health': systemHealthEndpoint,
      
      // Authentication
      'auth': authEndpoint,
      'register': registerEndpoint,
      'login': loginEndpoint,
      'logout': logoutEndpoint,
      'logout_all': logoutAllEndpoint,
      'validate_email': validateEmailEndpoint,
      'validate_matricle': validateMatricleEndpoint,
      'verify_2fa': verify2FAEndpoint,
      'refresh_token': refreshTokenEndpoint,
      'change_password': changePasswordEndpoint,
      'reset_password': resetPasswordEndpoint,
      'forgot_password': forgotPasswordEndpoint,
      
      // Session management
      'sessions': sessionsEndpoint,
      'revoke_session': revokeSessionEndpoint,
      'cleanup_sessions': cleanupSessionsEndpoint,
      
      // User management
      'users': usersEndpoint,
      'students': studentsEndpoint,
      'lecturers': lecturersEndpoint,
      'admins': adminsEndpoint,
      'profile': profileEndpoint,
      'update_profile': updateProfileEndpoint,
      
      // Academic structure
      'departments': departmentsEndpoint,
      'courses': coursesEndpoint,
      'semesters': semestersEndpoint,
      'academic_years': academicYearsEndpoint,
      
      // Course management
      'course_assignments': courseAssignmentsEndpoint,
      'student_enrollments': studentEnrollmentsEndpoint,
      'course_students': courseStudentsEndpoint,
      'student_courses': studentCoursesEndpoint,
      
      // Attendance system
      'attendance': attendanceEndpoint,
      'attendance_sessions': attendanceSessionsEndpoint,
      'start_session': startSessionEndpoint,
      'end_session': endSessionEndpoint,
      'check_in': checkInEndpoint,
      'attendance_history': attendanceHistoryEndpoint,
      
      // Geofencing
      'geofence_areas': geofenceAreasEndpoint,
      'validate_location': validateLocationEndpoint,
      
      // Notifications
      'notifications': notificationsEndpoint,
      'mark_notification_read': markNotificationReadEndpoint,
      'mark_all_notifications_read': markAllNotificationsReadEndpoint,
      
      // Dashboard and reports
      'dashboard': dashboardEndpoint,
      'reports': reportsEndpoint,
      'attendance_reports': attendanceReportsEndpoint,
      'student_reports': studentReportsEndpoint,
      'lecturer_reports': lecturerReportsEndpoint,
      'course_reports': courseReportsEndpoint,
      
      // System administration
      'system_settings': systemSettingsEndpoint,
      'audit_logs': auditLogsEndpoint,
      
      // UB FET specific
      'ub_setup': ubSetupEndpoint,
      'ub_departments': ubDepartmentsEndpoint,
      'ub_courses': ubCoursesEndpoint,
      
      // File uploads
      'upload_profile_image': uploadProfileImageEndpoint,
      'upload_student_list': uploadStudentListEndpoint,
      'download_template': downloadTemplateEndpoint,
    };
  }
  
  // Get authentication endpoints
  static Map<String, String> getAuthEndpoints() {
    return {
      'register': registerEndpoint,
      'login': loginEndpoint,
      'logout': logoutEndpoint,
      'logout_all': logoutAllEndpoint,
      'verify_2fa': verify2FAEndpoint,
      'refresh_token': refreshTokenEndpoint,
      'change_password': changePasswordEndpoint,
      'reset_password': resetPasswordEndpoint,
      'forgot_password': forgotPasswordEndpoint,
      'sessions': sessionsEndpoint,
      'cleanup_sessions': cleanupSessionsEndpoint,
    };
  }
  
  // Get user management endpoints
  static Map<String, String> getUserEndpoints() {
    return {
      'users': usersEndpoint,
      'students': studentsEndpoint,
      'lecturers': lecturersEndpoint,
      'admins': adminsEndpoint,
      'profile': profileEndpoint,
      'update_profile': updateProfileEndpoint,
      'upload_profile_image': uploadProfileImageEndpoint,
    };
  }
  
  // Get attendance endpoints
  static Map<String, String> getAttendanceEndpoints() {
    return {
      'attendance_records': attendanceEndpoint,
      'attendance_sessions': attendanceSessionsEndpoint,
      'start_session': startSessionEndpoint,
      'end_session': endSessionEndpoint,
      'check_in': checkInEndpoint,
      'attendance_history': attendanceHistoryEndpoint,
    };
  }
  
  // Validate endpoint exists
  static bool isValidEndpoint(String endpoint) {
    return getAllEndpoints().containsValue(endpoint);
  }
  
  // Get endpoint category
  static String getEndpointCategory(String endpoint) {
    if (getAuthEndpoints().containsValue(endpoint)) return 'Authentication';
    if (getUserEndpoints().containsValue(endpoint)) return 'User Management';
    if (getAttendanceEndpoints().containsValue(endpoint)) return 'Attendance';
    if (endpoint.contains('/reports')) return 'Reports';
    if (endpoint.contains('/dashboard')) return 'Dashboard';
    if (endpoint.contains('/notifications')) return 'Notifications';
    if (endpoint.contains('/geofence')) return 'Geofencing';
    if (endpoint.contains('/courses') || endpoint.contains('/departments')) return 'Academic';
    if (endpoint.contains('/system')) return 'System';
    return 'General';
  }
}
