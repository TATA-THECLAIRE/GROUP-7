class FeatureFlags {
  // Integration phases - Phase 1: Authentication enabled
  static const bool USE_REAL_API = true;
  static const bool ENABLE_AUTH_API = true;  // ✅ Enable real authentication
  static const bool ENABLE_READ_OPERATIONS = false;
  static const bool ENABLE_WRITE_OPERATIONS = false;
  
  // Features
  static const bool ENABLE_FACE_RECOGNITION = false;
  static const bool ENABLE_GEOLOCATION = false;
  static const bool ENABLE_OFFLINE_MODE = true;
  
  // Fallback options
  static const bool USE_MOCK_DATA_FALLBACK = true;
  
  // Debug options
  static const bool ENABLE_API_LOGGING = true;
  static const bool ENABLE_ERROR_REPORTING = false;
  
  // Helper getters
  static bool get isDebugMode {
    bool inDebugMode = false;
    assert(inDebugMode = true);
    return inDebugMode;
  }
  
  static String get currentPhase {
    if (!USE_REAL_API) return 'Pre-Integration (Mock Data)';
    if (!ENABLE_AUTH_API) return 'Phase 0 (Mock Testing)';
    if (!ENABLE_READ_OPERATIONS) return 'Phase 1 (Authentication)';
    if (!ENABLE_WRITE_OPERATIONS) return 'Phase 2 (Read Operations)';
    return 'Phase 3 (Full Integration)';
  }
}
