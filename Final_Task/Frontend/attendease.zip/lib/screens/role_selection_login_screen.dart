import 'package:flutter/material.dart';
import '../models/user_role.dart';
import '../widgets/app_bar_widget.dart';
import 'student_login_screen.dart';
import 'lecturer_login_screen.dart';
import 'admin_login_screen.dart';
import '../utils/adaptive_screen_manager.dart';

class RoleSelectionLoginScreen extends StatefulWidget {
  const RoleSelectionLoginScreen({super.key});

  @override
  State<RoleSelectionLoginScreen> createState() => _RoleSelectionLoginScreenState();
}

class _RoleSelectionLoginScreenState extends State<RoleSelectionLoginScreen> {
  UserRole? selectedRole;

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    
    return Scaffold(
      appBar: const CustomAppBar(),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF667EEA), Color(0xFF764BA2)],
          ),
        ),
        child: Container(
          color: Colors.black.withAlpha(179), // 0.7 * 255 = ~179
          child: Center(
            child: Container(
              margin: adaptive.responsiveMargin(all: 20),
              padding: adaptive.responsivePadding(all: 20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: adaptive.responsiveBorderRadius(20),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Select Login Type',
                    style: TextStyle(
                      fontSize: adaptive.sp(18),
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFF333333),
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: adaptive.scale(20)),
                  ...UserRole.values.map((role) => _buildRoleOption(role, adaptive)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRoleOption(UserRole role, AdaptiveScreenManager adaptive) {
    final isSelected = selectedRole == role;
    
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedRole = role;
        });
        
        // Navigate to appropriate login screen after a short delay
        Future.delayed(const Duration(milliseconds: 300), () {
          if (mounted) {
            Widget loginScreen;
            switch (role) {
              case UserRole.student:
                loginScreen = const StudentLoginScreen();
                break;
              case UserRole.lecturer:
                loginScreen = const LecturerLoginScreen();
                break;
              case UserRole.admin:
                loginScreen = const AdminLoginScreen();
                break;
            }
            
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => loginScreen),
            );
          }
        });
      },
      child: Container(
        width: double.infinity,
        margin: adaptive.responsiveMargin(bottom: 10),
        padding: adaptive.responsivePadding(all: 15),
        decoration: BoxDecoration(
          color: isSelected ? role.primaryColor : const Color(0xFFF8F9FA),
          border: Border.all(
            color: isSelected ? role.primaryColor : const Color(0xFFE9ECEF),
            width: 2,
          ),
          borderRadius: adaptive.responsiveBorderRadius(12),
        ),
        child: Column(
          children: [
            Text(
              role.emoji,
              style: TextStyle(fontSize: adaptive.sp(20)),
            ),
            SizedBox(height: adaptive.scale(5)),
            Text(
              role.displayName,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: isSelected ? Colors.white : Colors.black,
                fontSize: adaptive.sp(16),
              ),
            ),
            Text(
              role.description,
              style: TextStyle(
                fontSize: adaptive.sp(12),
                color: isSelected ? Colors.white.withAlpha(204) : const Color(0xFF666666), // 0.8 * 255 = ~204
              ),
            ),
          ],
        ),
      ),
    );
  }
}
