import 'package:flutter/material.dart';
import '../models/user_role.dart';
import '../widgets/custom_button.dart';
import 'homepage_screen.dart';
import '../widgets/app_bar_widget.dart';
import '../services/user_data_service.dart';
import 'student/student_interface_screen.dart';

class DashboardScreen extends StatefulWidget {
  final UserRole role;
  final bool isFromSignup;

  const DashboardScreen({
    super.key, 
    required this.role,
    this.isFromSignup = false,
  });

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  @override
  void initState() {
    super.initState();
    // Redirect to appropriate dashboard based on role
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (widget.role == UserRole.student) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => StudentInterfaceScreen(
              role: widget.role,
              isFromSignup: widget.isFromSignup,
            ),
          ),
        );
      } else {
        _showWelcomeMessage();
      }
    });
  }

  Future<void> _showWelcomeMessage() async {
    final userData = await UserDataService.getCurrentUser();
    String welcomeMessage = 'Welcome to your ${widget.role.displayName.toLowerCase()} dashboard! You\'re all set to get started.';
    
    if (userData != null) {
      welcomeMessage = 'Welcome back, ${userData.fullName}! You\'re logged in as ${widget.role.displayName.toLowerCase()}.';
    }
    
    if (mounted && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(welcomeMessage),
          backgroundColor: const Color(0xFF4CAF50),
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // This screen is only shown for non-student roles
    if (widget.role == UserRole.student) {
      return const SizedBox.shrink();
    }

    return Scaffold(
      appBar: const CustomAppBar(),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF667EEA), Color(0xFF764BA2)],
          ),
        ),
        child: Padding(
          padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.05),
          child: Column(
            children: [
              const SizedBox(height: 20),
              Center(
                child: Column(
                  children: [
                    Text(
                      _getDashboardTitle(),
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      _getDashboardSubtitle(),
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 80,
                        height: 80,
                        decoration: const BoxDecoration(
                          color: Color(0xFF4CAF50),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.person,
                          color: Colors.white,
                          size: 32,
                        ),
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        'Successfully Logged In!',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        'You are now viewing your personalized dashboard',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.white70,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 30),
                      CustomButton(
                        text: 'Logout',
                        backgroundColor: const Color(0xFFF44336),
                        onPressed: () async {
                          // Clear current user session but keep saved credentials
                          await UserDataService.setCurrentUserRole(UserRole.student); // Reset to default
                          
                          if (mounted && context.mounted) {
                            Navigator.pushAndRemoveUntil(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const HomepageScreen(),
                              ),
                              (route) => false,
                            );
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _getDashboardTitle() {
    switch (widget.role) {
      case UserRole.student:
        return 'Student Dashboard';
      case UserRole.lecturer:
        return 'Lecturer Dashboard';
      case UserRole.admin:
        return 'Admin Dashboard';
    }
  }

  String _getDashboardSubtitle() {
    switch (widget.role) {
      case UserRole.student:
        return 'View your attendance records';
      case UserRole.lecturer:
        return 'Manage class attendance';
      case UserRole.admin:
        return 'System administration';
    }
  }
}
