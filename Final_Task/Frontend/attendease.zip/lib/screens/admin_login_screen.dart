import 'package:flutter/material.dart';
import '../models/user_role.dart';
import '../widgets/custom_button.dart';
import '../widgets/custom_text_field.dart';
import '../widgets/app_bar_widget.dart';
import '../services/user_data_service.dart';
import 'admin/admin_interface_screen.dart';
import '../utils/adaptive_screen_manager.dart';
import 'role_selection_login_screen.dart';
import '../services/auth/auth_service.dart';

class AdminLoginScreen extends StatefulWidget {
  final bool isFromSignup;

  const AdminLoginScreen({
    super.key, 
    this.isFromSignup = false,
  });

  @override
  State<AdminLoginScreen> createState() => _AdminLoginScreenState();
}

class _AdminLoginScreenState extends State<AdminLoginScreen> {
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;
  bool _autoFilled = false;
  bool _autoLoginInProgress = false;
  bool _showCredentialPopup = false;

  final _adminIdController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.isFromSignup) {
      _handleSignupFlow();
    } else {
      _loadUserData();
    }
  }

  Future<void> _handleSignupFlow() async {
    final userData = await UserDataService.getUser(UserRole.admin);
    if (userData != null) {
      setState(() {
        _adminIdController.text = userData.id;
        _passwordController.text = userData.password;
        _autoFilled = true;
        _showCredentialPopup = true;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Admin account created successfully! Please sign in to continue.'),
            backgroundColor: Color(0xFF4CAF50),
            duration: Duration(seconds: 3),
          ),
        );
      }

      await Future.delayed(const Duration(seconds: 1));
      if (mounted && _showCredentialPopup) {
        _showCredentialSavingPopup();
      }
    }
  }

  Future<void> _showCredentialSavingPopup() async {
    setState(() {
      _showCredentialPopup = false;
    });

    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        final adaptive = context.adaptive;
        return Align(
          alignment: Alignment.topRight,
          child: Container(
            margin: adaptive.responsiveMargin(top: 100, right: 20),
            width: adaptive.wp(85),
            child: Material(
              borderRadius: adaptive.responsiveBorderRadius(15),
              elevation: 8,
              child: Container(
                padding: adaptive.responsivePadding(all: 20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: adaptive.responsiveBorderRadius(15),
                  border: Border.all(color: UserRole.admin.primaryColor, width: 2),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: adaptive.responsivePadding(all: 8),
                          decoration: BoxDecoration(
                            color: UserRole.admin.primaryColor.withValues(alpha: 0.1),
                            borderRadius: adaptive.responsiveBorderRadius(8),
                          ),
                          child: Icon(
                            Icons.save,
                            color: UserRole.admin.primaryColor,
                            size: adaptive.responsiveIconSize(20),
                          ),
                        ),
                        SizedBox(width: adaptive.scale(10)),
                        Expanded(
                          child: Text(
                            'Save Admin Login?',
                            style: TextStyle(
                              fontSize: adaptive.sp(16),
                              fontWeight: FontWeight.bold,
                              color: const Color(0xFF333333),
                            ),
                          ),
                        ),
                        IconButton(
                          onPressed: () => Navigator.of(context).pop(false),
                          icon: Icon(Icons.close, size: adaptive.responsiveIconSize(20)),
                          padding: EdgeInsets.zero,
                          constraints: const BoxConstraints(),
                        ),
                      ],
                    ),
                    SizedBox(height: adaptive.scale(15)),
                    Text(
                      'Save your admin credentials for quick access next time?',
                      style: TextStyle(
                        fontSize: adaptive.sp(14),
                        color: const Color(0xFF666666),
                      ),
                    ),
                    SizedBox(height: adaptive.scale(20)),
                    Row(
                      children: [
                        Expanded(
                          child: TextButton(
                            onPressed: () => Navigator.of(context).pop(false),
                            style: TextButton.styleFrom(
                              padding: adaptive.responsivePadding(vertical: 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: adaptive.responsiveBorderRadius(8),
                                side: const BorderSide(color: Color(0xFFDDDDDD)),
                              ),
                            ),
                            child: Text(
                              'No, Thanks',
                              style: TextStyle(
                                color: const Color(0xFF666666),
                                fontSize: adaptive.sp(14),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(width: adaptive.scale(10)),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () => Navigator.of(context).pop(true),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: UserRole.admin.primaryColor,
                              foregroundColor: Colors.white,
                              padding: adaptive.responsivePadding(vertical: 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: adaptive.responsiveBorderRadius(8),
                              ),
                            ),
                            child: Text(
                              'Yes, Save',
                              style: TextStyle(fontSize: adaptive.sp(14)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
    
    if (result == true) {
      await UserDataService.setAutoLoginEnabled(true);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Admin login saved! Auto-login enabled.'),
            backgroundColor: Color(0xFF4CAF50),
          ),
        );
      }
    }
  }

  Future<void> _loadUserData() async {
    final userData = await UserDataService.getUser(UserRole.admin);
    final autoLoginEnabled = await UserDataService.isAutoLoginEnabled();
    final currentRole = await UserDataService.getCurrentUserRole();
    
    if (userData != null && currentRole == UserRole.admin && autoLoginEnabled) {
      setState(() {
        _adminIdController.text = userData.id;
        _passwordController.text = userData.password;
        _autoFilled = true;
        _autoLoginInProgress = true;
      });

      await Future.delayed(const Duration(seconds: 2));
      
      if (mounted) {
        _handleLogin(autoLogin: true);
      }
    } else if (userData != null) {
      setState(() {
        _adminIdController.text = userData.id;
        _passwordController.text = userData.password;
        _autoFilled = true;
      });
    }
  }

  @override
  void dispose() {
    _adminIdController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    
    return Scaffold(
      appBar: const CustomAppBar(),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF667EEA), Color(0xFF764BA2)],
          ),
        ),
        child: SingleChildScrollView(
          padding: adaptive.responsivePadding(all: 20),
          child: Column(
            children: [
              SizedBox(height: adaptive.scale(20)),
              Center(
                child: Column(
                  children: [
                    Container(
                      padding: adaptive.responsivePadding(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: UserRole.admin.lightColor,
                        borderRadius: adaptive.responsiveBorderRadius(20),
                      ),
                      child: Text(
                        'ADMIN LOGIN',
                        style: TextStyle(
                          color: UserRole.admin.primaryColor,
                          fontSize: adaptive.sp(12),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    SizedBox(height: adaptive.scale(10)),
                    Text(
                      widget.isFromSignup ? 'Welcome Admin!' : 'Admin Portal',
                      style: TextStyle(
                        fontSize: adaptive.sp(24),
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      _autoLoginInProgress 
                          ? 'Auto-signing you in...'
                          : widget.isFromSignup
                              ? 'Please sign in to access your dashboard'
                              : 'Sign in to system administration',
                      style: TextStyle(
                        fontSize: adaptive.sp(14),
                        color: Colors.white70,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
              SizedBox(height: adaptive.scale(30)),
              Container(
                padding: adaptive.responsivePadding(all: 20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: adaptive.responsiveBorderRadius(20),
                ),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      if (_autoFilled && !_autoLoginInProgress && !widget.isFromSignup)
                        Container(
                          padding: adaptive.responsivePadding(all: 15),
                          margin: adaptive.responsiveMargin(bottom: 20),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF5EBFF),
                            border: Border.all(color: UserRole.admin.primaryColor),
                            borderRadius: adaptive.responsiveBorderRadius(10),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.info, 
                                color: UserRole.admin.primaryColor,
                                size: adaptive.responsiveIconSize(20),
                              ),
                              SizedBox(width: adaptive.scale(10)),
                              Expanded(
                                child: Text(
                                  'Admin credentials loaded from saved data',
                                  style: TextStyle(
                                    color: UserRole.admin.primaryColor,
                                    fontWeight: FontWeight.w500,
                                    fontSize: adaptive.sp(14),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      if (_autoLoginInProgress)
                        Container(
                          padding: adaptive.responsivePadding(all: 30),
                          margin: adaptive.responsiveMargin(bottom: 20),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF5EBFF),
                            border: Border.all(color: UserRole.admin.primaryColor),
                            borderRadius: adaptive.responsiveBorderRadius(10),
                          ),
                          child: Column(
                            children: [
                              SizedBox(
                                height: adaptive.responsiveIconSize(24),
                                width: adaptive.responsiveIconSize(24),
                                child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(UserRole.admin.primaryColor),
                                ),
                              ),
                              SizedBox(height: adaptive.scale(20)),
                              Text(
                                'Auto-signing in admin: ${_adminIdController.text}',
                                style: TextStyle(
                                  color: UserRole.admin.primaryColor,
                                  fontWeight: FontWeight.w500,
                                  fontSize: adaptive.sp(16),
                                ),
                                textAlign: TextAlign.center,
                              ),
                              SizedBox(height: adaptive.scale(10)),
                              Text(
                                'Please wait while we verify your admin credentials',
                                style: TextStyle(
                                  color: const Color(0xFF666666),
                                  fontSize: adaptive.sp(12),
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                      if (!_autoLoginInProgress) ...[
                        CustomTextField(
                          label: 'Admin ID',
                          placeholder: 'Enter your admin ID',
                          controller: _adminIdController,
                          validator: (value) => value?.isEmpty == true ? 'Please enter your admin ID' : null,
                        ),
                        CustomTextField(
                          label: 'Password',
                          placeholder: 'Enter your password',
                          controller: _passwordController,
                          isPassword: true,
                          validator: (value) => value?.isEmpty == true ? 'Please enter your password' : null,
                        ),
                        SizedBox(height: adaptive.scale(20)),
                        CustomButton(
                          text: 'Sign In as Admin',
                          backgroundColor: UserRole.admin.primaryColor,
                          isLoading: _isLoading,
                          onPressed: () => _handleLogin(autoLogin: false),
                        ),
                        SizedBox(height: adaptive.scale(15)),
                        if (!widget.isFromSignup)
                          TextButton(
                            onPressed: () {
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const RoleSelectionLoginScreen(),
                                ),
                              );
                            },
                            child: Text(
                              'Login as different role',
                              style: TextStyle(
                                color: UserRole.admin.primaryColor,
                                fontSize: adaptive.sp(14),
                              ),
                            ),
                          ),
                        SizedBox(height: adaptive.scale(20)),
                        Center(
                          child: Text.rich(
                            TextSpan(
                              text: 'Forgot password? ',
                              style: TextStyle(
                                fontSize: adaptive.sp(14), 
                                color: const Color(0xFF666666)
                              ),
                              children: [
                                TextSpan(
                                  text: 'Reset here',
                                  style: TextStyle(
                                    color: UserRole.admin.primaryColor,
                                    fontSize: adaptive.sp(14),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _handleLogin({required bool autoLogin}) async {
    if (!autoLogin && !_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      // Use AuthService for authentication
      final result = await AuthService.login(
        email: _adminIdController.text,
        password: _passwordController.text,
        role: UserRole.admin,
      );

      if (result['success'] == true) {
        // Set current user role for compatibility
        await UserDataService.setCurrentUserRole(UserRole.admin);
        
        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => const AdminInterfaceScreen(),
            ),
          );
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(result['message'] ?? 'Login failed'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Login error: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }
}
