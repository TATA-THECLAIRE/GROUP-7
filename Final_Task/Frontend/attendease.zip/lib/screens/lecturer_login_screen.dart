import 'package:flutter/material.dart';
import '../models/user_role.dart';
import '../widgets/custom_button.dart';
import '../widgets/custom_text_field.dart';
import '../widgets/app_bar_widget.dart';
import '../services/user_data_service.dart';
import '../utils/adaptive_screen_manager.dart';
import 'role_selection_login_screen.dart';
import 'lecturer/lecturer_interface_screen.dart';
import '../services/auth/auth_service.dart';

class LecturerLoginScreen extends StatefulWidget {
  final bool isFromSignup;

  const LecturerLoginScreen({
    super.key, 
    this.isFromSignup = false,
  });

  @override
  State<LecturerLoginScreen> createState() => _LecturerLoginScreenState();
}

class _LecturerLoginScreenState extends State<LecturerLoginScreen> {
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;
  bool _autoFilled = false;
  bool _autoLoginInProgress = false;
  bool _showCredentialPopup = false;
  
  final _lecturerIdController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.isFromSignup) {
      _handleSignupFlow();
    } else {
      _loadUserData();
    }
  }

  Future<void> _handleSignupFlow() async {
    final userData = await UserDataService.getUser(UserRole.lecturer);
    if (userData != null) {
      setState(() {
        _lecturerIdController.text = userData.id;
        _passwordController.text = userData.password;
        _autoFilled = true;
        _showCredentialPopup = true;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Lecturer account created successfully! Please sign in to continue.'),
            backgroundColor: Color(0xFF4CAF50),
            duration: Duration(seconds: 3),
          ),
        );
      }

      await Future.delayed(const Duration(seconds: 1));
      if (mounted && _showCredentialPopup) {
        _showCredentialSavingPopup();
      }
    }
  }

  Future<void> _showCredentialSavingPopup() async {
    setState(() {
      _showCredentialPopup = false;
    });

    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        final adaptive = context.adaptive;
        return Align(
          alignment: Alignment.topRight,
          child: Container(
            margin: adaptive.responsiveMargin(top: 100, right: 20),
            width: adaptive.wp(85),
            child: Material(
              borderRadius: adaptive.responsiveBorderRadius(15),
              elevation: 8,
              child: Container(
                padding: adaptive.responsivePadding(all: 20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: adaptive.responsiveBorderRadius(15),
                  border: Border.all(color: UserRole.lecturer.primaryColor, width: 2),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: adaptive.responsivePadding(all: 8),
                          decoration: BoxDecoration(
                            color: UserRole.lecturer.primaryColor.withValues(alpha: 0.1),
                            borderRadius: adaptive.responsiveBorderRadius(8),
                          ),
                          child: Icon(
                            Icons.save,
                            color: UserRole.lecturer.primaryColor,
                            size: adaptive.responsiveIconSize(20),
                          ),
                        ),
                        SizedBox(width: adaptive.scale(10)),
                        Expanded(
                          child: Text(
                            'Save Lecturer Login?',
                            style: TextStyle(
                              fontSize: adaptive.sp(16),
                              fontWeight: FontWeight.bold,
                              color: const Color(0xFF333333),
                            ),
                          ),
                        ),
                        IconButton(
                          onPressed: () => Navigator.of(context).pop(false),
                          icon: Icon(Icons.close, size: adaptive.responsiveIconSize(20)),
                          padding: EdgeInsets.zero,
                          constraints: const BoxConstraints(),
                        ),
                      ],
                    ),
                    SizedBox(height: adaptive.scale(15)),
                    Text(
                      'Save your lecturer credentials for quick access next time?',
                      style: TextStyle(
                        fontSize: adaptive.sp(14),
                        color: const Color(0xFF666666),
                      ),
                    ),
                    SizedBox(height: adaptive.scale(20)),
                    Row(
                      children: [
                        Expanded(
                          child: TextButton(
                            onPressed: () => Navigator.of(context).pop(false),
                            style: TextButton.styleFrom(
                              padding: adaptive.responsivePadding(vertical: 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: adaptive.responsiveBorderRadius(8),
                                side: const BorderSide(color: Color(0xFFDDDDDD)),
                              ),
                            ),
                            child: Text(
                              'No, Thanks',
                              style: TextStyle(
                                color: const Color(0xFF666666),
                                fontSize: adaptive.sp(14),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(width: adaptive.scale(10)),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () => Navigator.of(context).pop(true),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: UserRole.lecturer.primaryColor,
                              foregroundColor: Colors.white,
                              padding: adaptive.responsivePadding(vertical: 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: adaptive.responsiveBorderRadius(8),
                              ),
                            ),
                            child: Text(
                              'Yes, Save',
                              style: TextStyle(fontSize: adaptive.sp(14)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
    
    if (result == true) {
      await UserDataService.setAutoLoginEnabled(true);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Lecturer login saved! Auto-login enabled.'),
            backgroundColor: Color(0xFF4CAF50),
          ),
        );
      }
    }
  }

  Future<void> _loadUserData() async {
    final userData = await UserDataService.getUser(UserRole.lecturer);
    final autoLoginEnabled = await UserDataService.isAutoLoginEnabled();
    final currentRole = await UserDataService.getCurrentUserRole();
    
    if (userData != null && currentRole == UserRole.lecturer && autoLoginEnabled) {
      setState(() {
        _lecturerIdController.text = userData.id;
        _passwordController.text = userData.password;
        _autoFilled = true;
        _autoLoginInProgress = true;
      });

      await Future.delayed(const Duration(seconds: 2));
      
      if (mounted) {
        _handleLogin(autoLogin: true);
      }
    } else if (userData != null) {
      setState(() {
        _lecturerIdController.text = userData.id;
        _passwordController.text = userData.password;
        _autoFilled = true;
      });
    }
  }

  @override
  void dispose() {
    _lecturerIdController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    
    return Scaffold(
      appBar: const CustomAppBar(),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF667EEA), Color(0xFF764BA2)],
          ),
        ),
        child: SingleChildScrollView(
          padding: adaptive.responsivePadding(all: 20),
          child: Column(
            children: [
              SizedBox(height: adaptive.scale(20)),
              Center(
                child: Column(
                  children: [
                    Container(
                      padding: adaptive.responsivePadding(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: UserRole.lecturer.lightColor,
                        borderRadius: adaptive.responsiveBorderRadius(20),
                      ),
                      child: Text(
                        'LECTURER LOGIN',
                        style: TextStyle(
                          color: UserRole.lecturer.primaryColor,
                          fontSize: adaptive.sp(12),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    SizedBox(height: adaptive.scale(10)),
                    Text(
                      widget.isFromSignup ? 'Welcome Lecturer!' : 'Lecturer Portal',
                      style: TextStyle(
                        fontSize: adaptive.sp(24),
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      _autoLoginInProgress 
                          ? 'Auto-signing you in...'
                          : widget.isFromSignup
                              ? 'Please sign in to access your dashboard'
                              : 'Sign in to manage class attendance',
                      style: TextStyle(
                        fontSize: adaptive.sp(14),
                        color: Colors.white70,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
              SizedBox(height: adaptive.scale(30)),
              Container(
                padding: adaptive.responsivePadding(all: 20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: adaptive.responsiveBorderRadius(20),
                ),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      if (_autoFilled && !_autoLoginInProgress && !widget.isFromSignup)
                        Container(
                          padding: adaptive.responsivePadding(all: 15),
                          margin: adaptive.responsiveMargin(bottom: 20),
                          decoration: BoxDecoration(
                            color: const Color(0xFFEBF5FF),
                            border: Border.all(color: UserRole.lecturer.primaryColor),
                            borderRadius: adaptive.responsiveBorderRadius(10),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.info, 
                                color: UserRole.lecturer.primaryColor,
                                size: adaptive.responsiveIconSize(20),
                              ),
                              SizedBox(width: adaptive.scale(10)),
                              Expanded(
                                child: Text(
                                  'Lecturer credentials loaded from saved data',
                                  style: TextStyle(
                                    color: UserRole.lecturer.primaryColor,
                                    fontWeight: FontWeight.w500,
                                    fontSize: adaptive.sp(14),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      if (_autoLoginInProgress)
                        Container(
                          padding: adaptive.responsivePadding(all: 30),
                          margin: adaptive.responsiveMargin(bottom: 20),
                          decoration: BoxDecoration(
                            color: const Color(0xFFEBF5FF),
                            border: Border.all(color: UserRole.lecturer.primaryColor),
                            borderRadius: adaptive.responsiveBorderRadius(10),
                          ),
                          child: Column(
                            children: [
                              SizedBox(
                                height: adaptive.responsiveIconSize(24),
                                width: adaptive.responsiveIconSize(24),
                                child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(UserRole.lecturer.primaryColor),
                                ),
                              ),
                              SizedBox(height: adaptive.scale(20)),
                              Text(
                                'Auto-signing in lecturer: ${_lecturerIdController.text}',
                                style: TextStyle(
                                  color: UserRole.lecturer.primaryColor,
                                  fontWeight: FontWeight.w500,
                                  fontSize: adaptive.sp(16),
                                ),
                                textAlign: TextAlign.center,
                              ),
                              SizedBox(height: adaptive.scale(10)),
                              Text(
                                'Please wait while we verify your lecturer credentials',
                                style: TextStyle(
                                  color: const Color(0xFF666666),
                                  fontSize: adaptive.sp(12),
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                      if (!_autoLoginInProgress) ...[
                        CustomTextField(
                          label: 'Lecturer ID',
                          placeholder: 'Enter your lecturer ID',
                          controller: _lecturerIdController,
                          validator: (value) => value?.isEmpty == true ? 'Please enter your lecturer ID' : null,
                        ),
                        CustomTextField(
                          label: 'Password',
                          placeholder: 'Enter your password',
                          controller: _passwordController,
                          isPassword: true,
                          validator: (value) => value?.isEmpty == true ? 'Please enter your password' : null,
                        ),
                        SizedBox(height: adaptive.scale(20)),
                        CustomButton(
                          text: 'Sign In as Lecturer',
                          backgroundColor: UserRole.lecturer.primaryColor,
                          isLoading: _isLoading,
                          onPressed: () => _handleLogin(autoLogin: false),
                        ),
                        SizedBox(height: adaptive.scale(15)),
                        if (!widget.isFromSignup)
                          TextButton(
                            onPressed: () {
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const RoleSelectionLoginScreen(),
                                ),
                              );
                            },
                            child: Text(
                              'Login as different role',
                              style: TextStyle(
                                color: UserRole.lecturer.primaryColor,
                                fontSize: adaptive.sp(14),
                              ),
                            ),
                          ),
                        SizedBox(height: adaptive.scale(20)),
                        Center(
                          child: Text.rich(
                            TextSpan(
                              text: 'Forgot password? ',
                              style: TextStyle(
                                fontSize: adaptive.sp(14), 
                                color: const Color(0xFF666666)
                              ),
                              children: [
                                TextSpan(
                                  text: 'Reset here',
                                  style: TextStyle(
                                    color: UserRole.lecturer.primaryColor,
                                    fontSize: adaptive.sp(14),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _handleLogin({required bool autoLogin}) async {
    if (!autoLogin && !_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      // Use AuthService for authentication
      final result = await AuthService.login(
        email: _lecturerIdController.text,
        password: _passwordController.text,
        role: UserRole.lecturer,
      );

      if (result['success'] == true) {
        // Set current user role for compatibility
        await UserDataService.setCurrentUserRole(UserRole.lecturer);
        
        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => LecturerInterfaceScreen(
                isFromSignup: widget.isFromSignup,
              ),
            ),
          );
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(result['message'] ?? 'Login failed'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Login error: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }
}
