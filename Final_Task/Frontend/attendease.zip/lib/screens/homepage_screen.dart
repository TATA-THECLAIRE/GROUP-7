import 'package:flutter/material.dart';
import 'dart:async';
import '../widgets/custom_button.dart';
import 'role_selection_screen.dart';
import 'role_selection_login_screen.dart';

class HomepageScreen extends StatefulWidget {
  const HomepageScreen({super.key});

  @override
  State<HomepageScreen> createState() => _HomepageScreenState();
}

class _HomepageScreenState extends State<HomepageScreen> {
  int currentSlide = 0;
  Timer? slideTimer;
  final PageController pageController = PageController();

  final List<SlideData> slides = [
    SlideData(
      title: 'Welcome to AttendEase',
      description: 'Revolutionizing attendance management for educational institutions',
      backgroundImage: 'assets/images/slide1.png',
    ),
    SlideData(
      title: 'AttendEase',
      description: 'Smart attendance management with facial recognition and geofencing technology for seamless check-ins',
      showLogo: true,
      backgroundImage: 'assets/images/slide2.png',
    ),
    SlideData(
      title: 'Facial Recognition',
      description: 'Secure and accurate attendance tracking using advanced facial recognition technology',
      backgroundImage: 'assets/images/slide3.png',
    ),
    SlideData(
      title: 'Geofencing',
      description: 'Ensure attendance is only marked when students are in the classroom',
      backgroundImage: 'assets/images/slide4.png',
    ),
  ];

  @override
  void initState() {
    super.initState();
    startSlideshow();
  }

  @override
  void dispose() {
    slideTimer?.cancel();
    pageController.dispose();
    super.dispose();
  }

  void startSlideshow() {
    slideTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (currentSlide < slides.length - 1) {
        currentSlide++;
      } else {
        currentSlide = 0;
      }
      pageController.animateToPage(
        currentSlide,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    });
  }

  void goToSlide(int index) {
    setState(() {
      currentSlide = index;
    });
    pageController.animateToPage(
      index,
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeInOut,
    );
    slideTimer?.cancel();
    startSlideshow();
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;
    
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF5D3BE3),
        elevation: 0,
        automaticallyImplyLeading: false,
        title: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Image.asset(
                    'assets/images/logo.png',
                    fit: BoxFit.contain,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Center(
                          child: Text(
                            'AE',
                            style: TextStyle(
                              color: Color(0xFF5D3BE3),
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            const Text(
              'AttendEase',
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF667EEA), Color(0xFF764BA2)],
          ),
        ),
        child: Stack(
          children: [
            SizedBox(
              height: screenHeight,
              width: screenWidth,
              child: PageView.builder(
                controller: pageController,
                onPageChanged: (index) {
                  setState(() {
                    currentSlide = index;
                  });
                },
                itemCount: slides.length,
                itemBuilder: (context, index) {
                  return _buildSlide(slides[index]);
                },
              ),
            ),
            Positioned(
              bottom: screenHeight * 0.2,
              left: 0,
              right: 0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                  slides.length,
                  (index) => GestureDetector(
                    onTap: () => goToSlide(index),
                    child: Container(
                      width: 10,
                      height: 10,
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: currentSlide == index
                            ? const Color(0xFF5D3BE3)
                            : Colors.white.withValues(alpha: 0.5),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 30,
              left: screenWidth * 0.05,
              right: screenWidth * 0.05,
              child: Column(
                children: [
                  CustomButton(
                    text: 'Sign Up',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const RoleSelectionScreen(),
                        ),
                      );
                    },
                  ),
                  CustomButton(
                    text: 'Login',
                    isSecondary: true,
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const RoleSelectionLoginScreen(),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSlide(SlideData slide) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;
    
    return SizedBox(
      width: screenWidth,
      height: screenHeight,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Background image with advanced fitting for wide images
          SizedBox(
            width: screenWidth,
            height: screenHeight,
            child: FittedBox(
              fit: BoxFit.cover,
              alignment: Alignment.center,
              child: SizedBox(
                width: screenWidth,
                height: screenHeight,
                child: Image.asset(
                  slide.backgroundImage,
                  fit: BoxFit.cover,
                  alignment: Alignment.center,
                  errorBuilder: (context, error, stackTrace) {
                    // Failed to load background image: ${slide.backgroundImage} - Error: $error
                    // Fallback gradient if image fails to load
                    return Container(
                      width: screenWidth,
                      height: screenHeight,
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [Color(0xFF667EEA), Color(0xFF764BA2)],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
          // Dark overlay for better text readability
          Container(
            color: Colors.black.withAlpha(102),
          ),
          // Content overlay with better positioning
          SafeArea(
            child: Padding(
              padding: EdgeInsets.symmetric(
                horizontal: screenWidth * 0.05,
                vertical: screenHeight * 0.05,
              ),
              child: Center(
                child: Container(
                  width: double.infinity,
                  constraints: BoxConstraints(
                    maxWidth: screenWidth * 0.9,
                    maxHeight: screenHeight * 0.7,
                  ),
                  padding: EdgeInsets.all(screenWidth * 0.06),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.95),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withAlpha(77),
                        blurRadius: 15,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        if (slide.showLogo) ...[
                          Container(
                            width: screenWidth * 0.25,
                            height: screenWidth * 0.25,
                            constraints: const BoxConstraints(
                              minWidth: 100,
                              minHeight: 100,
                              maxWidth: 150,
                              maxHeight: 150,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: const Color(0xFF5D3BE3),
                                width: 3,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFF5D3BE3).withAlpha(51),
                                  blurRadius: 10,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(17),
                              child: Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Image.asset(
                                  'assets/images/logo.png',
                                  fit: BoxFit.contain,
                                  errorBuilder: (context, error, stackTrace) {
                                    // Failed to load logo image: $error
                                    return Container(
                                      decoration: const BoxDecoration(
                                        color: Color(0xFF5D3BE3),
                                        borderRadius: BorderRadius.all(Radius.circular(8)),
                                      ),
                                      child: Center(
                                        child: Text(
                                          'AE',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: screenWidth * 0.08,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: screenHeight * 0.025),
                        ],
                        Text(
                          slide.title,
                          style: TextStyle(
                            fontSize: slide.showLogo 
                                ? screenWidth * 0.075 
                                : screenWidth * 0.065,
                            fontWeight: FontWeight.w700,
                            color: const Color(0xFF5D3BE3),
                            letterSpacing: -0.5,
                            height: 1.2,
                          ),
                          textAlign: TextAlign.center,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                        ),
                        SizedBox(height: screenHeight * 0.02),
                        Text(
                          slide.description,
                          style: TextStyle(
                            fontSize: screenWidth * 0.042,
                            color: const Color(0xFF333333),
                            height: 1.6,
                            fontWeight: FontWeight.w400,
                          ),
                          textAlign: TextAlign.center,
                          maxLines: 6,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class SlideData {
  final String title;
  final String description;
  final String backgroundImage;
  final bool showLogo;

  SlideData({
    required this.title,
    required this.description,
    required this.backgroundImage,
    this.showLogo = false,
  });
}
