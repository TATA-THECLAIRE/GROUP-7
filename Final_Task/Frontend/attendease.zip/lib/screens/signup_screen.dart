import 'package:flutter/material.dart';
import 'dart:developer' as developer;
import '../models/user_role.dart';
import '../widgets/custom_button.dart';
import '../widgets/custom_text_field.dart';
import '../widgets/custom_dropdown.dart';
import '../widgets/app_bar_widget.dart';
import '../services/permission_service.dart';
import '../services/auth/auth_service.dart';
import '../config/feature_flags.dart';
import '../utils/fet_validators.dart';
import 'two_fa_screen.dart';

class SignupScreen extends StatefulWidget {
  final UserRole role;

  const SignupScreen({super.key, required this.role});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final _formKey = GlobalKey<FormState>();
  bool _faceScanned = false;
  bool _isScanning = false;
  bool _isLoading = false;
  bool _backendHealthy = false;

  // Form controllers
  final _fullNameController = TextEditingController();
  final _idController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final _phoneController = TextEditingController();
  final _institutionController = TextEditingController();
  final _adminCodeController = TextEditingController();
  
  String? _selectedDepartment;
  String? _selectedLevel;
  String? _selectedGender;

  @override
  void initState() {
    super.initState();
    _checkBackendHealth();
  }

  Future<void> _checkBackendHealth() async {
    if (FeatureFlags.ENABLE_AUTH_API) {
      developer.log('🏥 Checking backend health...', name: 'SIGNUP_SCREEN');
      final healthResult = await AuthService.checkBackendHealth();
      if (mounted) {
        setState(() {
          _backendHealthy = healthResult['success'] == true;
        });
        
        if (_backendHealthy) {
          developer.log('✅ Backend is healthy and ready!', name: 'SIGNUP_SCREEN');
        } else {
          developer.log('❌ Backend health check failed: ${healthResult['message']}', name: 'SIGNUP_SCREEN');
        }
      }
    }
  }

  @override
  void dispose() {
    _fullNameController.dispose();
    _idController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    _phoneController.dispose();
    _institutionController.dispose();
    _adminCodeController.dispose();
    super.dispose();
  }

  // Enhanced validators using updated FET validators
  String? _validateEmail(String? value) {
    return FETValidators.validateEmailByUserType(value, widget.role.toString().split('.').last);
  }

  String? _validateMatricle(String? value) {
    return FETValidators.validateUBMatricleNumber(value);
  }

  String? _validatePassword(String? value) {
    return FETValidators.validatePassword(value);
  }

  String? _validateConfirmPassword(String? value) {
    return FETValidators.validatePasswordConfirmation(value, _passwordController.text);
  }

  String? _validateFullName(String? value) {
    return FETValidators.validateFullName(value);
  }

  String? _validateLecturerID(String? value) {
    return FETValidators.validateLecturerID(value);
  }

  String? _validateAdminID(String? value) {
    return FETValidators.validateAdminID(value);
  }

  String? _validateRequired(String? value, String fieldName) {
    return FETValidators.validateRequired(value, fieldName);
  }

  String? _validateDepartment(String? value) {
    return FETValidators.validateDepartment(value);
  }

  String? _validateLevel(String? value) {
    return FETValidators.validateLevel(value);
  }

  String? _validateGender(String? value) {
    return FETValidators.validateGender(value);
  }

  String? _validatePhoneNumber(String? value) {
    return FETValidators.validatePhoneNumber(value);
  }

  Future<void> _validateEmailWithBackend() async {
    if (_emailController.text.trim().isEmpty) return;
    
    final result = await AuthService.validateFETEmail(
      _emailController.text.trim(),
      widget.role.toString().split('.').last,
    );

    if (mounted) {
      if (result['success'] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('✅ ${result['message']}'),
            backgroundColor: Colors.green,
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('❌ ${result['error']}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _validateMatricleWithBackend() async {
    if (_idController.text.trim().isEmpty || widget.role != UserRole.student) return;
    
    final result = await AuthService.validateFETMatricle(_idController.text.trim());

    if (mounted) {
      if (result['success'] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('✅ ${result['message']}'),
            backgroundColor: Colors.green,
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('❌ ${result['error']}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF667EEA), Color(0xFF764BA2)],
          ),
        ),
        child: SingleChildScrollView(
          padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.05),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 20),
                Center(
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: widget.role.lightColor,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          widget.role.displayName.toUpperCase(),
                          style: TextStyle(
                            color: widget.role.primaryColor,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        'Create Account',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      Text(
                        'Join AttendEase as a ${widget.role.displayName.toLowerCase()}',
                        style: const TextStyle(
                          fontSize: 14,
                          color: Colors.white70,
                        ),
                      ),
                      // Phase indicator with backend health
                      Container(
                        margin: const EdgeInsets.only(top: 8),
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: FeatureFlags.ENABLE_AUTH_API 
                              ? (_backendHealthy ? Colors.green.withValues(alpha: 0.2) : Colors.red.withValues(alpha: 0.2))
                              : Colors.orange.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: FeatureFlags.ENABLE_AUTH_API 
                                ? (_backendHealthy ? Colors.green : Colors.red)
                                : Colors.orange
                          ),
                        ),
                        child: Text(
                          FeatureFlags.ENABLE_AUTH_API 
                              ? (_backendHealthy ? 'LIVE API ✅' : 'API OFFLINE ❌')
                              : 'MOCK MODE 🎭',
                          style: TextStyle(
                            fontSize: 10,
                            color: FeatureFlags.ENABLE_AUTH_API 
                                ? (_backendHealthy ? Colors.green : Colors.red)
                                : Colors.orange,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 30),
                Container(
                  padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.05),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    children: [
                      _buildFormFields(),
                      if (widget.role == UserRole.student) ...[
                        _buildFaceRegistrationSection(),
                      ],
                      const SizedBox(height: 20),
                      CustomButton(
                        text: _isLoading 
                            ? 'Creating Account...' 
                            : 'Create Account',
                        backgroundColor: widget.role.primaryColor,
                        isLoading: _isLoading,
                        onPressed: _handleCreateAccount,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFormFields() {
    switch (widget.role) {
      case UserRole.student:
        return Column(
          children: [
            CustomTextField(
              label: 'Full Name',
              placeholder: 'Enter your full name',
              controller: _fullNameController,
              validator: _validateFullName,
              helpText: 'Enter your complete name as it appears on official documents',
            ),
            Row(
              children: [
                Expanded(
                  child: CustomTextField(
                    label: 'Matricle Number',
                    placeholder: 'e.g., CSC/2024/1179',
                    controller: _idController,
                    validator: _validateMatricle,
                    helpText: 'Format: ABC/YYYY/NNNN (Department/Year/Number)',
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.check_circle_outline),
                  onPressed: _validateMatricleWithBackend,
                  tooltip: 'Validate Format',
                ),
              ],
            ),
            CustomDropdown(
              label: 'Department',
              placeholder: 'Select Department',
              items: const [
                'CE - Computer Engineering',
                'EE - Electrical Engineering', 
                'ME - Mechanical Engineering',
                'CVE - Civil Engineering',
                'CHE - Chemical Engineering',
                'CS - Computer Science',
                'MTH - Mathematics',
                'PHY - Physics',
                'CHM - Chemistry',
                'ENG - English'
              ],
              value: _selectedDepartment,
              onChanged: (value) => setState(() => _selectedDepartment = value),
              validator: _validateDepartment,
            ),
            CustomDropdown(
              label: 'Level',
              placeholder: 'Select Level',
              items: const ['Level 100', 'Level 200', 'Level 300', 'Level 400', 'Level 500'],
              value: _selectedLevel,
              onChanged: (value) => setState(() => _selectedLevel = value),
              validator: _validateLevel,
            ),
            CustomDropdown(
              label: 'Gender',
              placeholder: 'Select Gender',
              items: const ['Male', 'Female'],
              value: _selectedGender,
              onChanged: (value) => setState(() => _selectedGender = value),
              validator: _validateGender,
            ),
            Row(
              children: [
                Expanded(
                  child: CustomTextField(
                    label: 'Email',
                    placeholder: 'your.email@example.com',
                    controller: _emailController,
                    validator: _validateEmail,
                    keyboardType: TextInputType.emailAddress,
                    helpText: 'Use your personal email (not @ubuea.cm)',
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.check_circle_outline),
                  onPressed: _validateEmailWithBackend,
                  tooltip: 'Validate Email',
                ),
              ],
            ),
            CustomTextField(
              label: 'Password',
              placeholder: 'Enter password',
              controller: _passwordController,
              isPassword: true,
              validator: _validatePassword,
              helpText: 'Must contain letters, numbers, and special characters',
            ),
            CustomTextField(
              label: 'Confirm Password',
              placeholder: 'Confirm your password',
              controller: _confirmPasswordController,
              isPassword: true,
              validator: _validateConfirmPassword,
            ),
          ],
        );
      case UserRole.lecturer:
        return Column(
          children: [
            CustomTextField(
              label: 'Full Name',
              placeholder: 'Enter your full name',
              controller: _fullNameController,
              validator: _validateFullName,
              helpText: 'Enter your complete name as it appears on official documents',
            ),
            CustomTextField(
              label: 'Lecturer ID',
              placeholder: 'Enter lecturer ID',
              controller: _idController,
              validator: _validateLecturerID,
              helpText: 'Your institutional lecturer identification number',
            ),
            Row(
              children: [
                Expanded(
                  child: CustomTextField(
                    label: 'Email',
                    placeholder: 'firstname.lastname@ubuea.cm',
                    controller: _emailController,
                    validator: _validateEmail,
                    keyboardType: TextInputType.emailAddress,
                    helpText: 'Use your UB institutional email',
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.check_circle_outline),
                  onPressed: _validateEmailWithBackend,
                  tooltip: 'Validate Email',
                ),
              ],
            ),
            CustomTextField(
              label: 'Phone Number (Optional)',
              placeholder: '+237 6XX XXX XXX',
              controller: _phoneController,
              validator: _validatePhoneNumber,
              keyboardType: TextInputType.phone,
              helpText: 'Cameroon phone number format preferred',
            ),
            CustomTextField(
              label: 'Password',
              placeholder: 'Enter password',
              controller: _passwordController,
              isPassword: true,
              validator: _validatePassword,
              helpText: 'Must contain letters, numbers, and special characters',
            ),
            CustomTextField(
              label: 'Confirm Password',
              placeholder: 'Confirm your password',
              controller: _confirmPasswordController,
              isPassword: true,
              validator: _validateConfirmPassword,
            ),
          ],
        );
      case UserRole.admin:
        return Column(
          children: [
            CustomTextField(
              label: 'Full Name',
              placeholder: 'Enter your full name',
              controller: _fullNameController,
              validator: _validateFullName,
              helpText: 'Enter your complete name as it appears on official documents',
            ),
            CustomTextField(
              label: 'Admin ID',
              placeholder: 'Enter admin ID',
              controller: _idController,
              validator: _validateAdminID,
              helpText: 'Your administrative identification number',
            ),
            Row(
              children: [
                Expanded(
                  child: CustomTextField(
                    label: 'Email',
                    placeholder: 'admin@institution.edu',
                    controller: _emailController,
                    validator: _validateEmail,
                    keyboardType: TextInputType.emailAddress,
                    helpText: 'Your institutional or professional email',
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.check_circle_outline),
                  onPressed: _validateEmailWithBackend,
                  tooltip: 'Validate Email',
                ),
              ],
            ),
            CustomTextField(
              label: 'Institution',
              placeholder: 'University of Buea - FET',
              controller: _institutionController,
              validator: (value) => _validateRequired(value, 'Institution'),
              helpText: 'Full name of your institution',
            ),
            CustomTextField(
              label: 'Password',
              placeholder: 'Enter password',
              controller: _passwordController,
              isPassword: true,
              validator: _validatePassword,
              helpText: 'Must contain letters, numbers, and special characters',
            ),
            CustomTextField(
              label: 'Confirm Password',
              placeholder: 'Confirm your password',
              controller: _confirmPasswordController,
              isPassword: true,
              validator: _validateConfirmPassword,
            ),
            CustomTextField(
              label: 'Admin Code',
              placeholder: 'Enter admin access code',
              controller: _adminCodeController,
              isPassword: true,
              validator: (value) => _validateRequired(value, 'Admin Code'),
              helpText: 'Special access code provided by your institution',
            ),
          ],
        );
    }
  }

  Widget _buildFaceRegistrationSection() {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFFF8F9FA),
        border: Border.all(
          color: _faceScanned ? const Color(0xFF4CAF50) : const Color(0xFF5D3BE3),
          width: 2,
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: _faceScanned ? const Color(0xFF4CAF50) : const Color(0xFF5D3BE3),
              shape: BoxShape.circle,
            ),
            child: Icon(
              _faceScanned ? Icons.check : Icons.camera_alt,
              color: Colors.white,
              size: 24,
            ),
          ),
          const SizedBox(height: 15),
          Text(
            _faceScanned ? 'Face Registered Successfully!' : 'Register Your Face',
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _faceScanned
                ? 'Your face has been registered for attendance verification'
                : 'Tap below to register your face for attendance verification',
            style: const TextStyle(
              fontSize: 12,
              color: Color(0xFF666666),
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 15),
          CustomButton(
            text: _isScanning 
                ? 'Scanning Face...' 
                : _faceScanned 
                    ? 'Face Registered ✓' 
                    : 'Start Face Registration',
            backgroundColor: _faceScanned 
                ? const Color(0xFF4CAF50) 
                : const Color(0xFF5D3BE3),
            isLoading: _isScanning,
            onPressed: _faceScanned ? null : _handleFaceScan,
          ),
        ],
      ),
    );
  }

  Future<void> _handleFaceScan() async {
    final cameraGranted = await PermissionService.requestCameraPermission(context);
    
    if (!cameraGranted) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Camera permission is required for face registration'),
            backgroundColor: Colors.red,
          ),
        );
      }
      return;
    }
    
    setState(() => _isScanning = true);
    
    // Simulate face scanning
    await Future.delayed(const Duration(seconds: 3));
    
    if (mounted) {
      setState(() {
        _isScanning = false;
        _faceScanned = true;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Face registered successfully!'),
          backgroundColor: Color(0xFF4CAF50),
        ),
      );
    }
  }

  Future<void> _handleCreateAccount() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }
    
    // For students, check if face is scanned
    if (widget.role == UserRole.student && !_faceScanned) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Please complete face registration first'),
            backgroundColor: Colors.red,
          ),
        );
      }
      return;
    }
    
    setState(() => _isLoading = true);
    
    // For students, request location permission
    if (widget.role == UserRole.student) {
      final locationGranted = await PermissionService.requestLocationPermission(context);
      
      if (!locationGranted) {
        setState(() => _isLoading = false);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Location permission is required for attendance verification'),
              backgroundColor: Colors.red,
            ),
          );
        }
        return;
      }
    }
    
    try {
      developer.log('🚀 Starting registration process...', name: 'SIGNUP_SCREEN');
      developer.log('📧 Email: ${_emailController.text}', name: 'SIGNUP_SCREEN');
      developer.log('👤 Role: ${widget.role}', name: 'SIGNUP_SCREEN');
      developer.log('🔧 API Enabled: ${FeatureFlags.ENABLE_AUTH_API}', name: 'SIGNUP_SCREEN');
      developer.log('🏥 Backend Healthy: $_backendHealthy', name: 'SIGNUP_SCREEN');
      
      // Prepare additional data based on role
      final additionalData = <String, dynamic>{
        'full_name': _fullNameController.text.trim(),
      };
      
      if (widget.role == UserRole.student) {
        additionalData.addAll({
          'matricle_number': _idController.text.trim(),
          'department': _selectedDepartment,
          'level': _selectedLevel,
          'gender': _selectedGender,
        });
      } else if (widget.role == UserRole.lecturer) {
        additionalData.addAll({
          'lecturer_id': _idController.text.trim(),
          'phone': _phoneController.text.trim(),
        });
      } else if (widget.role == UserRole.admin) {
        additionalData.addAll({
          'admin_id': _idController.text.trim(),
          'institution': _institutionController.text.trim(),
          'admin_code': _adminCodeController.text.trim(),
        });
      }
      
      final result = await AuthService.signup(
        fullName: _fullNameController.text.trim(),
        email: _emailController.text.trim(),
        password: _passwordController.text,
        role: widget.role,
        additionalData: additionalData,
      );
      
      setState(() => _isLoading = false);
      
      if (result['success'] == true) {
        developer.log('✅ Registration successful!', name: 'SIGNUP_SCREEN');
        
        // Determine the source of success
        String sourceIndicator = '';
        if (result['is_api_call'] == true) {
          sourceIndicator = ' (REAL API ✅)';
        } else if (result['is_mock'] == true) {
          sourceIndicator = ' (MOCK DATA 🎭)';
        } else if (result['is_fallback'] == true) {
          sourceIndicator = ' (FALLBACK TO MOCK ⚠️)';
        }
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('${result['message']}$sourceIndicator'),
              backgroundColor: result['is_api_call'] == true ? Colors.green : Colors.orange,
              duration: const Duration(seconds: 4),
            ),
          );
          
          // Show additional info if it was a fallback
          if (result['is_fallback'] == true) {
            Future.delayed(const Duration(seconds: 1), () {
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('API Error: ${result['original_error']}'),
                    backgroundColor: Colors.red,
                    duration: const Duration(seconds: 3),
                  ),
                );
              }
            });
          }
          
          // Navigate to 2FA screen
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => TwoFAScreen(
                role: widget.role, 
                isFromSignup: true,
              ),
            ),
          );
        }
      } else {
        developer.log('❌ Registration failed: ${result['message']}', name: 'SIGNUP_SCREEN');
        
        // Determine the source of failure
        String sourceIndicator = '';
        if (result['is_api_call'] == true) {
          sourceIndicator = ' (API ERROR ❌)';
        } else if (result['is_mock'] == true) {
          sourceIndicator = ' (MOCK ERROR 🎭)';
        }
        
        // Show backend validation errors
        String errorMessage = result['message'] ?? 'Registration failed';
        if (result['field'] != null) {
          errorMessage += ' (Field: ${result['field']})';
        }
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('$errorMessage$sourceIndicator'),
              backgroundColor: Colors.red,
              duration: const Duration(seconds: 4),
            ),
          );
        }
      }
    } catch (e) {
      setState(() => _isLoading = false);
      developer.log('💥 Registration exception: $e', name: 'SIGNUP_SCREEN');
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Network error: ${e.toString()}'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 4),
          ),
        );
      }
    }
  }
}
