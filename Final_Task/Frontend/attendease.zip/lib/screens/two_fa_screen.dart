import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/user_role.dart';
import '../widgets/app_bar_widget.dart';
import 'student_login_screen.dart';
import 'lecturer_login_screen.dart';
import 'admin_login_screen.dart';
import '../utils/adaptive_screen_manager.dart';

class TwoFAScreen extends StatefulWidget {
  final UserRole role;
  final bool isFromSignup;

  const TwoFAScreen({
    super.key, 
    required this.role,
    this.isFromSignup = false,
  });

  @override
  State<TwoFAScreen> createState() => _TwoFAScreenState();
}

class _TwoFAScreenState extends State<TwoFAScreen> {
  final List<TextEditingController> _controllers = List.generate(6, (index) => TextEditingController());
  final List<FocusNode> _focusNodes = List.generate(6, (index) => FocusNode());

  @override
  void dispose() {
    for (var controller in _controllers) {
      controller.dispose();
    }
    for (var focusNode in _focusNodes) {
      focusNode.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
  final adaptive = context.adaptive;
  
  return Scaffold(
    appBar: const CustomAppBar(),
    body: Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF667EEA), Color(0xFF764BA2)],
        ),
      ),
      child: SafeArea(
        child: SingleChildScrollView(
          physics: const ClampingScrollPhysics(),
          child: Padding(
            padding: adaptive.adaptivePadding(horizontal: 16, vertical: 12),
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: adaptive.screenHeight * 0.7,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(height: adaptive.adaptiveSpacing(12)),
                  Text(
                    'Verify Email',
                    style: TextStyle(
                      fontSize: adaptive.adaptiveFont(22),
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: adaptive.adaptiveSpacing(5)),
                  Text(
                    'Enter the 6-digit code sent to your email',
                    style: TextStyle(
                      fontSize: adaptive.adaptiveFont(14),
                      color: Colors.white70,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: adaptive.adaptiveSpacing(20)),
                  Container(
                    width: double.infinity,
                    constraints: BoxConstraints(
                      maxWidth: adaptive.screenWidth * 0.95,
                    ),
                    padding: adaptive.adaptivePadding(
                      vertical: 16,
                      horizontal: adaptive.deviceCategory == DeviceCategory.smallMobile ? 12 : 16,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: adaptive.adaptiveBorderRadius(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withAlpha(20),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Container(
                          padding: adaptive.adaptivePadding(
                            all: adaptive.deviceCategory == DeviceCategory.smallMobile ? 12 : 15,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFFE8F5E8),
                            border: Border.all(color: const Color(0xFF4CAF50)),
                            borderRadius: adaptive.adaptiveBorderRadius(10),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Text('🔒', style: TextStyle(fontSize: adaptive.adaptiveFont(16))),
                                  SizedBox(width: adaptive.adaptiveSpacing(8)),
                                  Expanded(
                                    child: Text(
                                      'Two-Factor Authentication',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: adaptive.adaptiveFont(14),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: adaptive.adaptiveSpacing(10)),
                              Text(
                                'We\'ve sent a verification code to your email address',
                                style: TextStyle(
                                  fontSize: adaptive.adaptiveFont(13),
                                  color: const Color(0xFF666666),
                                ),
                              ),
                              SizedBox(height: adaptive.adaptiveSpacing(15)),
                              _buildAdaptiveOTPRow(adaptive),
                            ],
                          ),
                        ),
                        SizedBox(height: adaptive.adaptiveSpacing(15)),
                        SizedBox(
                          width: double.infinity,
                          height: adaptive.buttonHeight,
                          child: ElevatedButton(
                            onPressed: () {
                              _navigateToCorrectLoginScreen();
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF4CAF50),
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: adaptive.adaptiveBorderRadius(12),
                              ),
                            ),
                            child: Text(
                              'Verify & Complete',
                              style: TextStyle(
                                fontSize: adaptive.adaptiveFont(16),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: adaptive.adaptiveSpacing(15)),
                        Text.rich(
                          TextSpan(
                            text: 'Didn\'t receive code? ',
                            style: TextStyle(
                              fontSize: adaptive.adaptiveFont(14), 
                              color: const Color(0xFF666666)
                            ),
                            children: [
                              TextSpan(
                                text: 'Resend',
                                style: TextStyle(
                                  color: const Color(0xFF5D3BE3),
                                  fontSize: adaptive.adaptiveFont(14),
                                ),
                              ),
                            ],
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    ),
  );
}

Widget _buildAdaptiveOTPRow(AdaptiveScreenManager adaptive) {
  // Calculate optimal size for OTP inputs based on screen width and device category
  double spacing = adaptive.deviceCategory == DeviceCategory.smallMobile ? 2.0 : 4.0;
  
  // Dynamically calculate input size based on available width
  double containerWidth = adaptive.screenWidth - (adaptive.adaptiveSpacing(40) * 2);
  if (adaptive.deviceCategory == DeviceCategory.smallMobile) {
    containerWidth = adaptive.screenWidth - (adaptive.adaptiveSpacing(24) * 2);
  }
  
  double totalSpacing = adaptive.adaptiveSpacing(spacing) * 5; // 5 spaces between 6 inputs
  double inputWidth = (containerWidth - totalSpacing) / 6;
  
  // Ensure minimum and maximum sizes
  inputWidth = inputWidth.clamp(30.0, 50.0);
  double inputHeight = inputWidth; // Keep square aspect ratio
  
  return FittedBox(
    fit: BoxFit.scaleDown,
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(6, (index) => 
        Padding(
          padding: EdgeInsets.symmetric(horizontal: adaptive.adaptiveSpacing(spacing / 2)),
          child: _buildAdaptiveOTPInput(index, inputWidth, inputHeight, adaptive),
        )
      ),
    ),
  );
}

Widget _buildAdaptiveOTPInput(int index, double width, double height, AdaptiveScreenManager adaptive) {
  return SizedBox(
    width: width,
    height: height,
    child: TextFormField(
      controller: _controllers[index],
      focusNode: _focusNodes[index],
      textAlign: TextAlign.center,
      keyboardType: TextInputType.number,
      maxLength: 1,
      style: TextStyle(
        fontSize: adaptive.adaptiveFont(16),
        fontWeight: FontWeight.w600,
      ),
      decoration: InputDecoration(
        counterText: '',
        contentPadding: EdgeInsets.zero,
        border: OutlineInputBorder(
          borderRadius: adaptive.adaptiveBorderRadius(8),
          borderSide: const BorderSide(color: Color(0xFFDDDDDD), width: 1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: adaptive.adaptiveBorderRadius(8),
          borderSide: const BorderSide(color: Color(0xFF4CAF50), width: 2),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: adaptive.adaptiveBorderRadius(8),
          borderSide: const BorderSide(color: Color(0xFFDDDDDD), width: 1),
        ),
      ),
      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
      onChanged: (value) {
        if (value.isNotEmpty && index < 5) {
          _focusNodes[index + 1].requestFocus();
        } else if (value.isEmpty && index > 0) {
          _focusNodes[index - 1].requestFocus();
        }
      },
    ),
  );
}

  void _navigateToCorrectLoginScreen() {
    Widget loginScreen;
    
    switch (widget.role) {
      case UserRole.student:
        loginScreen = const StudentLoginScreen(isFromSignup: true);
        break;
      case UserRole.lecturer:
        loginScreen = const LecturerLoginScreen(isFromSignup: true);
        break;
      case UserRole.admin:
        loginScreen = const AdminLoginScreen(isFromSignup: true);
        break;
    }
    
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => loginScreen),
    );
  }
}
