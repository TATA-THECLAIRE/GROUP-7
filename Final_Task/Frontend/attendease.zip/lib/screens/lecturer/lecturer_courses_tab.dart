import 'package:flutter/material.dart';
import '../../utils/adaptive_screen_manager.dart';

class LecturerCoursesTab extends StatelessWidget {
  final List<Map<String, dynamic>> courses;
  final Function(String) onUploadStudents;
  final Function(String) onManageStudents;
  final bool isDarkMode;

  const LecturerCoursesTab({
    super.key,
    required this.courses,
    required this.onUploadStudents,
    required this.onManageStudents,
    required this.isDarkMode,
  });

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    
    return SingleChildScrollView(
      padding: adaptive.responsivePadding(all: 20, bottom: 100),
      child: Column(
        children: courses.map((course) => _buildCourseCard(course, adaptive)).toList(),
      ),
    );
  }

  Widget _buildCourseCard(Map<String, dynamic> course, AdaptiveScreenManager adaptive) {
    return Container(
      margin: adaptive.responsiveMargin(bottom: 16),
      padding: adaptive.responsivePadding(all: 20),
      decoration: BoxDecoration(
        color: isDarkMode ? const Color(0xFF2d3748) : Colors.white,
        borderRadius: adaptive.responsiveBorderRadius(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
        border: isDarkMode ? Border.all(color: const Color(0xFF4a5568)) : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Course Header
          Row(
            children: [
              Expanded(
                child: Text(
                  course['title'],
                  style: TextStyle(
                    fontSize: adaptive.sp(18),
                    fontWeight: FontWeight.w600,
                    color: isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
                  ),
                ),
              ),
              Container(
                padding: adaptive.responsivePadding(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFf8f9ff),
                  borderRadius: adaptive.responsiveBorderRadius(20),
                ),
                child: Text(
                  course['code'],
                  style: TextStyle(
                    fontSize: adaptive.sp(14),
                    color: isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
                  ),
                ),
              ),
            ],
          ),
          
          SizedBox(height: adaptive.scale(12)),
          
          // Course Info
          Text(
            '${course['level']} • ${course['department']}',
            style: TextStyle(
              fontSize: adaptive.sp(14),
              color: isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
            ),
          ),
          
          SizedBox(height: adaptive.scale(16)),
          
          // Course Management Controls
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: () => onUploadStudents(course['code']),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
                    padding: adaptive.responsivePadding(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: adaptive.responsiveBorderRadius(12),
                    ),
                  ),
                  child: Text(
                    'Upload Students',
                    style: TextStyle(
                      fontSize: adaptive.sp(14),
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              SizedBox(width: adaptive.scale(12)),
              Expanded(
                child: OutlinedButton(
                  onPressed: () => onManageStudents(course['code']),
                  style: OutlinedButton.styleFrom(
                    padding: adaptive.responsivePadding(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: adaptive.responsiveBorderRadius(12),
                    ),
                    side: BorderSide(
                      color: isDarkMode ? const Color(0xFF718096) : const Color(0xFFe5e7ff),
                    ),
                  ),
                  child: Text(
                    'Manage',
                    style: TextStyle(
                      fontSize: adaptive.sp(14),
                      fontWeight: FontWeight.w600,
                      color: isDarkMode ? const Color(0xFFe2e8f0) : const Color(0xFF667eea),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
