import 'package:flutter/material.dart';
import '../../utils/adaptive_screen_manager.dart';

class LecturerDashboardTab extends StatelessWidget {
  final List<Map<String, dynamic>> courses;
  final Map<String, bool> activeSessions;
  final Map<String, int> sessionStats;
  final Function(String) onStartSession;
  final Function(String) onStopSession;
  final Function(String) onViewAttendance;
  final Function(String) onViewRealtime;
  final bool isDarkMode;

  const LecturerDashboardTab({
    super.key,
    required this.courses,
    required this.activeSessions,
    required this.sessionStats,
    required this.onStartSession,
    required this.onStopSession,
    required this.onViewAttendance,
    required this.onViewRealtime,
    required this.isDarkMode,
  });

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    
    return SingleChildScrollView(
      padding: adaptive.responsivePadding(all: 20, bottom: 100),
      child: Column(
        children: [
          // Stats Grid
          Row(
            children: [
              Expanded(
                child: _buildStatCard(
                  '${sessionStats['totalCourses']}',
                  'Active Courses',
                  adaptive,
                ),
              ),
              SizedBox(width: adaptive.scale(16)),
              Expanded(
                child: _buildStatCard(
                  '${sessionStats['totalStudents']}',
                  'Total Students',
                  adaptive,
                ),
              ),
            ],
          ),
          
          SizedBox(height: adaptive.scale(20)),
          
          // Course Cards
          ...courses.map((course) => _buildCourseCard(course, adaptive)),
        ],
      ),
    );
  }

  Widget _buildStatCard(String number, String label, AdaptiveScreenManager adaptive) {
    return Container(
      padding: adaptive.responsivePadding(all: 20),
      decoration: BoxDecoration(
        color: isDarkMode ? const Color(0xFF2d3748) : Colors.white,
        borderRadius: adaptive.responsiveBorderRadius(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
        border: isDarkMode ? Border.all(color: const Color(0xFF4a5568)) : null,
      ),
      child: Column(
        children: [
          Text(
            number,
            style: TextStyle(
              fontSize: adaptive.sp(32),
              fontWeight: FontWeight.bold,
              color: isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
            ),
          ),
          SizedBox(height: adaptive.scale(8)),
          Text(
            label,
            style: TextStyle(
              fontSize: adaptive.sp(14),
              color: isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCourseCard(Map<String, dynamic> course, AdaptiveScreenManager adaptive) {
    final isActive = activeSessions[course['code']] ?? false;
    
    return Container(
      margin: adaptive.responsiveMargin(bottom: 16),
      padding: adaptive.responsivePadding(all: 20),
      decoration: BoxDecoration(
        color: isDarkMode ? const Color(0xFF2d3748) : Colors.white,
        borderRadius: adaptive.responsiveBorderRadius(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
        border: Border(
          left: BorderSide(
            color: isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
            width: 4,
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Course Header
          Row(
            children: [
              Expanded(
                child: Text(
                  course['title'],
                  style: TextStyle(
                    fontSize: adaptive.sp(18),
                    fontWeight: FontWeight.w600,
                    color: isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
                  ),
                ),
              ),
              Container(
                padding: adaptive.responsivePadding(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFf8f9ff),
                  borderRadius: adaptive.responsiveBorderRadius(20),
                ),
                child: Text(
                  course['code'],
                  style: TextStyle(
                    fontSize: adaptive.sp(14),
                    color: isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
                  ),
                ),
              ),
            ],
          ),
          
          SizedBox(height: adaptive.scale(12)),
          
          // Course Info
          Text(
            '${course['level']} • ${course['department']} • ${course['students']} Students',
            style: TextStyle(
              fontSize: adaptive.sp(14),
              color: isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
            ),
          ),
          
          SizedBox(height: adaptive.scale(16)),
          
          // Session Controls
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: () {
                    if (isActive) {
                      onStopSession(course['code']);
                    } else {
                      onStartSession(course['code']);
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isActive ? Colors.red : Colors.green,
                    padding: adaptive.responsivePadding(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: adaptive.responsiveBorderRadius(12),
                    ),
                  ),
                  child: Text(
                    isActive ? 'Stop Session' : 'Start Session',
                    style: TextStyle(
                      fontSize: adaptive.sp(14),
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              SizedBox(width: adaptive.scale(12)),
              Expanded(
                child: OutlinedButton(
                  onPressed: () {
                    if (isActive) {
                      onViewRealtime(course['code']);
                    } else {
                      onViewAttendance(course['code']);
                    }
                  },
                  style: OutlinedButton.styleFrom(
                    padding: adaptive.responsivePadding(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: adaptive.responsiveBorderRadius(12),
                    ),
                    side: BorderSide(
                      color: isDarkMode ? const Color(0xFF718096) : const Color(0xFFe5e7ff),
                    ),
                  ),
                  child: Text(
                    isActive ? 'View Live' : 'View Attendance',
                    style: TextStyle(
                      fontSize: adaptive.sp(14),
                      fontWeight: FontWeight.w600,
                      color: isDarkMode ? const Color(0xFFe2e8f0) : const Color(0xFF667eea),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
