import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../../utils/adaptive_screen_manager.dart';

class LecturerProfileTab extends StatefulWidget {
  final bool isDarkMode;
  final VoidCallback onToggleTheme;
  final VoidCallback onLogout;
  final String? profileImagePath;
  final Function(String?)? onProfileImageChanged;

  const LecturerProfileTab({
    super.key,
    required this.isDarkMode,
    required this.onToggleTheme,
    required this.onLogout,
    this.profileImagePath,
    this.onProfileImageChanged,
  });

  @override
  State<LecturerProfileTab> createState() => _LecturerProfileTabState();
}

class _LecturerProfileTabState extends State<LecturerProfileTab> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController(text: 'mbua.daniel@university.edu');
  final _phoneController = TextEditingController(text: '+237 650 123 456');
  final _currentPasswordController = TextEditingController();
  final _newPasswordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  
  bool _notificationsEnabled = true;
  bool _autoExportEnabled = false;
  bool _personalInfoExpanded = false;
  bool _appSettingsExpanded = false;
  bool _securityExpanded = false;

  @override
  void dispose() {
    _emailController.dispose();
    _phoneController.dispose();
    _currentPasswordController.dispose();
    _newPasswordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  void _changeProfilePicture() async {
    showModalBottomSheet(
      context: context,
      backgroundColor: widget.isDarkMode ? const Color(0xFF2d3748) : Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Change Profile Picture',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildImageOption(
                  icon: Icons.camera_alt,
                  label: 'Camera',
                  onTap: () => _pickImage(ImageSource.camera),
                ),
                _buildImageOption(
                  icon: Icons.photo_library,
                  label: 'Gallery',
                  onTap: () => _pickImage(ImageSource.gallery),
                ),
                _buildImageOption(
                  icon: Icons.delete,
                  label: 'Remove',
                  onTap: () => _removeImage(),
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildImageOption({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: () {
        Navigator.pop(context);
        onTap();
      },
      child: Column(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFf8f9ff),
              borderRadius: BorderRadius.circular(30),
            ),
            child: Icon(
              icon,
              color: widget.isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
              size: 30,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              fontSize: 14,
              color: widget.isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
            ),
          ),
        ],
      ),
    );
  }

  void _pickImage(ImageSource source) async {
    try {
      final ImagePicker picker = ImagePicker();
      final XFile? image = await picker.pickImage(source: source);
      
      if (image != null) {
        widget.onProfileImageChanged?.call(image.path);
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('Profile picture updated successfully'),
              backgroundColor: widget.isDarkMode ? const Color(0xFF4a5568) : Colors.green,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to pick image'),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }

  void _removeImage() {
    widget.onProfileImageChanged?.call(null);
    
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Profile picture removed'),
          backgroundColor: widget.isDarkMode ? const Color(0xFF4a5568) : Colors.green,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  void _updateProfile() {
    if (_formKey.currentState!.validate()) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Profile updated successfully'),
            backgroundColor: Colors.green,
          ),
        );
      }
    }
  }

  void _changePassword() {
    if (_currentPasswordController.text.isEmpty ||
        _newPasswordController.text.isEmpty ||
        _confirmPasswordController.text.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Please fill all password fields'),
            backgroundColor: Colors.red,
          ),
        );
      }
      return;
    }

    if (_newPasswordController.text != _confirmPasswordController.text) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('New passwords do not match'),
            backgroundColor: Colors.red,
          ),
        );
      }
      return;
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Password changed successfully'),
          backgroundColor: Colors.green,
        ),
      );
    }

    _currentPasswordController.clear();
    _newPasswordController.clear();
    _confirmPasswordController.clear();
  }

  void _confirmLogout() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: widget.isDarkMode ? const Color(0xFF2d3748) : Colors.white,
        title: Text(
          'Logout',
          style: TextStyle(
            color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
          ),
        ),
        content: Text(
          'Are you sure you want to logout?',
          style: TextStyle(
            color: widget.isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: TextStyle(
                color: widget.isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              widget.onLogout();
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Logout', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    
    return SingleChildScrollView(
      padding: adaptive.responsivePadding(all: 20, bottom: 100),
      child: Column(
        children: [
          _buildProfileHeader(adaptive),
          SizedBox(height: adaptive.scale(30)),
          _buildExpandableSection(
            'Personal Information',
            _personalInfoExpanded,
            () => setState(() => _personalInfoExpanded = !_personalInfoExpanded),
            _buildProfileForm(adaptive),
            adaptive,
          ),
          SizedBox(height: adaptive.scale(20)),
          _buildExpandableSection(
            'App Settings',
            _appSettingsExpanded,
            () => setState(() => _appSettingsExpanded = !_appSettingsExpanded),
            _buildAppSettings(adaptive),
            adaptive,
          ),
          SizedBox(height: adaptive.scale(20)),
          _buildExpandableSection(
            'Security',
            _securityExpanded,
            () => setState(() => _securityExpanded = !_securityExpanded),
            _buildPasswordSection(adaptive),
            adaptive,
          ),
          SizedBox(height: adaptive.scale(20)),
          _buildLogoutButton(adaptive),
        ],
      ),
    );
  }

  Widget _buildProfileHeader(AdaptiveScreenManager adaptive) {
    return Column(
      children: [
        GestureDetector(
          onTap: _changeProfilePicture,
          child: Stack(
            children: [
              Container(
                width: adaptive.scale(100),
                height: adaptive.scale(100),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: widget.isDarkMode 
                      ? const [Color(0xFF8b5cf6), Color(0xFF6366f1)]
                      : const [Color(0xFF667eea), Color(0xFF764ba2)],
                  ),
                  shape: BoxShape.circle,
                ),
                child: widget.profileImagePath != null
                    ? ClipOval(
                        child: Image.file(
                          File(widget.profileImagePath!),
                          fit: BoxFit.cover,
                          width: adaptive.scale(100),
                          height: adaptive.scale(100),
                          errorBuilder: (context, error, stackTrace) {
                            return Center(
                              child: Text(
                                'DM',
                                style: TextStyle(
                                  fontSize: adaptive.sp(36),
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            );
                          },
                        ),
                      )
                    : Center(
                        child: Text(
                          'DM',
                          style: TextStyle(
                            fontSize: adaptive.sp(36),
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
              ),
              Positioned(
                bottom: 0,
                right: 0,
                child: Container(
                  width: adaptive.scale(30),
                  height: adaptive.scale(30),
                  decoration: BoxDecoration(
                    color: widget.isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 2),
                  ),
                  child: Icon(
                    Icons.camera_alt,
                    color: Colors.white,
                    size: adaptive.sp(16),
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: adaptive.scale(16)),
        Text(
          'Dr. Mbua Daniel',
          style: TextStyle(
            fontSize: adaptive.sp(24),
            fontWeight: FontWeight.w600,
            color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
          ),
        ),
        SizedBox(height: adaptive.scale(8)),
        Text(
          'Lecturer ID: LEC001',
          style: TextStyle(
            fontSize: adaptive.sp(16),
            color: widget.isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
          ),
        ),
      ],
    );
  }

  Widget _buildExpandableSection(
    String title,
    bool isExpanded,
    VoidCallback onTap,
    Widget content,
    AdaptiveScreenManager adaptive,
  ) {
    return Container(
      decoration: BoxDecoration(
        color: widget.isDarkMode ? const Color(0xFF2d3748) : Colors.white,
        borderRadius: adaptive.responsiveBorderRadius(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x14000000),
            blurRadius: 20,
            offset: Offset(0, 4),
          ),
        ],
        border: widget.isDarkMode ? Border.all(color: const Color(0xFF4a5568)) : null,
      ),
      child: Column(
        children: [
          GestureDetector(
            onTap: onTap,
            child: Container(
              padding: adaptive.responsivePadding(all: 20),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      title,
                      style: TextStyle(
                        fontSize: adaptive.sp(18),
                        fontWeight: FontWeight.w600,
                        color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
                      ),
                    ),
                  ),
                  Icon(
                    isExpanded ? Icons.expand_less : Icons.expand_more,
                    color: widget.isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
                  ),
                ],
              ),
            ),
          ),
          if (isExpanded) ...[
            Divider(
              color: widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFe5e7eb),
              height: 1,
            ),
            Padding(
              padding: adaptive.responsivePadding(all: 20),
              child: content,
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildProfileForm(AdaptiveScreenManager adaptive) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          _buildFormField('Full Name', 'Dr. Mbua Daniel', null, true, adaptive),
          SizedBox(height: adaptive.scale(20)),
          _buildFormField('Lecturer ID', 'LEC001', null, true, adaptive),
          SizedBox(height: adaptive.scale(20)),
          _buildFormField('Email', null, _emailController, false, adaptive),
          SizedBox(height: adaptive.scale(20)),
          _buildFormField('Phone Number', null, _phoneController, false, adaptive),
          SizedBox(height: adaptive.scale(20)),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _updateProfile,
              style: ElevatedButton.styleFrom(
                backgroundColor: widget.isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
                padding: adaptive.responsivePadding(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: adaptive.responsiveBorderRadius(12),
                ),
              ),
              child: Text(
                'Update Profile',
                style: TextStyle(
                  fontSize: adaptive.sp(16),
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFormField(String label, String? value, TextEditingController? controller, bool readOnly, AdaptiveScreenManager adaptive) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: adaptive.sp(16),
            fontWeight: FontWeight.w600,
            color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
          ),
        ),
        SizedBox(height: adaptive.scale(8)),
        TextFormField(
          controller: controller,
          readOnly: readOnly,
          decoration: InputDecoration(
            hintText: value,
            filled: true,
            fillColor: widget.isDarkMode ? const Color(0xFF4a5568) : Colors.white,
            border: OutlineInputBorder(
              borderRadius: adaptive.responsiveBorderRadius(12),
              borderSide: BorderSide(
                color: widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFe5e7eb),
                width: 2,
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: adaptive.responsiveBorderRadius(12),
              borderSide: BorderSide(
                color: widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFe5e7eb),
                width: 2,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: adaptive.responsiveBorderRadius(12),
              borderSide: BorderSide(
                color: widget.isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
                width: 2,
              ),
            ),
          ),
          style: TextStyle(
            fontSize: adaptive.sp(16),
            color: widget.isDarkMode ? const Color(0xFFe2e8f0) : const Color(0xFF333333),
          ),
          validator: readOnly ? null : (value) {
            if (value == null || value.isEmpty) {
              return 'Please enter $label';
            }
            return null;
          },
        ),
      ],
    );
  }

  Widget _buildAppSettings(AdaptiveScreenManager adaptive) {
    return Column(
      children: [
        _buildSettingItem(
          'Dark Mode',
          'Switch between light and dark theme',
          widget.isDarkMode,
          widget.onToggleTheme,
          adaptive,
        ),
        _buildSettingItem(
          'Notifications',
          'Receive attendance alerts',
          _notificationsEnabled,
          () {
            setState(() {
              _notificationsEnabled = !_notificationsEnabled;
            });
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(_notificationsEnabled ? 'Notifications enabled' : 'Notifications disabled'),
                  backgroundColor: widget.isDarkMode ? const Color(0xFF4a5568) : Colors.green,
                  behavior: SnackBarBehavior.floating,
                ),
              );
            }
          },
          adaptive,
        ),
        _buildSettingItem(
          'Auto Export',
          'Automatically export attendance reports',
          _autoExportEnabled,
          () {
            setState(() {
              _autoExportEnabled = !_autoExportEnabled;
            });
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(_autoExportEnabled ? 'Auto export enabled' : 'Auto export disabled'),
                  backgroundColor: widget.isDarkMode ? const Color(0xFF4a5568) : Colors.green,
                  behavior: SnackBarBehavior.floating,
                ),
              );
            }
          },
          adaptive,
        ),
      ],
    );
  }

  Widget _buildSettingItem(String title, String description, bool value, VoidCallback onTap, AdaptiveScreenManager adaptive) {
    return Container(
      padding: adaptive.responsivePadding(vertical: 16),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFe5e7eb),
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: adaptive.sp(16),
                    fontWeight: FontWeight.w500,
                    color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
                  ),
                ),
                SizedBox(height: adaptive.scale(4)),
                Text(
                  description,
                  style: TextStyle(
                    fontSize: adaptive.sp(14),
                    color: widget.isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: onTap,
            child: Container(
              width: adaptive.scale(50),
              height: adaptive.scale(26),
              decoration: BoxDecoration(
                color: value 
                  ? (widget.isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea))
                  : (widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFe5e7eb)),
                borderRadius: adaptive.responsiveBorderRadius(13),
              ),
              child: AnimatedAlign(
                duration: const Duration(milliseconds: 200),
                alignment: value ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  width: adaptive.scale(22),
                  height: adaptive.scale(22),
                  margin: adaptive.responsiveMargin(all: 2),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x33000000),
                        blurRadius: 4,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPasswordSection(AdaptiveScreenManager adaptive) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildPasswordField('Current Password', _currentPasswordController, adaptive),
        SizedBox(height: adaptive.scale(16)),
        _buildPasswordField('New Password', _newPasswordController, adaptive),
        SizedBox(height: adaptive.scale(16)),
        _buildPasswordField('Confirm Password', _confirmPasswordController, adaptive),
        SizedBox(height: adaptive.scale(20)),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _changePassword,
            style: ElevatedButton.styleFrom(
              backgroundColor: widget.isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
              padding: adaptive.responsivePadding(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: adaptive.responsiveBorderRadius(12),
              ),
            ),
            child: Text(
              'Change Password',
              style: TextStyle(
                fontSize: adaptive.sp(16),
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPasswordField(String label, TextEditingController controller, AdaptiveScreenManager adaptive) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: adaptive.sp(16),
            fontWeight: FontWeight.w600,
            color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
          ),
        ),
        SizedBox(height: adaptive.scale(8)),
        TextFormField(
          controller: controller,
          obscureText: true,
          decoration: InputDecoration(
            hintText: 'Enter $label',
            filled: true,
            fillColor: widget.isDarkMode ? const Color(0xFF4a5568) : Colors.white,
            border: OutlineInputBorder(
              borderRadius: adaptive.responsiveBorderRadius(12),
              borderSide: BorderSide(
                color: widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFe5e7eb),
                width: 2,
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: adaptive.responsiveBorderRadius(12),
              borderSide: BorderSide(
                color: widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFe5e7eb),
                width: 2,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: adaptive.responsiveBorderRadius(12),
              borderSide: BorderSide(
                color: widget.isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
                width: 2,
              ),
            ),
          ),
          style: TextStyle(
            fontSize: adaptive.sp(16),
            color: widget.isDarkMode ? const Color(0xFFe2e8f0) : const Color(0xFF333333),
          ),
        ),
      ],
    );
  }

  Widget _buildLogoutButton(AdaptiveScreenManager adaptive) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: _confirmLogout,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.red,
          padding: adaptive.responsivePadding(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: adaptive.responsiveBorderRadius(12),
          ),
        ),
        child: Text(
          'Logout',
          style: TextStyle(
            fontSize: adaptive.sp(16),
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}
