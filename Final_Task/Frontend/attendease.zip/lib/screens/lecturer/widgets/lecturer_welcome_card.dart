import 'package:flutter/material.dart';
import '../../../utils/adaptive_screen_manager.dart';

class LecturerWelcomeCard extends StatelessWidget {
  final int currentIndex;
  final bool isDarkMode;
  final AdaptiveScreenManager adaptive;

  const LecturerWelcomeCard({
    super.key,
    required this.currentIndex,
    required this.isDarkMode,
    required this.adaptive,
  });

  String _getTitle() {
    switch (currentIndex) {
      case 0:
        return 'Dashboard';
      case 1:
        return 'My Courses';
      case 2:
        return 'Attendance Reports';
      case 3:
        return 'Profile Settings';
      default:
        return 'Dashboard';
    }
  }

  String _getSubtitle() {
    switch (currentIndex) {
      case 0:
        return 'Welcome back, Dr. Mbua';
      case 1:
        return 'Manage your assigned courses';
      case 2:
        return 'View and manage attendance';
      case 3:
        return 'Manage your account';
      default:
        return 'Welcome back, Dr. Mbua';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: adaptive.responsiveMargin(all: 20),
      padding: adaptive.responsivePadding(all: 20),
      width: double.infinity,
      decoration: BoxDecoration(
        color: const Color(0xFF667eea), // Consistent color regardless of theme
        borderRadius: adaptive.responsiveBorderRadius(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _getTitle(),
            style: TextStyle(
              fontSize: adaptive.sp(24),
              fontWeight: FontWeight.w600,
              color: Colors.white,
            ),
          ),
          SizedBox(height: adaptive.scale(8)),
          Text(
            _getSubtitle(),
            style: TextStyle(
              fontSize: adaptive.sp(16),
              color: Colors.white.withValues(alpha: 0.9),
            ),
          ),
        ],
      ),
    );
  }
}
