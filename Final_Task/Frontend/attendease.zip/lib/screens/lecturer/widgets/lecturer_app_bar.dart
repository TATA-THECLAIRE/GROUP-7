import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../../../utils/adaptive_screen_manager.dart';

class LecturerAppBar extends StatefulWidget {
  final bool isDarkMode;
  final ThemeMode themeMode;
  final VoidCallback onToggleTheme;
  final VoidCallback? onMenuTap;
  final VoidCallback? onProfileTap;
  final String? profileImagePath;
  final Function(String?)? onProfileImageChanged;

  const LecturerAppBar({
    super.key,
    required this.isDarkMode,
    required this.themeMode,
    required this.onToggleTheme,
    this.onMenuTap,
    this.onProfileTap,
    this.profileImagePath,
    this.onProfileImageChanged,
  });

  @override
  State<LecturerAppBar> createState() => _LecturerAppBarState();
}

class _LecturerAppBarState extends State<LecturerAppBar> {
  void _showProfileOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: widget.isDarkMode ? const Color(0xFF2d3748) : Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Profile Options',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildProfileOption(
                  icon: Icons.camera_alt,
                  label: 'Camera',
                  onTap: () => _pickProfileImage(ImageSource.camera),
                ),
                _buildProfileOption(
                  icon: Icons.photo_library,
                  label: 'Gallery',
                  onTap: () => _pickProfileImage(ImageSource.gallery),
                ),
                _buildProfileOption(
                  icon: Icons.person,
                  label: 'View Profile',
                  onTap: () => widget.onProfileTap?.call(),
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileOption({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: () {
        Navigator.pop(context);
        onTap();
      },
      child: Column(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFf8f9ff),
              borderRadius: BorderRadius.circular(30),
            ),
            child: Icon(
              icon,
              color: widget.isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
              size: 30,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              fontSize: 14,
              color: widget.isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
            ),
          ),
        ],
      ),
    );
  }

  void _pickProfileImage(ImageSource source) async {
    try {
      final ImagePicker picker = ImagePicker();
      final XFile? image = await picker.pickImage(source: source);
      
      if (image != null) {
        widget.onProfileImageChanged?.call(image.path);
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('Profile picture updated successfully'),
              backgroundColor: widget.isDarkMode ? const Color(0xFF4a5568) : Colors.green,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Failed to pick image'),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    
    return Container(
      padding: adaptive.responsivePadding(horizontal: 20, vertical: 8),
      decoration: const BoxDecoration(
        color: Color(0xFF667eea), // Consistent color regardless of theme
        border: null,
      ),
      child: Row(
        children: [
          // Logo
          Container(
            width: adaptive.scale(36),
            height: adaptive.scale(36),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: adaptive.responsiveBorderRadius(8),
            ),
            child: ClipRRect(
              borderRadius: adaptive.responsiveBorderRadius(8),
              child: Image.asset(
                'assets/images/logo.png',
                width: adaptive.scale(36),
                height: adaptive.scale(36),
                fit: BoxFit.contain,
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    width: adaptive.scale(36),
                    height: adaptive.scale(36),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: adaptive.responsiveBorderRadius(8),
                    ),
                    child: Center(
                      child: Text(
                        'AE',
                        style: TextStyle(
                          color: const Color(0xFF667eea),
                          fontSize: adaptive.sp(14),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          SizedBox(width: adaptive.scale(12)),

      // Theme toggle
          GestureDetector(
            onTap: widget.onToggleTheme,
            child: Container(
              width: adaptive.scale(36),
              height: adaptive.scale(36),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Center(
                child: Icon(
                  widget.themeMode == ThemeMode.light 
                      ? Icons.light_mode 
                      : widget.themeMode == ThemeMode.dark 
                      ? Icons.dark_mode 
                      : Icons.brightness_auto,
                  color: Colors.white,
                  size: adaptive.responsiveIconSize(18),
                ),
              ),
            ),
          ),
          SizedBox(width: adaptive.scale(8)),
          // Profile icon
          GestureDetector(
            onTap: _showProfileOptions,
            child: Container(
              width: adaptive.scale(36),
              height: adaptive.scale(36),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.white.withValues(alpha: 0.3), width: 1),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: widget.profileImagePath != null
                    ? Image.file(
                        File(widget.profileImagePath!),
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Icon(
                            Icons.person,
                            color: Colors.white,
                            size: adaptive.responsiveIconSize(20),
                          );
                        },
                      )
                    : Icon(
                        Icons.person,
                        color: Colors.white,
                        size: adaptive.responsiveIconSize(20),
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
