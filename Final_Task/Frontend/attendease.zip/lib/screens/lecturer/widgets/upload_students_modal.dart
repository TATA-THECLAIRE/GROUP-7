import 'package:flutter/material.dart';
import '../../../utils/adaptive_screen_manager.dart';

class UploadStudentsModal extends StatefulWidget {
  final String courseCode;
  final bool isDarkMode;
  final VoidCallback onConfirm;

  const UploadStudentsModal({
    super.key,
    required this.courseCode,
    required this.isDarkMode,
    required this.onConfirm,
  });

  @override
  State<UploadStudentsModal> createState() => _UploadStudentsModalState();
}

class _UploadStudentsModalState extends State<UploadStudentsModal> {
  bool _isUploading = false;

  void _handleUpload() async {
    setState(() {
      _isUploading = true;
    });

    // Simulate upload process
    await Future.delayed(const Duration(seconds: 2));

    if (mounted) {
      setState(() {
        _isUploading = false;
      });
      Navigator.of(context).pop();
      widget.onConfirm();
    }
  }

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        decoration: BoxDecoration(
          color: widget.isDarkMode ? const Color(0xFF2d3748) : Colors.white,
          borderRadius: adaptive.responsiveBorderRadius(16),
          border: widget.isDarkMode ? Border.all(color: const Color(0xFF4a5568)) : null,
        ),
        padding: adaptive.responsivePadding(all: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: adaptive.responsivePadding(all: 8),
                  decoration: BoxDecoration(
                    color: widget.isDarkMode 
                      ? const Color(0xFF8b5cf6).withValues(alpha: 0.1)
                      : const Color(0xFF667eea).withValues(alpha: 0.1),
                    borderRadius: adaptive.responsiveBorderRadius(8),
                  ),
                  child: Icon(
                    Icons.upload_file,
                    color: widget.isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
                    size: adaptive.responsiveIconSize(24),
                  ),
                ),
                SizedBox(width: adaptive.scale(12)),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Upload Student List',
                        style: TextStyle(
                          fontSize: adaptive.sp(18),
                          fontWeight: FontWeight.w600,
                          color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
                        ),
                      ),
                      Text(
                        widget.courseCode,
                        style: TextStyle(
                          fontSize: adaptive.sp(14),
                          color: widget.isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: adaptive.scale(24)),
            
            Container(
              width: double.infinity,
              padding: adaptive.responsivePadding(all: 20),
              decoration: BoxDecoration(
                color: widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFf8f9ff),
                borderRadius: adaptive.responsiveBorderRadius(12),
                border: Border.all(
                  color: widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFe5e7eb),
                  style: BorderStyle.solid,
                ),
              ),
              child: Column(
                children: [
                  Icon(
                    Icons.cloud_upload_outlined,
                    size: adaptive.responsiveIconSize(48),
                    color: widget.isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
                  ),
                  SizedBox(height: adaptive.scale(12)),
                  Text(
                    'Drop CSV file here or click to browse',
                    style: TextStyle(
                      fontSize: adaptive.sp(16),
                      fontWeight: FontWeight.w500,
                      color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: adaptive.scale(8)),
                  Text(
                    'Supported format: CSV with columns: Name, Matricle Number, Email',
                    style: TextStyle(
                      fontSize: adaptive.sp(14),
                      color: widget.isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            
            SizedBox(height: adaptive.scale(24)),
            
            Row(
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: _isUploading ? null : () => Navigator.of(context).pop(),
                    style: TextButton.styleFrom(
                      padding: adaptive.responsivePadding(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: adaptive.responsiveBorderRadius(12),
                        side: BorderSide(
                          color: widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFe5e7eb),
                        ),
                      ),
                    ),
                    child: Text(
                      'Cancel',
                      style: TextStyle(
                        fontSize: adaptive.sp(16),
                        fontWeight: FontWeight.w500,
                        color: widget.isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
                      ),
                    ),
                  ),
                ),
                SizedBox(width: adaptive.scale(12)),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _isUploading ? null : _handleUpload,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: widget.isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
                      foregroundColor: Colors.white,
                      padding: adaptive.responsivePadding(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: adaptive.responsiveBorderRadius(12),
                      ),
                    ),
                    child: _isUploading
                        ? SizedBox(
                            height: adaptive.scale(20),
                            width: adaptive.scale(20),
                            child: const CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : Text(
                            'Upload',
                            style: TextStyle(
                              fontSize: adaptive.sp(16),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
