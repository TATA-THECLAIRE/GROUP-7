import 'package:flutter/material.dart';
import '../../../utils/adaptive_screen_manager.dart';

class SessionStartModal extends StatefulWidget {
  final String courseCode;
  final bool isDarkMode;
  final Function(String) onConfirm;

  const SessionStartModal({
    super.key,
    required this.courseCode,
    required this.isDarkMode,
    required this.onConfirm,
  });

  @override
  State<SessionStartModal> createState() => _SessionStartModalState();
}

class _SessionStartModalState extends State<SessionStartModal> {
  String? _selectedLocation;
  
  final List<String> _locations = [
    'Amphitheatre 1',
    'Amphitheatre 2',
    'Computer Lab 1',
    'Computer Lab 2',
    'Room 101',
    'Room 102',
  ];

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        decoration: BoxDecoration(
          color: widget.isDarkMode ? const Color(0xFF2d3748) : Colors.white,
          borderRadius: adaptive.responsiveBorderRadius(16),
          border: widget.isDarkMode ? Border.all(color: const Color(0xFF4a5568)) : null,
        ),
        padding: adaptive.responsivePadding(all: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: adaptive.responsivePadding(all: 8),
                  decoration: BoxDecoration(
                    color: widget.isDarkMode 
                      ? const Color(0xFF8b5cf6).withValues(alpha: 0.1)
                      : const Color(0xFF667eea).withValues(alpha: 0.1),
                    borderRadius: adaptive.responsiveBorderRadius(8),
                  ),
                  child: Icon(
                    Icons.play_circle_outline,
                    color: widget.isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
                    size: adaptive.responsiveIconSize(24),
                  ),
                ),
                SizedBox(width: adaptive.scale(12)),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Start Attendance Session',
                        style: TextStyle(
                          fontSize: adaptive.sp(18),
                          fontWeight: FontWeight.w600,
                          color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
                        ),
                      ),
                      Text(
                        widget.courseCode,
                        style: TextStyle(
                          fontSize: adaptive.sp(14),
                          color: widget.isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: adaptive.scale(24)),
            
            Text(
              'Select Location',
              style: TextStyle(
                fontSize: adaptive.sp(16),
                fontWeight: FontWeight.w500,
                color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
              ),
            ),
            SizedBox(height: adaptive.scale(12)),
            
            Container(
              padding: adaptive.responsivePadding(horizontal: 16, vertical: 4),
              decoration: BoxDecoration(
                color: widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFf8f9ff),
                border: Border.all(
                  color: widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFe5e7eb),
                  width: 2,
                ),
                borderRadius: adaptive.responsiveBorderRadius(12),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: _selectedLocation,
                  hint: Text(
                    'Choose classroom or location',
                    style: TextStyle(
                      color: widget.isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
                    ),
                  ),
                  isExpanded: true,
                  dropdownColor: widget.isDarkMode ? const Color(0xFF2d3748) : Colors.white,
                  style: TextStyle(
                    color: widget.isDarkMode ? const Color(0xFFe2e8f0) : const Color(0xFF333333),
                    fontSize: adaptive.sp(16),
                  ),
                  items: _locations.map((location) {
                    return DropdownMenuItem<String>(
                      value: location,
                      child: Text(location),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedLocation = value;
                    });
                  },
                ),
              ),
            ),
            
            SizedBox(height: adaptive.scale(24)),
            
            Text(
              'Students will be notified to check in once the session starts.',
              style: TextStyle(
                fontSize: adaptive.sp(14),
                color: widget.isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
              ),
            ),
            
            SizedBox(height: adaptive.scale(24)),
            
            Row(
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    style: TextButton.styleFrom(
                      padding: adaptive.responsivePadding(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: adaptive.responsiveBorderRadius(12),
                        side: BorderSide(
                          color: widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFe5e7eb),
                        ),
                      ),
                    ),
                    child: Text(
                      'Cancel',
                      style: TextStyle(
                        fontSize: adaptive.sp(16),
                        fontWeight: FontWeight.w500,
                        color: widget.isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
                      ),
                    ),
                  ),
                ),
                SizedBox(width: adaptive.scale(12)),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _selectedLocation != null
                        ? () {
                            Navigator.of(context).pop();
                            widget.onConfirm(_selectedLocation!);
                          }
                        : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: widget.isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
                      foregroundColor: Colors.white,
                      padding: adaptive.responsivePadding(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: adaptive.responsiveBorderRadius(12),
                      ),
                    ),
                    child: Text(
                      'Start Session',
                      style: TextStyle(
                        fontSize: adaptive.sp(16),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
