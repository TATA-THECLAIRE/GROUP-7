import 'package:flutter/material.dart';
import 'lecturer_interface_screen.dart';

class LecturerDashboardScreen extends StatelessWidget {
  final bool isFromSignup;

  const LecturerDashboardScreen({super.key, required this.isFromSignup});

  @override
  Widget build(BuildContext context) {
    return LecturerInterfaceScreen(isFromSignup: isFromSignup);
  }
}
