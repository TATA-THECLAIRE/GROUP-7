import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import '../../models/user_role.dart';
import '../../utils/adaptive_screen_manager.dart';
import 'lecturer_dashboard_tab.dart';
import 'lecturer_courses_tab.dart';
import 'lecturer_attendance_tab.dart';
import 'lecturer_profile_tab.dart';
import 'widgets/session_start_modal.dart';
import 'widgets/upload_students_modal.dart';
import 'widgets/lecturer_app_bar.dart';

class LecturerInterfaceScreen extends StatefulWidget {
  final bool isFromSignup;

  const LecturerInterfaceScreen({
    super.key,
    this.isFromSignup = false,
  });

  @override
  State<LecturerInterfaceScreen> createState() => _LecturerInterfaceScreenState();
}

class _LecturerInterfaceScreenState extends State<LecturerInterfaceScreen> with TickerProviderStateMixin {
  int _currentIndex = 0;
  ThemeMode _themeMode = ThemeMode.system;
  late TabController _tabController;
  DateTime? _lastBackPressed;
  
  // Session management
  final Map<String, bool> _activeSessions = {};
  final Map<String, int> _sessionStats = {
    'totalCourses': 5,
    'totalStudents': 142,
  };

  final List<Map<String, dynamic>> _courses = [
    {
      'title': 'Software Engineering',
      'code': 'CSC301',
      'level': 'Level 300',
      'department': 'Computer Science',
      'students': 45,
      'isActive': false,
    },
    {
      'title': 'Database Systems',
      'code': 'CSC302',
      'level': 'Level 300',
      'department': 'Computer Science',
      'students': 38,
      'isActive': false,
    },
    {
      'title': 'Data Structures',
      'code': 'CSC201',
      'level': 'Level 200',
      'department': 'Computer Science',
      'students': 59,
      'isActive': true,
    },
  ];

  String? _profileImagePath;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _activeSessions['CSC201'] = true;
    
    if (widget.isFromSignup) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _showWelcomeMessage();
      });
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  bool get _isDarkMode {
    switch (_themeMode) {
      case ThemeMode.light:
        return false;
      case ThemeMode.dark:
        return true;
      case ThemeMode.system:
        return MediaQuery.of(context).platformBrightness == Brightness.dark;
    }
  }

  void _showWelcomeMessage() {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Welcome to your lecturer dashboard!'),
          backgroundColor: UserRole.lecturer.primaryColor,
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  void _toggleTheme() {
    setState(() {
      switch (_themeMode) {
        case ThemeMode.light:
          _themeMode = ThemeMode.dark;
          break;
        case ThemeMode.dark:
          _themeMode = ThemeMode.system;
          break;
        case ThemeMode.system:
          _themeMode = ThemeMode.light;
          break;
      }
    });
    
    String message;
    switch (_themeMode) {
      case ThemeMode.light:
        message = 'Light mode activated';
        break;
      case ThemeMode.dark:
        message = 'Dark mode activated';
        break;
      case ThemeMode.system:
        message = 'System default theme activated';
        break;
    }
    
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: Colors.green,
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  Future<bool> _onWillPop() async {
    // If not on dashboard tab, navigate back to dashboard instead of exiting
    if (_currentIndex != 0) {
      setState(() {
        _currentIndex = 0;
        _tabController.animateTo(0);
      });
      return false;
    }
    
    // Only on dashboard tab - show double-tap exit message
    final now = DateTime.now();
    if (_lastBackPressed == null || now.difference(_lastBackPressed!) > const Duration(seconds: 2)) {
      _lastBackPressed = now;
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Press back again to go to homepage'),
            duration: const Duration(seconds: 2),
            backgroundColor: _isDarkMode ? const Color(0xFF4a5568) : Colors.grey[600],
          ),
        );
      }
      return false;
    }
    
    // Navigate to homepage instead of exiting app
    if (mounted) {
      Navigator.pushNamedAndRemoveUntil(
        context, 
        '/', 
        (route) => false,
      );
    }
    return false;
  }

  void _startSession(String courseCode) {
    showDialog(
      context: context,
      builder: (context) => Theme(
        data: _isDarkMode ? _buildDarkTheme() : _buildLightTheme(),
        child: SessionStartModal(
          courseCode: courseCode,
          isDarkMode: _isDarkMode,
          onConfirm: (classroom) {
            setState(() {
              _activeSessions[courseCode] = true;
            });
            
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Session started successfully for $courseCode in $classroom'),
                  backgroundColor: Colors.green,
                ),
              );
              
              Future.delayed(const Duration(seconds: 1), () {
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Students have been notified to check in'),
                      backgroundColor: Colors.green,
                    ),
                  );
                }
              });
            }
          },
        ),
      ),
    );
  }

  void _stopSession(String courseCode) {
    showDialog(
      context: context,
      builder: (context) => Theme(
        data: _isDarkMode ? _buildDarkTheme() : _buildLightTheme(),
        child: AlertDialog(
          backgroundColor: _isDarkMode ? const Color(0xFF2d3748) : Colors.white,
          title: Text(
            'Stop Session',
            style: TextStyle(
              color: _isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
            ),
          ),
          content: Text(
            'Are you sure you want to stop the attendance session?',
            style: TextStyle(
              color: _isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                'Cancel',
                style: TextStyle(
                  color: _isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  _activeSessions[courseCode] = false;
                });
                
                Navigator.pop(context);
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Session stopped for $courseCode'),
                      backgroundColor: Colors.green,
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              child: const Text('Stop Session', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  void _viewAttendance(String courseCode) {
    setState(() {
      _currentIndex = 2;
      _tabController.animateTo(2);
    });
  }

  void _viewRealtime(String courseCode) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Theme(
          data: _isDarkMode ? _buildDarkTheme() : _buildLightTheme(),
          child: LecturerRealtimeScreen(
            courseCode: courseCode,
            courseName: _courses.firstWhere((c) => c['code'] == courseCode)['title'],
            isDarkMode: _isDarkMode,
            // Pass the theme mode for consistent app bar
            themeMode: _themeMode,
          ),
        ),
      ),
    );
  }

  void _uploadStudents(String courseCode) {
    showDialog(
      context: context,
      builder: (context) => Theme(
        data: _isDarkMode ? _buildDarkTheme() : _buildLightTheme(),
        child: UploadStudentsModal(
          courseCode: courseCode,
          isDarkMode: _isDarkMode,
          onConfirm: () {
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Student list uploaded successfully for $courseCode'),
                  backgroundColor: Colors.green,
                ),
              );
            }
          },
        ),
      ),
    );
  }

  void _manageStudents(String courseCode) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Managing students for $courseCode'),
          backgroundColor: Colors.blue,
        ),
      );
    }
  }

  void _showProfileOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: _isDarkMode ? const Color(0xFF2d3748) : Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Profile Options',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: _isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildProfileOption(
                  icon: Icons.camera_alt,
                  label: 'Camera',
                  onTap: () => _pickProfileImage(ImageSource.camera),
                ),
                _buildProfileOption(
                  icon: Icons.photo_library,
                  label: 'Gallery',
                  onTap: () => _pickProfileImage(ImageSource.gallery),
                ),
                _buildProfileOption(
                  icon: Icons.person,
                  label: 'View Profile',
                  onTap: () => _goToProfile(),
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileOption({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: () {
        Navigator.pop(context);
        onTap();
      },
      child: Column(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: _isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFf8f9ff),
              borderRadius: BorderRadius.circular(30),
            ),
            child: Icon(
              icon,
              color: _isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
              size: 30,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              fontSize: 14,
              color: _isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
            ),
          ),
        ],
      ),
    );
  }

  void _pickProfileImage(ImageSource source) async {
    try {
      final ImagePicker picker = ImagePicker();
      final XFile? image = await picker.pickImage(source: source);
      
      if (image != null) {
        setState(() {
          _profileImagePath = image.path;
        });
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Profile picture updated successfully'),
              backgroundColor: Colors.green,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to pick image'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _goToProfile() {
    setState(() {
      _currentIndex = 3;
      _tabController.animateTo(3);
    });
  }

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (!didPop) {
          final shouldPop = await _onWillPop();
          if (shouldPop && _currentIndex != 0 && mounted) {
            Navigator.of(context).pop();
          }
        }
      },
      child: Theme(
        data: _isDarkMode ? _buildDarkTheme() : _buildLightTheme(),
        child: Scaffold(
          backgroundColor: _isDarkMode ? const Color(0xFF1a1a2e) : Colors.white,
          body: SafeArea(
            child: Column(
              children: [
                _buildAppBar(adaptive),
                Expanded(
                  child: Container(
                    color: _isDarkMode ? const Color(0xFF1a1a2e) : Colors.white,
                    child: Column(
                      children: [
                        // Welcome Card with proper margins and consistent color
                        Container(
                          margin: adaptive.responsiveMargin(all: 20),
                          padding: adaptive.responsivePadding(all: 20),
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: const Color(0xFF667eea), // Same color as app bar
                            borderRadius: adaptive.responsiveBorderRadius(16),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.1),
                                blurRadius: 20,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _getWelcomeTitle(),
                                style: TextStyle(
                                  fontSize: adaptive.sp(24),
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white,
                                ),
                              ),
                              SizedBox(height: adaptive.scale(8)),
                              Text(
                                _getWelcomeSubtitle(),
                                style: TextStyle(
                                  fontSize: adaptive.sp(16),
                                  color: Colors.white.withValues(alpha: 0.9),
                                ),
                              ),
                            ],
                          ),
                        ),
                        // Tab content
                        Expanded(
                          child: TabBarView(
                            controller: _tabController,
                            children: [
                              LecturerDashboardTab(
                                courses: _courses,
                                activeSessions: _activeSessions,
                                sessionStats: _sessionStats,
                                onStartSession: _startSession,
                                onStopSession: _stopSession,
                                onViewAttendance: _viewAttendance,
                                onViewRealtime: _viewRealtime,
                                isDarkMode: _isDarkMode,
                              ),
                              LecturerCoursesTab(
                                courses: _courses,
                                onUploadStudents: _uploadStudents,
                                onManageStudents: _manageStudents,
                                isDarkMode: _isDarkMode,
                              ),
                              LecturerAttendanceTab(
                                courses: _courses,
                                isDarkMode: _isDarkMode,
                              ),
                              LecturerProfileTab(
                                isDarkMode: _isDarkMode,
                                onToggleTheme: _toggleTheme,
                                profileImagePath: _profileImagePath,
                                onProfileImageChanged: (imagePath) {
                                  setState(() {
                                    _profileImagePath = imagePath;
                                  });
                                },
                                onLogout: () {
                                  // Navigate to home page and clear all routes
                                  Navigator.pushNamedAndRemoveUntil(
                                    context, 
                                    '/', 
                                    (route) => false,
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          bottomNavigationBar: _buildBottomNavigation(adaptive),
        ),
      ),
    );
  }

  Widget _buildAppBar(AdaptiveScreenManager adaptive) {
    return LecturerAppBar(
      isDarkMode: _isDarkMode,
      themeMode: _themeMode,
      onToggleTheme: _toggleTheme,
      profileImagePath: _profileImagePath,
      onProfileImageChanged: (imagePath) {
        setState(() {
          _profileImagePath = imagePath;
        });
      },
      onProfileTap: () {
        setState(() {
          _currentIndex = 3;
          _tabController.animateTo(3);
        });
      },
    );
  }

  Widget _buildBottomNavigation(AdaptiveScreenManager adaptive) {
    return Container(
      decoration: BoxDecoration(
        color: _isDarkMode ? const Color(0xFF2d3748) : Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: _isDarkMode ? 0.3 : 0.1),
            blurRadius: 20,
            offset: const Offset(0, -4),
          ),
        ],
        border: Border(
          top: BorderSide(
            color: _isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFf0f0f0),
          ),
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: adaptive.responsivePadding(vertical: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildNavItem(0, '🏠', 'Dashboard', adaptive),
              _buildNavItem(1, '📚', 'Courses', adaptive),
              _buildNavItem(2, '📊', 'Reports', adaptive),
              _buildNavItem(3, '👤', 'Profile', adaptive),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(int index, String emoji, String label, AdaptiveScreenManager adaptive) {
    final isActive = _currentIndex == index;
    
    return GestureDetector(
      onTap: () {
        setState(() {
          _currentIndex = index;
          _tabController.animateTo(index);
        });
      },
      child: Container(
        padding: adaptive.responsivePadding(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: isActive 
            ? (_isDarkMode 
                ? const Color(0xFF8b5cf6).withValues(alpha: 0.1)
                : const Color(0xFFf8f9ff))
            : Colors.transparent,
          borderRadius: adaptive.responsiveBorderRadius(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              emoji,
              style: TextStyle(fontSize: adaptive.sp(24)),
            ),
            SizedBox(height: adaptive.scale(4)),
            Text(
              label,
              style: TextStyle(
                fontSize: adaptive.sp(12),
                fontWeight: FontWeight.w500,
                color: isActive 
                  ? (_isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea))
                  : (_isDarkMode ? const Color(0xFFe2e8f0) : const Color(0xFF333333)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  ThemeData _buildLightTheme() {
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.light,
      ),
    );
    
    return ThemeData(
      primarySwatch: Colors.deepPurple,
      primaryColor: const Color(0xFF667eea),
      scaffoldBackgroundColor: Colors.white,
      cardColor: Colors.white,
      dialogTheme: const DialogThemeData(
        backgroundColor: Colors.white,
      ),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: Color(0xFF333333)),
        bodyMedium: TextStyle(color: Color(0xFF666666)),
      ),
    );
  }

  ThemeData _buildDarkTheme() {
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.dark,
      ),
    );
    
    return ThemeData(
      primarySwatch: Colors.deepPurple,
      primaryColor: const Color(0xFF8b5cf6),
      scaffoldBackgroundColor: const Color(0xFF1a1a2e),
      cardColor: const Color(0xFF2d3748),
      dialogTheme: const DialogThemeData(
        backgroundColor: Color(0xFF2d3748),
      ),
      inputDecorationTheme: const InputDecorationTheme(
        hintStyle: TextStyle(color: Color(0xFFa0aec0)),
        labelStyle: TextStyle(color: Color(0xFFe2e8f0)),
        fillColor: Color(0xFF4a5568),
        filled: true,
      ),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: Color(0xFFe2e8f0)),
        bodyMedium: TextStyle(color: Color(0xFFa0aec0)),
      ),
    );
  }

  String _getWelcomeTitle() {
    switch (_currentIndex) {
      case 0:
        return 'Dashboard';
      case 1:
        return 'My Courses';
      case 2:
        return 'Attendance Reports';
      case 3:
        return 'Profile Settings';
      default:
        return 'Dashboard';
    }
  }

  String _getWelcomeSubtitle() {
    switch (_currentIndex) {
      case 0:
        return 'Welcome back, Dr. Mbua';
      case 1:
        return 'Manage your assigned courses';
      case 2:
        return 'View and manage attendance';
      case 3:
        return 'Manage your account';
      default:
        return 'Welcome back, Dr. Mbua';
    }
  }
}

// Real-time attendance screen
class LecturerRealtimeScreen extends StatefulWidget {
  final String courseCode;
  final String courseName;
  final bool isDarkMode;
  final ThemeMode? themeMode;

  const LecturerRealtimeScreen({
    super.key,
    required this.courseCode,
    required this.courseName,
    required this.isDarkMode,
    this.themeMode,
  });

  @override
  State<LecturerRealtimeScreen> createState() => _LecturerRealtimeScreenState();
}

class _LecturerRealtimeScreenState extends State<LecturerRealtimeScreen> {
  final int _checkedIn = 23;
  final int _expected = 36;
  
  final List<Map<String, dynamic>> _recentCheckIns = [
    {'name': 'Tabe Mercy', 'matricle': 'FE19A001', 'status': 'present'},
    {'name': 'Ngozi Paul', 'matricle': 'FE19A002', 'status': 'checking'},
    {'name': 'Fon Sandra', 'matricle': 'FE19A003', 'status': 'present'},
  ];

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: widget.isDarkMode 
              ? const [Color(0xFF1a1a2e), Color(0xFF16213e)]
              : const [Color(0xFF667eea), Color(0xFF764ba2)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildRealtimeHeader(adaptive),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: widget.isDarkMode ? const Color(0xFF1a1a2e) : Colors.white,
                  ),
                  child: _buildRealtimeContent(adaptive),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRealtimeHeader(AdaptiveScreenManager adaptive) {
    return Container(
      padding: adaptive.responsivePadding(horizontal: 20, vertical: 20),
      child: Column(
        children: [
          Row(
            children: [
              // Add logo first
              Container(
                width: adaptive.scale(36),
                height: adaptive.scale(36),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: adaptive.responsiveBorderRadius(8),
                ),
                child: ClipRRect(
                  borderRadius: adaptive.responsiveBorderRadius(8),
                  child: Image.asset(
                    'assets/images/logo.png',
                    width: adaptive.scale(36),
                    height: adaptive.scale(36),
                    fit: BoxFit.contain,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        width: adaptive.scale(36),
                        height: adaptive.scale(36),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: adaptive.responsiveBorderRadius(8),
                        ),
                        child: Center(
                          child: Text(
                            'AE',
                            style: TextStyle(
                              color: const Color(0xFF667eea),
                              fontSize: adaptive.sp(14),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
              SizedBox(width: adaptive.scale(12)),
              // Back button
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: adaptive.scale(40),
                  height: adaptive.scale(40),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    borderRadius: adaptive.responsiveBorderRadius(8),
                  ),
                  child: Icon(
                    Icons.arrow_back,
                    color: Colors.white,
                    size: adaptive.responsiveIconSize(24),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: adaptive.scale(20)),
          Column(
            children: [
              Text(
                'Live Attendance',
                style: TextStyle(
                  fontSize: adaptive.sp(28),
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: adaptive.scale(8)),
              Text(
                '${widget.courseName} - ${widget.courseCode}',
                style: TextStyle(
                  fontSize: adaptive.sp(16),
                  color: Colors.white.withValues(alpha: 0.9),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildRealtimeContent(AdaptiveScreenManager adaptive) {
    return Padding(
      padding: adaptive.responsivePadding(all: 20),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: _buildStatCard('$_checkedIn', 'Checked In', adaptive),
              ),
              SizedBox(width: adaptive.scale(16)),
              Expanded(
                child: _buildStatCard('$_expected', 'Expected', adaptive),
              ),
            ],
          ),
          SizedBox(height: adaptive.scale(20)),
          
          Expanded(
            child: Container(
              padding: adaptive.responsivePadding(all: 20),
              decoration: BoxDecoration(
                color: widget.isDarkMode ? const Color(0xFF2d3748) : Colors.white,
                borderRadius: adaptive.responsiveBorderRadius(16),
                border: widget.isDarkMode ? Border.all(color: const Color(0xFF4a5568)) : null,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: widget.isDarkMode ? 0.3 : 0.08),
                    blurRadius: 20,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Recent Check-ins',
                    style: TextStyle(
                      fontSize: adaptive.sp(18),
                      fontWeight: FontWeight.w600,
                      color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
                    ),
                  ),
                  SizedBox(height: adaptive.scale(16)),
                  Expanded(
                    child: ListView.builder(
                      itemCount: _recentCheckIns.length,
                      itemBuilder: (context, index) {
                        final student = _recentCheckIns[index];
                        return _buildAttendanceItem(student, adaptive);
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          SizedBox(height: adaptive.scale(20)),
          
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    backgroundColor: widget.isDarkMode ? const Color(0xFF2d3748) : Colors.white,
                    title: Text(
                      'Stop Session',
                      style: TextStyle(
                        color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
                      ),
                    ),
                    content: Text(
                      'Are you sure you want to stop the attendance session?',
                      style: TextStyle(
                        color: widget.isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
                      ),
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text(
                          'Cancel',
                          style: TextStyle(
                            color: widget.isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
                          ),
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                          Navigator.pop(context);
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('Session stopped for ${widget.courseCode}'),
                                backgroundColor: Colors.green,
                              ),
                            );
                          }
                        },
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                        child: const Text('Stop Session', style: TextStyle(color: Colors.white)),
                      ),
                    ],
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                padding: adaptive.responsivePadding(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: adaptive.responsiveBorderRadius(12),
                ),
              ),
              child: Text(
                'Stop Session',
                style: TextStyle(
                  fontSize: adaptive.sp(16),
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String number, String label, AdaptiveScreenManager adaptive) {
    return Container(
      padding: adaptive.responsivePadding(all: 20),
      decoration: BoxDecoration(
        color: widget.isDarkMode ? const Color(0xFF2d3748) : Colors.white,
        borderRadius: adaptive.responsiveBorderRadius(16),
        border: widget.isDarkMode ? Border.all(color: const Color(0xFF4a5568)) : null,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: widget.isDarkMode ? 0.3 : 0.08),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            number,
            style: TextStyle(
              fontSize: adaptive.sp(32),
              fontWeight: FontWeight.bold,
              color: widget.isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
            ),
          ),
          SizedBox(height: adaptive.scale(8)),
          Text(
            label,
            style: TextStyle(
              fontSize: adaptive.sp(14),
              color: widget.isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAttendanceItem(Map<String, dynamic> student, AdaptiveScreenManager adaptive) {
    return Container(
      margin: adaptive.responsiveMargin(bottom: 12),
      padding: adaptive.responsivePadding(all: 16),
      decoration: BoxDecoration(
        color: widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFf8f9ff),
        borderRadius: adaptive.responsiveBorderRadius(12),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  student['name'],
                  style: TextStyle(
                    fontSize: adaptive.sp(16),
                    fontWeight: FontWeight.w600,
                    color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
                  ),
                ),
                SizedBox(height: adaptive.scale(4)),
                Text(
                  student['matricle'],
                  style: TextStyle(
                    fontSize: adaptive.sp(14),
                    color: widget.isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: adaptive.responsivePadding(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: student['status'] == 'present' 
                ? const Color(0xFFdcfce7)
                : const Color(0xFFfef3c7),
              borderRadius: adaptive.responsiveBorderRadius(20),
            ),
            child: Text(
              student['status'] == 'present' ? 'Present' : 'Checking...',
              style: TextStyle(
                fontSize: adaptive.sp(12),
                fontWeight: FontWeight.w600,
                color: student['status'] == 'present' 
                  ? const Color(0xFF16a34a)
                  : const Color(0xFFd97706),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
