import 'package:flutter/material.dart';
import '../../utils/adaptive_screen_manager.dart';

class LecturerAttendanceTab extends StatefulWidget {
  final List<Map<String, dynamic>> courses;
  final bool isDarkMode;

  const LecturerAttendanceTab({
    super.key,
    required this.courses,
    required this.isDarkMode,
  });

  @override
  State<LecturerAttendanceTab> createState() => _LecturerAttendanceTabState();
}

class _LecturerAttendanceTabState extends State<LecturerAttendanceTab> {
  String? _selectedCourse;
  String? _selectedSemester;

  final List<Map<String, dynamic>> _attendanceData = [
    {'name': 'Tabe Mercy', 'matricle': 'FE19A001', 'present': 12, 'total': 15, 'percentage': 80},
    {'name': 'Ngozi Paul', 'matricle': 'FE19A002', 'present': 14, 'total': 15, 'percentage': 93},
    {'name': 'Fon Sandra', 'matricle': 'FE19A003', 'present': 10, 'total': 15, 'percentage': 67},
    {'name': 'Kom Victor', 'matricle': 'FE19A004', 'present': 13, 'total': 15, 'percentage': 87},
    {'name': 'Bih Grace', 'matricle': 'FE19A005', 'present': 11, 'total': 15, 'percentage': 73},
  ];

  @override
  void initState() {
    super.initState();
  }

  void _filterAttendance() {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Attendance filtered successfully'),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  void _exportAttendance() {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Attendance report exported to CSV'),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    
    return SingleChildScrollView(
      padding: adaptive.responsivePadding(all: 20, bottom: 100),
      child: Column(
        children: [
          _buildFilterSection(adaptive),
          SizedBox(height: adaptive.scale(20)),
          _buildAttendanceTable(adaptive),
        ],
      ),
    );
  }

  Widget _buildFilterSection(AdaptiveScreenManager adaptive) {
    return Container(
      padding: adaptive.responsivePadding(all: 20),
      decoration: BoxDecoration(
        color: widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFf8f9ff),
        borderRadius: adaptive.responsiveBorderRadius(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Filter Attendance',
            style: TextStyle(
              fontSize: adaptive.sp(18),
              fontWeight: FontWeight.w600,
              color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
            ),
          ),
          SizedBox(height: adaptive.scale(16)),
          
          // Course and Semester filters only
          Column(
            children: [
              _buildDropdown(
                'Select Course',
                _selectedCourse,
                widget.courses.map<Map<String, String>>((course) => {
                  'value': course['code'] as String,
                  'label': course['title'] as String,
                }).toList(),
                (value) => setState(() => _selectedCourse = value),
                adaptive,
              ),
              SizedBox(height: adaptive.scale(12)),
              _buildDropdown(
                'Select Semester',
                _selectedSemester,
                const [
                  {'value': '1', 'label': 'First Semester'},
                  {'value': '2', 'label': 'Second Semester'},
                ],
                (value) => setState(() => _selectedSemester = value),
                adaptive,
              ),
            ],
          ),
          
          SizedBox(height: adaptive.scale(16)),
          
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _filterAttendance,
              style: ElevatedButton.styleFrom(
                backgroundColor: widget.isDarkMode ? const Color(0xFF8b5cf6) : const Color(0xFF667eea),
                padding: adaptive.responsivePadding(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: adaptive.responsiveBorderRadius(12),
                ),
              ),
              child: Text(
                'Apply Filter',
                style: TextStyle(
                  fontSize: adaptive.sp(16),
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDropdown(
    String hint,
    String? value,
    List<Map<String, String>> items,
    Function(String?) onChanged,
    AdaptiveScreenManager adaptive,
  ) {
    return Container(
      width: double.infinity,
      padding: adaptive.responsivePadding(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(
        color: widget.isDarkMode ? const Color(0xFF2d3748) : Colors.white,
        border: Border.all(
          color: widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFe5e7eb),
          width: 2,
        ),
        borderRadius: adaptive.responsiveBorderRadius(12),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          isExpanded: true,
          hint: Text(
            hint,
            style: TextStyle(
              color: widget.isDarkMode ? const Color(0xFFa0aec0) : const Color(0xFF666666),
            ),
            overflow: TextOverflow.ellipsis,
          ),
          dropdownColor: widget.isDarkMode ? const Color(0xFF2d3748) : Colors.white,
          style: TextStyle(
            color: widget.isDarkMode ? const Color(0xFFe2e8f0) : const Color(0xFF333333),
            fontSize: adaptive.sp(16),
          ),
          items: items.map((item) {
            return DropdownMenuItem<String>(
              value: item['value'],
              child: Text(
                item['label']!,
                overflow: TextOverflow.ellipsis,
              ),
            );
          }).toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }

  Widget _buildAttendanceTable(AdaptiveScreenManager adaptive) {
    return Container(
      padding: adaptive.responsivePadding(all: 20),
      decoration: BoxDecoration(
        color: widget.isDarkMode ? const Color(0xFF2d3748) : Colors.white,
        borderRadius: adaptive.responsiveBorderRadius(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
        border: widget.isDarkMode ? Border.all(color: const Color(0xFF4a5568)) : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Attendance Summary',
            style: TextStyle(
              fontSize: adaptive.sp(18),
              fontWeight: FontWeight.w600,
              color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
            ),
          ),
          SizedBox(height: adaptive.scale(16)),
          
          // Table
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              headingRowColor: WidgetStateProperty.all(
                widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFf8f9ff),
              ),
              dataRowColor: WidgetStateProperty.all(
                widget.isDarkMode ? const Color(0xFF2d3748) : Colors.white,
              ),
              border: TableBorder.all(
                color: widget.isDarkMode ? const Color(0xFF4a5568) : const Color(0xFFe5e7eb),
              ),
              columns: [
                DataColumn(
                  label: Text(
                    'Student',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
                    ),
                  ),
                ),
                DataColumn(
                  label: Text(
                    'Matricle',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
                    ),
                  ),
                ),
                DataColumn(
                  label: Text(
                    'Present',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
                    ),
                  ),
                ),
                DataColumn(
                  label: Text(
                    'Total',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
                    ),
                  ),
                ),
                DataColumn(
                  label: Text(
                    '%',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: widget.isDarkMode ? const Color(0xFFf7fafc) : const Color(0xFF333333),
                    ),
                  ),
                ),
              ],
              rows: _attendanceData.map((student) {
                return DataRow(
                  cells: [
                    DataCell(
                      Text(
                        student['name'],
                        style: TextStyle(
                          color: widget.isDarkMode ? const Color(0xFFe2e8f0) : const Color(0xFF333333),
                        ),
                      ),
                    ),
                    DataCell(
                      Text(
                        student['matricle'],
                        style: TextStyle(
                          color: widget.isDarkMode ? const Color(0xFFe2e8f0) : const Color(0xFF333333),
                        ),
                      ),
                    ),
                    DataCell(
                      Text(
                        '${student['present']}',
                        style: TextStyle(
                          color: widget.isDarkMode ? const Color(0xFFe2e8f0) : const Color(0xFF333333),
                        ),
                      ),
                    ),
                    DataCell(
                      Text(
                        '${student['total']}',
                        style: TextStyle(
                          color: widget.isDarkMode ? const Color(0xFFe2e8f0) : const Color(0xFF333333),
                        ),
                      ),
                    ),
                    DataCell(
                      Text(
                        '${student['percentage']}%',
                        style: TextStyle(
                          color: student['percentage'] >= 75 
                            ? const Color(0xFF16a34a) 
                            : const Color(0xFFdc2626),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                );
              }).toList(),
            ),
          ),
          
          SizedBox(height: adaptive.scale(16)),
          
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: _exportAttendance,
              style: OutlinedButton.styleFrom(
                padding: adaptive.responsivePadding(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: adaptive.responsiveBorderRadius(12),
                ),
                side: BorderSide(
                  color: widget.isDarkMode ? const Color(0xFF718096) : const Color(0xFFe5e7ff),
                ),
              ),
              child: Text(
                'Export to CSV',
                style: TextStyle(
                  fontSize: adaptive.sp(16),
                  fontWeight: FontWeight.w600,
                  color: widget.isDarkMode ? const Color(0xFFe2e8f0) : const Color(0xFF667eea),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
