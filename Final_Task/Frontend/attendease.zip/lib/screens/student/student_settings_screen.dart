import 'package:flutter/material.dart';
import '../../utils/adaptive_screen_manager.dart';

class StudentSettingsScreen extends StatefulWidget {
  final VoidCallback onBack;
  final String themeMode;
  final Function(String) onThemeChanged;
  final Color primaryColor;
  final Color secondaryColor;
  final Color textColor;
  final Color textMuted;
  final Color bgColor;
  final Color cardBg;
  final Color borderColor;

  const StudentSettingsScreen({
    super.key,
    required this.onBack,
    required this.themeMode,
    required this.onThemeChanged,
    this.primaryColor = const Color(0xFF667EEA),
    this.secondaryColor = const Color(0xFF764BA2),
    this.textColor = const Color(0xFF333333),
    this.textMuted = const Color(0xFF6C757D),
    this.bgColor = const Color(0xFFFFFFFF),
    this.cardBg = const Color(0xFFFFFFFF),
    this.borderColor = const Color(0xFFE0E0E0),
  });

  @override
  State<StudentSettingsScreen> createState() => _StudentSettingsScreenState();
}

class _StudentSettingsScreenState extends State<StudentSettingsScreen> {
  bool _notificationsEnabled = true;
  bool _classReminders = true;
  bool _attendanceAlerts = true;
  bool _announcements = true;
  bool _dueDateReminders = true;
  bool _locationEnabled = true;
  bool _locationNotifications = true;

  // EXACT theme colors from HTML CSS
  static const Color _shadowColor = Color(0x1A000000);

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [widget.primaryColor, widget.secondaryColor],
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: Text(
            'Settings',
            style: TextStyle(
              fontSize: adaptive.sp(18),
              fontWeight: FontWeight.w600,
              color: Colors.white,
            ),
          ),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: widget.onBack,
          ),
        ),
        body: Container(
          color: widget.bgColor,
          child: SingleChildScrollView(
            padding: adaptive.responsivePadding(all: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildNotificationSettings(adaptive),
                SizedBox(height: adaptive.scale(20)),
                _buildLocationSettings(adaptive),
                SizedBox(height: adaptive.scale(20)),
                _buildAppearanceSettings(adaptive),
                SizedBox(height: adaptive.scale(20)),
                _buildAboutSettings(adaptive),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNotificationSettings(AdaptiveScreenManager adaptive) {
    return _buildSettingsSection(
      adaptive,
      'Notifications',
      Icons.notifications,
      [
        _buildSwitchTile(
          adaptive,
          'Enable Notifications',
          'Receive important alerts and reminders',
          _notificationsEnabled,
          (value) {
            setState(() => _notificationsEnabled = value);
          },
        ),
        if (_notificationsEnabled) ...[
          Container(
            margin: adaptive.responsivePadding(horizontal: 20, top: 10),
            padding: adaptive.responsivePadding(all: 15),
            decoration: BoxDecoration(
              color: widget.themeMode == 'dark' ? const Color(0xFF2c3034) : const Color(0xFFF8F9FA),
              borderRadius: adaptive.responsiveBorderRadius(8),
              border: Border.all(color: widget.borderColor),
            ),
            child: Column(
              children: [
                _buildNotificationOption(adaptive, 'Class Reminders', _classReminders, (value) => setState(() => _classReminders = value)),
                _buildNotificationOption(adaptive, 'Attendance Alerts', _attendanceAlerts, (value) => setState(() => _attendanceAlerts = value)),
                _buildNotificationOption(adaptive, 'Announcements', _announcements, (value) => setState(() => _announcements = value)),
                _buildNotificationOption(adaptive, 'Due Date Reminders', _dueDateReminders, (value) => setState(() => _dueDateReminders = value)),
              ],
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildNotificationOption(AdaptiveScreenManager adaptive, String title, bool value, ValueChanged<bool> onChanged) {
    return Container(
      padding: adaptive.responsivePadding(vertical: 8),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: widget.borderColor,
            width: 0.5,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: adaptive.sp(14),
              color: widget.textColor,
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: widget.primaryColor,
          ),
        ],
      ),
    );
  }

  Widget _buildLocationSettings(AdaptiveScreenManager adaptive) {
    return _buildSettingsSection(
      adaptive,
      'Location Services',
      Icons.location_on,
      [
        _buildSwitchTile(
          adaptive,
          'Enable Location',
          'Allow app to access your location for attendance',
          _locationEnabled,
          (value) => setState(() => _locationEnabled = value),
        ),
        _buildSwitchTile(
          adaptive,
          'Location Notifications',
          'Get notified when near class locations',
          _locationNotifications,
          (value) => setState(() => _locationNotifications = value),
        ),
      ],
    );
  }

  Widget _buildAppearanceSettings(AdaptiveScreenManager adaptive) {
    return _buildSettingsSection(
      adaptive,
      'Appearance',
      Icons.palette,
      [
        Container(
          padding: adaptive.responsivePadding(horizontal: 20, vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Theme Mode',
                style: TextStyle(
                  fontSize: adaptive.sp(14),
                  fontWeight: FontWeight.w500,
                  color: widget.textColor,
                ),
              ),
              SizedBox(height: adaptive.scale(8)),
              Text(
                'Choose your preferred theme',
                style: TextStyle(
                  fontSize: adaptive.sp(12),
                  color: widget.textMuted,
                ),
              ),
              SizedBox(height: adaptive.scale(12)),
              Column(
                children: [
                  _buildThemeOption(adaptive, 'System Default', 'system', Icons.brightness_auto),
                  _buildThemeOption(adaptive, 'Light Mode', 'light', Icons.light_mode),
                  _buildThemeOption(adaptive, 'Dark Mode', 'dark', Icons.dark_mode),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildThemeOption(AdaptiveScreenManager adaptive, String title, String value, IconData icon) {
    final bool isSelected = widget.themeMode == value;
    
    return Container(
      margin: adaptive.responsiveMargin(bottom: 8),
      child: InkWell(
        onTap: () => widget.onThemeChanged(value),
        borderRadius: adaptive.responsiveBorderRadius(8),
        child: Container(
          padding: adaptive.responsivePadding(all: 12),
          decoration: BoxDecoration(
            color: isSelected 
                ? widget.primaryColor.withOpacity(0.1) 
                : Colors.transparent,
            borderRadius: adaptive.responsiveBorderRadius(8),
            border: Border.all(
              color: isSelected 
                  ? widget.primaryColor 
                  : widget.borderColor,
              width: isSelected ? 2 : 1,
            ),
          ),
          child: Row(
            children: [
              Icon(
                icon,
                color: isSelected ? widget.primaryColor : widget.textMuted,
                size: adaptive.responsiveIconSize(20),
              ),
              SizedBox(width: adaptive.scale(12)),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    fontSize: adaptive.sp(14),
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                    color: isSelected ? widget.primaryColor : widget.textColor,
                  ),
                ),
              ),
              if (isSelected)
                Icon(
                  Icons.check_circle,
                  color: widget.primaryColor,
                  size: adaptive.responsiveIconSize(20),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAboutSettings(AdaptiveScreenManager adaptive) {
    return _buildSettingsSection(
      adaptive,
      'About',
      Icons.info,
      [
        _buildInfoTile(adaptive, 'Version', 'AttendEase v1.2.0'),
        _buildActionTile(adaptive, 'Privacy Policy', 'How we handle your data', () => _showPrivacyPolicy()),
        _buildActionTile(adaptive, 'Terms of Service', 'App usage guidelines', () => _showTermsOfService()),
      ],
    );
  }

  Widget _buildSettingsSection(
    AdaptiveScreenManager adaptive,
    String title,
    IconData icon,
    List<Widget> children,
  ) {
    return Container(
      decoration: BoxDecoration(
        color: widget.cardBg,
        borderRadius: adaptive.responsiveBorderRadius(12),
        border: Border.all(color: widget.borderColor),
        boxShadow: const [
          BoxShadow(
            color: _shadowColor,
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: adaptive.responsivePadding(all: 20),
            child: Row(
              children: [
                Icon(icon, color: widget.primaryColor, size: adaptive.responsiveIconSize(20)),
                SizedBox(width: adaptive.scale(10)),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: adaptive.sp(16),
                    fontWeight: FontWeight.w600,
                    color: widget.textColor,
                  ),
                ),
              ],
            ),
          ),
          ...children,
        ],
      ),
    );
  }

  Widget _buildSwitchTile(
    AdaptiveScreenManager adaptive,
    String title,
    String subtitle,
    bool value,
    ValueChanged<bool> onChanged,
  ) {
    return Container(
      padding: adaptive.responsivePadding(horizontal: 20, vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: adaptive.sp(14),
                    fontWeight: FontWeight.w500,
                    color: widget.textColor,
                  ),
                ),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: adaptive.sp(12),
                    color: widget.textMuted,
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: widget.primaryColor,
          ),
        ],
      ),
    );
  }

  Widget _buildActionTile(AdaptiveScreenManager adaptive, String title, String subtitle, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: adaptive.responsivePadding(horizontal: 20, vertical: 16),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: adaptive.sp(14),
                      fontWeight: FontWeight.w500,
                      color: widget.textColor,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: adaptive.sp(12),
                      color: widget.textMuted,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.chevron_right,
              color: widget.textMuted,
              size: adaptive.responsiveIconSize(16),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoTile(AdaptiveScreenManager adaptive, String title, String value) {
    return Container(
      padding: adaptive.responsivePadding(horizontal: 20, vertical: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: adaptive.sp(14),
              fontWeight: FontWeight.w500,
              color: widget.textColor,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: adaptive.sp(14),
              color: widget.textMuted,
            ),
          ),
        ],
      ),
    );
  }

  void _showPrivacyPolicy() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Privacy Policy'),
        content: const SingleChildScrollView(
          child: Text(
            '1. Information We Collect\n\n'
            'We collect personal information that you provide when you register for an account, including your name, email address, student ID, and facial recognition data for attendance purposes.\n\n'
            '2. How We Use Your Information\n\n'
            'Your information is used to provide the attendance tracking service, verify your identity during check-ins, and maintain your academic records.\n\n'
            '3. Data Security\n\n'
            'We implement industry-standard security measures to protect your personal information. Your facial recognition data is encrypted and stored securely.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('I Understand'),
          ),
        ],
      ),
    );
  }

  void _showTermsOfService() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Terms of Service'),
        content: const SingleChildScrollView(
          child: Text(
            '1. Acceptance of Terms\n\n'
            'By using the AttendEase app, you agree to comply with these Terms of Service.\n\n'
            '2. Proper Use\n\n'
            'You agree to use the app only for legitimate attendance tracking purposes. Misrepresentation of attendance records is prohibited.\n\n'
            '3. Account Responsibility\n\n'
            'You are responsible for maintaining the confidentiality of your account credentials.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('I Agree'),
          ),
        ],
      ),
    );
  }
}
