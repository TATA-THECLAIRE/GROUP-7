import 'package:flutter/material.dart';
import '../../utils/adaptive_screen_manager.dart';
import 'student_models.dart';

class StudentAttendanceHistoryScreen extends StatefulWidget {
  final List<AttendanceRecord> records;
  final VoidCallback onBack;
  final Function(AttendanceRecord) onViewDetail;
  final bool isDarkMode;
  final Color primaryColor;
  final Color secondaryColor;
  final Color textColor;
  final Color textMuted;
  final Color bgColor;
  final Color cardBg;
  final Color borderColor;

  const StudentAttendanceHistoryScreen({
    super.key,
    required this.records,
    required this.onBack,
    required this.onViewDetail,
    this.isDarkMode = false,
    this.primaryColor = const Color(0xFF667EEA),
    this.secondaryColor = const Color(0xFF764BA2),
    this.textColor = const Color(0xFF333333),
    this.textMuted = const Color(0xFF6C757D),
    this.bgColor = const Color(0xFFFFFFFF),
    this.cardBg = const Color(0xFFFFFFFF),
    this.borderColor = const Color(0xFFE0E0E0),
  });

  @override
  State<StudentAttendanceHistoryScreen> createState() => _StudentAttendanceHistoryScreenState();
}

class _StudentAttendanceHistoryScreenState extends State<StudentAttendanceHistoryScreen> {
  // Remove these unused constants:
  // static const Color _successColor = Color(0xFF28A745);
  // static const Color _dangerColor = Color(0xFFDC3545);
  // static const Color _warningColor = Color(0xFFFFC107);
  
  // Keep only the used one:
  static const Color _shadowColor = Color(0x1A000000);

  String _selectedSemester = '';
  String _selectedCourse = '';
  DateTime? _selectedDate;

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    final filteredRecords = _getFilteredRecords();

    return Container(
      color: widget.bgColor,
      child: SingleChildScrollView(
        padding: adaptive.responsivePadding(all: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Attendance Records',
              style: TextStyle(
                fontSize: adaptive.sp(16),
                fontWeight: FontWeight.w600,
                color: widget.textColor,
              ),
            ),
            SizedBox(height: adaptive.scale(20)),
            _buildFilterContainer(adaptive),
            SizedBox(height: adaptive.scale(20)),
            _buildAttendanceTable(adaptive, filteredRecords),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterContainer(AdaptiveScreenManager adaptive) {
    return Material(
      color: Colors.transparent,
      child: Container(
        padding: adaptive.responsivePadding(all: 15),
        decoration: BoxDecoration(
          color: widget.cardBg,
          borderRadius: adaptive.responsiveBorderRadius(12),
          border: Border.all(color: widget.borderColor),
          boxShadow: const [
            BoxShadow(
              color: _shadowColor,
              blurRadius: 6,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          children: [
            // First row with semester and course dropdowns
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _selectedSemester.isEmpty ? null : _selectedSemester,
                    decoration: InputDecoration(
                      labelText: 'Semester',
                      border: OutlineInputBorder(
                        borderRadius: adaptive.responsiveBorderRadius(6),
                      ),
                      contentPadding: adaptive.responsivePadding(horizontal: 8, vertical: 6),
                      labelStyle: TextStyle(fontSize: adaptive.sp(12)),
                    ),
                    style: TextStyle(fontSize: adaptive.sp(12), color: widget.textColor),
                    items: const [
                      DropdownMenuItem(value: '1', child: Text('Semester 1')),
                      DropdownMenuItem(value: '2', child: Text('Semester 2')),
                    ],
                    onChanged: (value) {
                      setState(() {
                        _selectedSemester = value ?? '';
                      });
                    },
                  ),
                ),
                SizedBox(width: adaptive.scale(8)),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _selectedCourse.isEmpty ? null : _selectedCourse,
                    decoration: InputDecoration(
                      labelText: 'Course',
                      border: OutlineInputBorder(
                        borderRadius: adaptive.responsiveBorderRadius(6),
                      ),
                      contentPadding: adaptive.responsivePadding(horizontal: 8, vertical: 6),
                      labelStyle: TextStyle(fontSize: adaptive.sp(12)),
                    ),
                    style: TextStyle(fontSize: adaptive.sp(12), color: widget.textColor),
                    items: const [
                      DropdownMenuItem(value: 'CS301', child: Text('CS301')),
                      DropdownMenuItem(value: 'MATH201', child: Text('MATH201')),
                      DropdownMenuItem(value: 'CS302', child: Text('CS302')),
                    ],
                    onChanged: (value) {
                      setState(() {
                        _selectedCourse = value ?? '';
                      });
                    },
                  ),
                ),
              ],
            ),
            SizedBox(height: adaptive.scale(10)),
            // Date picker
            InkWell(
              onTap: () async {
                final date = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime(2020),
                  lastDate: DateTime.now(),
                );
                if (date != null) {
                  setState(() {
                    _selectedDate = date;
                  });
                }
              },
              child: Container(
                width: double.infinity,
                padding: adaptive.responsivePadding(horizontal: 12, vertical: 12),
                decoration: BoxDecoration(
                  border: Border.all(color: widget.borderColor),
                  borderRadius: adaptive.responsiveBorderRadius(6),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.calendar_today,
                      size: adaptive.responsiveIconSize(16),
                      color: widget.textMuted,
                    ),
                    SizedBox(width: adaptive.scale(8)),
                    Text(
                      _selectedDate != null 
                        ? '${_selectedDate!.day}/${_selectedDate!.month}/${_selectedDate!.year}'
                        : 'Select Date',
                      style: TextStyle(
                        fontSize: adaptive.sp(14),
                        color: _selectedDate != null ? widget.textColor : widget.textMuted,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAttendanceTable(AdaptiveScreenManager adaptive, List<AttendanceRecord> records) {
    return Container(
      decoration: BoxDecoration(
        color: widget.cardBg,
        borderRadius: adaptive.responsiveBorderRadius(12),
        border: Border.all(color: widget.borderColor),
        boxShadow: const [
          BoxShadow(
            color: _shadowColor,
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          // Table Header
          Container(
            padding: adaptive.responsivePadding(all: 15),
            decoration: BoxDecoration(
              color: widget.isDarkMode ? const Color(0xFF2c3034) : const Color(0xFFF8F9FA),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(adaptive.scale(12)),
                topRight: Radius.circular(adaptive.scale(12)),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  flex: 3,
                  child: Text(
                    'Course',
                    style: TextStyle(
                      fontSize: adaptive.sp(14),
                      fontWeight: FontWeight.w600,
                      color: widget.textColor,
                    ),
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: Text(
                    'Date',
                    style: TextStyle(
                      fontSize: adaptive.sp(14),
                      fontWeight: FontWeight.w600,
                      color: widget.textColor,
                    ),
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: Text(
                    'Status',
                    style: TextStyle(
                      fontSize: adaptive.sp(14),
                      fontWeight: FontWeight.w600,
                      color: widget.textColor,
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Table Body
          ...List.generate(6, (index) {
            final attendanceData = [
              {'course': 'Data Structures & Algorithms', 'date': 'May 15, 2024', 'status': 'Present'},
              {'course': 'Computer Architecture', 'date': 'May 13, 2024', 'status': 'Present'},
              {'course': 'Linear Algebra', 'date': 'May 12, 2024', 'status': 'Present'},
              {'course': 'Operating Systems', 'date': 'May 10, 2024', 'status': 'Absent'},
              {'course': 'Data Structures & Algorithms', 'date': 'May 8, 2024', 'status': 'Present'},
              {'course': 'Computer Architecture', 'date': 'May 6, 2024', 'status': 'Late'},
            ];
            
            final data = attendanceData[index];
            return InkWell(
              onTap: () => widget.onViewDetail(widget.records.isNotEmpty ? widget.records[0] : _createDummyRecord()),
              child: Container(
                padding: adaptive.responsivePadding(all: 15),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(
                      color: widget.borderColor,
                      width: index < 5 ? 1 : 0,
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: Text(
                        data['course']!,
                        style: TextStyle(
                          fontSize: adaptive.sp(13),
                          color: widget.textColor,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        data['date']!,
                        style: TextStyle(
                          fontSize: adaptive.sp(13),
                          color: widget.textColor,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: _buildStatusBadge(adaptive, data['status']!),
                    ),
                  ],
                ),
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildStatusBadge(AdaptiveScreenManager adaptive, String status) {
    Color bgColor;
    Color textColor;
    
    switch (status.toLowerCase()) {
      case 'present':
        bgColor = const Color(0xFFd4edda);
        textColor = const Color(0xFF155724);
        break;
      case 'absent':
        bgColor = const Color(0xFFf8d7da);
        textColor = const Color(0xFF721c24);
        break;
      case 'late':
        bgColor = const Color(0xFFfff3cd);
        textColor = const Color(0xFF856404);
        break;
      default:
        bgColor = widget.borderColor;
        textColor = widget.textColor;
    }
    
    return Container(
      padding: adaptive.responsivePadding(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: adaptive.responsiveBorderRadius(12),
      ),
      child: Text(
        status,
        style: TextStyle(
          fontSize: adaptive.sp(12),
          fontWeight: FontWeight.w500,
          color: textColor,
        ),
        textAlign: TextAlign.center,
      ),
    );
  }

  AttendanceRecord _createDummyRecord() {
    return AttendanceRecord(
      id: '1',
      courseCode: 'CS301',
      courseTitle: 'Data Structures & Algorithms',
      date: 'May 15, 2024',
      time: '10:00 AM',
      status: AttendanceStatus.present,
      location: 'Lecture Hall A',
      topic: 'Linked Lists Implementation',
      checkInTime: '10:02 AM',
      confidence: '94% match',
    );
  }

  List<AttendanceRecord> _getFilteredRecords() {
    var filtered = widget.records;
    
    if (_selectedCourse.isNotEmpty) {
      filtered = filtered.where((record) => record.courseCode == _selectedCourse).toList();
    }
    
    // Add more filtering logic based on semester and date
    
    return filtered;
  }
}
