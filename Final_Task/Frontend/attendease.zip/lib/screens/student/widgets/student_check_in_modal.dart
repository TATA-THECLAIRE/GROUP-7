import 'package:flutter/material.dart';
import '../../../utils/adaptive_screen_manager.dart';

class StudentCheckInModal extends StatefulWidget {
  final String courseCode;
  final VoidCallback onSuccess;
  final Color primaryColor;
  final Color textColor;
  final Color textMuted;
  final Color bgColor;
  final Color cardBg;
  final bool isDarkMode;

  const StudentCheckInModal({
    super.key,
    required this.courseCode,
    required this.onSuccess,
    required this.primaryColor,
    required this.textColor,
    required this.textMuted,
    required this.bgColor,
    required this.cardBg,
    required this.isDarkMode,
  });

  @override
  State<StudentCheckInModal> createState() => _StudentCheckInModalState();
}

class _StudentCheckInModalState extends State<StudentCheckInModal> {
  bool _showProgress = false;

  static const Color _successColor = Color(0xFF28A745);

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        width: adaptive.scale(350),
        decoration: BoxDecoration(
          color: widget.cardBg,
          borderRadius: adaptive.responsiveBorderRadius(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header
            Container(
              padding: adaptive.responsivePadding(all: 20),
              child: Column(
                children: [
                  Text(
                    'Check In to Class',
                    style: TextStyle(
                      fontSize: adaptive.sp(18),
                      fontWeight: FontWeight.w600,
                      color: widget.textColor,
                    ),
                  ),
                  SizedBox(height: adaptive.scale(10)),
                  Container(
                    width: double.infinity,
                    padding: adaptive.responsivePadding(all: 12),
                    decoration: BoxDecoration(
                      color: widget.isDarkMode 
                          ? Colors.grey[800] 
                          : const Color(0xFFF8F9FA),
                      borderRadius: adaptive.responsiveBorderRadius(8),
                    ),
                    child: Text(
                      'Linear Algebra • MATH201',
                      style: TextStyle(
                        fontSize: adaptive.sp(14),
                        color: widget.textMuted,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
            
            if (!_showProgress) ...[
              // Face scan area
              Container(
                margin: adaptive.responsivePadding(horizontal: 20),
                width: double.infinity,
                height: adaptive.scale(200),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: widget.primaryColor,
                    width: 2,
                    style: BorderStyle.solid,
                  ),
                  borderRadius: adaptive.responsiveBorderRadius(8),
                  color: widget.isDarkMode 
                      ? Colors.grey[800] 
                      : const Color(0xFFF8F9FA),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.person,
                      size: adaptive.responsiveIconSize(40),
                      color: widget.primaryColor,
                    ),
                    SizedBox(height: adaptive.scale(10)),
                    Text(
                      'Position your face in the frame',
                      style: TextStyle(
                        fontSize: adaptive.sp(14),
                        color: widget.textMuted,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
              
              // Location status
              Container(
                margin: adaptive.responsivePadding(all: 20),
                padding: adaptive.responsivePadding(all: 10),
                decoration: BoxDecoration(
                  color: widget.isDarkMode 
                      ? Colors.grey[800] 
                      : const Color(0xFFF8F9FA),
                  borderRadius: adaptive.responsiveBorderRadius(8),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.check_circle,
                      color: _successColor,
                      size: adaptive.responsiveIconSize(16),
                    ),
                    SizedBox(width: adaptive.scale(8)),
                    Expanded(
                      child: Text(
                        'Location verified: Lecture Hall A (50m)',
                        style: TextStyle(
                          fontSize: adaptive.sp(13),
                          color: _successColor,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              
              // Instructions
              Padding(
                padding: adaptive.responsivePadding(horizontal: 20),
                child: Text(
                  'Please ensure good lighting and remove any face coverings',
                  style: TextStyle(
                    fontSize: adaptive.sp(13),
                    color: widget.textMuted,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              SizedBox(height: adaptive.scale(20)),
              
              // Buttons
              Padding(
                padding: adaptive.responsivePadding(horizontal: 20, bottom: 20),
                child: Column(
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _startFacialRecognition,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: widget.primaryColor,
                          foregroundColor: Colors.white,
                          padding: adaptive.responsivePadding(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: adaptive.responsiveBorderRadius(8),
                          ),
                          elevation: 0,
                        ),
                        child: Text(
                          'Start Facial Recognition',
                          style: TextStyle(
                            fontSize: adaptive.sp(16),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: adaptive.scale(10)),
                    SizedBox(
                      width: double.infinity,
                      child: TextButton(
                        onPressed: () => Navigator.of(context).pop(),
                        style: TextButton.styleFrom(
                          backgroundColor: widget.isDarkMode 
                              ? Colors.grey[700] 
                              : const Color(0xFFE0E0E0),
                          foregroundColor: widget.textColor,
                          padding: adaptive.responsivePadding(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: adaptive.responsiveBorderRadius(8),
                          ),
                        ),
                        child: Text(
                          'Cancel',
                          style: TextStyle(
                            fontSize: adaptive.sp(16),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ] else ...[
              // Progress state
              Container(
                padding: adaptive.responsivePadding(all: 20),
                child: Column(
                  children: [
                    SizedBox(
                      width: adaptive.scale(40),
                      height: adaptive.scale(40),
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(widget.primaryColor),
                        strokeWidth: 4,
                      ),
                    ),
                    SizedBox(height: adaptive.scale(15)),
                    Text(
                      'Verifying your identity...',
                      style: TextStyle(
                        fontSize: adaptive.sp(14),
                        color: widget.textMuted,
                      ),
                    ),
                    SizedBox(height: adaptive.scale(15)),
                    Container(
                      width: double.infinity,
                      padding: adaptive.responsivePadding(all: 10),
                      decoration: BoxDecoration(
                        color: widget.isDarkMode 
                            ? Colors.grey[800] 
                            : const Color(0xFFF8F9FA),
                        borderRadius: adaptive.responsiveBorderRadius(8),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.check_circle,
                            color: _successColor,
                            size: adaptive.responsiveIconSize(16),
                          ),
                          SizedBox(width: adaptive.scale(8)),
                          Expanded(
                            child: Text(
                              'Location confirmed: Lecture Hall A',
                              style: TextStyle(
                                fontSize: adaptive.sp(13),
                                color: _successColor,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: adaptive.scale(10)),
                    Text(
                      'Please remain still while we verify your location and identity',
                      style: TextStyle(
                        fontSize: adaptive.sp(13),
                        color: widget.textMuted,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _startFacialRecognition() {
    setState(() {
      _showProgress = true;
    });

    // Simulate processing
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        Navigator.of(context).pop();
        _showSuccessModal();
      }
    });
  }

  void _showSuccessModal() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        final adaptive = context.adaptive;
        
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            decoration: BoxDecoration(
              color: widget.cardBg,
              borderRadius: adaptive.responsiveBorderRadius(12),
            ),
            padding: adaptive.responsivePadding(all: 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Check-in Successful!',
                  style: TextStyle(
                    fontSize: adaptive.sp(18),
                    fontWeight: FontWeight.w600,
                    color: widget.textColor,
                  ),
                ),
                SizedBox(height: adaptive.scale(10)),
                Text(
                  'Linear Algebra • MATH201',
                  style: TextStyle(
                    fontSize: adaptive.sp(14),
                    color: widget.textMuted,
                  ),
                ),
                SizedBox(height: adaptive.scale(20)),
                
                // Success icon
                Container(
                  width: adaptive.scale(60),
                  height: adaptive.scale(60),
                  decoration: BoxDecoration(
                    color: widget.isDarkMode 
                        ? _successColor.withValues(alpha: 0.2)
                        : const Color(0xFFD4EDDA),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.check,
                    size: adaptive.responsiveIconSize(30),
                    color: _successColor,
                  ),
                ),
                SizedBox(height: adaptive.scale(15)),
                
                Text(
                  'You have successfully checked in to your class.',
                  style: TextStyle(
                    fontSize: adaptive.sp(14),
                    color: widget.textColor,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: adaptive.scale(20)),
                
                // Details
                Container(
                  width: double.infinity,
                  padding: adaptive.responsivePadding(all: 15),
                  decoration: BoxDecoration(
                    color: widget.isDarkMode 
                        ? Colors.grey[800] 
                        : const Color(0xFFF8F9FA),
                    borderRadius: adaptive.responsiveBorderRadius(8),
                  ),
                  child: Column(
                    children: [
                      _buildDetailRow(adaptive, 'Time:', '2:05 PM'),
                      _buildDetailRow(adaptive, 'Location:', 'Lecture Hall A'),
                      _buildDetailRow(adaptive, 'Confidence:', '94% match'),
                    ],
                  ),
                ),
                SizedBox(height: adaptive.scale(20)),
                
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                      widget.onSuccess();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: widget.primaryColor,
                      foregroundColor: Colors.white,
                      padding: adaptive.responsivePadding(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: adaptive.responsiveBorderRadius(8),
                      ),
                    ),
                    child: Text(
                      'Done',
                      style: TextStyle(fontSize: adaptive.sp(16)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildDetailRow(AdaptiveScreenManager adaptive, String label, String value) {
    return Padding(
      padding: adaptive.responsivePadding(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: adaptive.sp(14),
              color: widget.textMuted,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: adaptive.sp(14),
              fontWeight: FontWeight.w500,
              color: widget.textColor,
            ),
          ),
        ],
      ),
    );
  }
}
