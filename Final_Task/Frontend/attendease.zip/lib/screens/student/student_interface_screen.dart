import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../../models/user_role.dart';
import '../../utils/adaptive_screen_manager.dart';
import '../../services/user_data_service.dart';
import '../homepage_screen.dart';
import 'student_models.dart';
import 'widgets/student_check_in_modal.dart';
import 'student_attendance_detail_screen.dart';
import 'student_notifications_screen.dart';
import 'student_courses_screen.dart';
import 'student_attendance_history_screen.dart';
import 'student_settings_screen.dart';
import 'student_course_detail_screen.dart';
import 'package:flutter/services.dart';
import 'student_calendar_screen.dart';

class StudentInterfaceScreen extends StatefulWidget {
  final UserRole role;
  final bool isFromSignup;

  const StudentInterfaceScreen({
    super.key,
    required this.role,
    this.isFromSignup = false,
  });

  @override
  State<StudentInterfaceScreen> createState() => _StudentInterfaceScreenState();
}

class _StudentInterfaceScreenState extends State<StudentInterfaceScreen> {
  int _currentIndex = 0;
  String _themeMode = 'system'; // 'light', 'dark', 'system'
  String _currentScreen = 'dashboard';
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();
  bool _isLoading = false;
  
  // Navigation history for proper back navigation
  final List<String> _navigationHistory = ['dashboard'];
  DateTime? _lastBackPressed;

  // EXACT theme colors from HTML CSS
  static const Color _primaryColor = Color(0xFF667EEA);  // Changed from 0xFF5D3BE3
  static const Color _secondaryColor = Color(0xFF764BA2);
  static const Color _successColor = Color(0xFF28A745);
  static const Color _dangerColor = Color(0xFFDC3545);
  static const Color _warningColor = Color(0xFFFFC107);
  static const Color _infoColor = Color(0xFF17A2B8);
  static const Color _textColor = Color(0xFF333333);
  static const Color _textMuted = Color(0xFF6C757D);
  static const Color _borderColor = Color(0xFFE0E0E0);
  static const Color _bgColor = Color(0xFFFFFFFF);  // Changed from 0xFFF5F7FA
  static const Color _cardBg = Color(0xFFFFFFFF);
  static const Color _shadowColor = Color(0x1A000000);

  // Dark mode colors from HTML
  static const Color _darkPrimaryColor = Color(0xFF7C93E8);
  static const Color _darkSecondaryColor = Color(0xFF8A66AD);
  static const Color _darkSuccessColor = Color(0xFF34CE57);
  static const Color _darkDangerColor = Color(0xFFE4606D);
  static const Color _darkWarningColor = Color(0xFFFFD351);
  static const Color _darkTextColor = Color(0xFFF8F9FA);
  static const Color _darkTextMuted = Color(0xFFADB5BD);
  static const Color _darkBorderColor = Color(0xFF495057);
  static const Color _darkBgColor = Color(0xFF212529);
  static const Color _darkCardBg = Color(0xFF2C3034);

  // Sample data matching HTML
  final List<Course> _courses = [
    Course(
      code: 'CS301',
      title: 'Data Structures & Algorithms',
      lecturer: 'Dr. Sarah Wilson',
      department: 'Computer Science',
      attendance: 92,
      present: 12,
      total: 13,
      late: 1,
      nextClass: 'Wed, 10:00 AM',
      schedule: 'Wednesdays, 10:00 AM - 12:00 PM',
    ),
    Course(
      code: 'MATH201',
      title: 'Linear Algebra',
      lecturer: 'Prof. David Brown',
      department: 'Mathematics',
      attendance: 87,
      present: 7,
      total: 8,
      late: 0,
      nextClass: 'Today, 2:00 PM',
      schedule: 'Mondays & Wednesdays, 2:00 PM - 4:00 PM',
    ),
    Course(
      code: 'CS302',
      title: 'Operating Systems',
      lecturer: 'Dr. Michael Lee',
      department: 'Computer Science',
      attendance: 68,
      present: 5,
      total: 8,
      late: 2,
      nextClass: 'Fri, 8:00 AM',
      schedule: 'Fridays, 8:00 AM - 10:00 AM',
    ),
  ];

  final List<AttendanceRecord> _attendanceRecords = [
    AttendanceRecord(
      id: '1',
      courseCode: 'CS301',
      courseTitle: 'Data Structures & Algorithms',
      date: 'May 15, 2024',
      time: '10:00 AM',
      status: AttendanceStatus.present,
      checkInTime: '10:02 AM',
      location: 'Lecture Hall A',
      confidence: '94%',
      topic: 'Linked Lists Implementation',
    ),
    AttendanceRecord(
      id: '2',
      courseCode: 'CS301',
      courseTitle: 'Data Structures & Algorithms',
      date: 'May 8, 2024',
      time: '10:00 AM',
      status: AttendanceStatus.present,
      checkInTime: '10:05 AM',
      location: 'Lecture Hall A',
      confidence: '92%',
      topic: 'Trees',
    ),
    AttendanceRecord(
      id: '3',
      courseCode: 'CS302',
      courseTitle: 'Operating Systems',
      date: 'May 10, 2024',
      time: '8:00 AM',
      status: AttendanceStatus.absent,
      location: 'Computer Lab 3',
      topic: 'Memory Management',
    ),
  ];

  // Theme getters with system theme support
  bool get _isSystemDark => MediaQuery.of(context).platformBrightness == Brightness.dark;
  bool get _effectiveIsDark {
    switch (_themeMode) {
      case 'dark':
        return true;
      case 'light':
        return false;
      case 'system':
      default:
        return _isSystemDark;
    }
  }

  Color get primaryColor => _effectiveIsDark ? _darkPrimaryColor : _primaryColor;
  Color get secondaryColor => _effectiveIsDark ? _darkSecondaryColor : _secondaryColor;
  Color get successColor => _effectiveIsDark ? _darkSuccessColor : _successColor;
  Color get dangerColor => _effectiveIsDark ? _darkDangerColor : _dangerColor;
  Color get warningColor => _effectiveIsDark ? _darkWarningColor : _warningColor;
  Color get textColor => _effectiveIsDark ? _darkTextColor : _textColor;
  Color get textMuted => _effectiveIsDark ? _darkTextMuted : _textMuted;
  Color get bgColor => _effectiveIsDark ? _darkBgColor : _bgColor;
  Color get cardBg => _effectiveIsDark ? _darkCardBg : _cardBg;
  Color get borderColor => _effectiveIsDark ? _darkBorderColor : _borderColor;

  @override
  void initState() {
    super.initState();
    if (widget.isFromSignup) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _showWelcomeMessage();
      });
    }
  }

  Future<void> _showWelcomeMessage() async {
    if (mounted && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Row(
            children: [
              Icon(Icons.check_circle, color: Colors.white, size: 20),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Welcome back, John! You\'re successfully logged in.',
                  style: TextStyle(fontSize: 14),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 2,
                ),
              ),
            ],
          ),
          backgroundColor: successColor,
          duration: const Duration(seconds: 4),
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.all(16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
          action: SnackBarAction(
            label: 'OK',
            textColor: Colors.white,
            onPressed: () {
              ScaffoldMessenger.of(context).hideCurrentSnackBar();
            },
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        _handleSystemBackPress();
      },
      child: Theme(
        data: _buildTheme(),
        child: Scaffold(
          backgroundColor: bgColor,
          appBar: _buildAppBar(adaptive),
          body: _isLoading ? _buildLoadingState(adaptive) : _buildCurrentScreen(adaptive),
          bottomNavigationBar: _shouldShowBottomNav() ? _buildBottomNav(adaptive) : null,
        ),
      ),
    );
  }

  // Nielsen's Heuristic #1: Visibility of System Status
  Widget _buildLoadingState(AdaptiveScreenManager adaptive) {
    return Container(
      color: bgColor,  // Consistent background
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: primaryColor),
            SizedBox(height: adaptive.scale(16)),
            Text(
              'Loading your attendance data...',
              style: TextStyle(
                fontSize: adaptive.sp(16),
                color: textMuted,
              ),
            ),
          ],
        ),
      ),
    );
  }

  ThemeData _buildTheme() {
    return ThemeData(
      primaryColor: primaryColor,
      brightness: _effectiveIsDark ? Brightness.dark : Brightness.light,
      scaffoldBackgroundColor: bgColor,
      cardColor: cardBg,
      textTheme: TextTheme(
        bodyLarge: TextStyle(color: textColor),
        bodyMedium: TextStyle(color: textColor),
      ),
    );
  }

  // Nielsen's Heuristic #2: Match between system and real world
  PreferredSizeWidget _buildAppBar(AdaptiveScreenManager adaptive) {
    return AppBar(
      backgroundColor: primaryColor,
      elevation: 0,
      automaticallyImplyLeading: false,
      flexibleSpace: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [primaryColor, secondaryColor],
          ),
        ),
      ),
      leading: _shouldShowBackButton() 
        ? IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: _handleBackPress,
            tooltip: 'Go back',
          )
        : null,
      title: Row(
        children: [
          // Logo container
          Container(
            width: adaptive.scale(32),
            height: adaptive.scale(32),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.asset(
                'assets/images/logo.png',
                width: adaptive.scale(32),
                height: adaptive.scale(32),
                fit: BoxFit.contain,
                errorBuilder: (context, error, stackTrace) {
                  // Fallback to "AE" text if image fails to load
                  return Container(
                    width: adaptive.scale(32),
                    height: adaptive.scale(32),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Center(
                      child: Text(
                        'AE',
                        style: TextStyle(
                          color: primaryColor,
                          fontSize: adaptive.sp(14),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          SizedBox(width: adaptive.scale(10)),
          // Title section
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                if (_shouldShowBackButton()) _buildNavigationBreadcrumb(adaptive),
                Text(
                  _getScreenTitle(),
                  style: TextStyle(
                    fontSize: adaptive.sp(18),
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      actions: _currentScreen == 'dashboard' ? [
        IconButton(
          icon: Icon(
            _themeMode == 'system' 
                ? Icons.brightness_auto 
                : _themeMode == 'dark' 
                    ? Icons.dark_mode 
                    : Icons.light_mode, 
            color: Colors.white
          ),
          onPressed: () {
            setState(() {
              switch (_themeMode) {
                case 'light':
                  _themeMode = 'dark';
                  break;
                case 'dark':
                  _themeMode = 'system';
                  break;
                case 'system':
                default:
                  _themeMode = 'light';
                  break;
              }
            });
            String message;
            IconData icon;
            switch (_themeMode) {
              case 'light':
                message = 'Light mode enabled';
                icon = Icons.light_mode;
                break;
              case 'dark':
                message = 'Dark mode enabled';
                icon = Icons.dark_mode;
                break;
              case 'system':
              default:
                message = 'System theme enabled';
                icon = Icons.brightness_auto;
                break;
            }
            _showSnackBar(message, successColor, icon: icon);
          },
          tooltip: _themeMode == 'system' 
              ? 'Switch to light mode' 
              : _themeMode == 'dark' 
                  ? 'Switch to system theme' 
                  : 'Switch to dark mode',
        ),
        IconButton(
          icon: const Icon(Icons.notifications, color: Colors.white),
          onPressed: () => _navigateToNotifications(),
          tooltip: 'Notifications',
        ),
        GestureDetector(
          onTap: () => _navigateToScreen('profile'),
          child: Container(
            margin: const EdgeInsets.only(right: 15),
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(18),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(18),
              child: _profileImage != null
                  ? Image.file(_profileImage!, fit: BoxFit.cover)
                  : Image.network(
                      'https://ui-avatars.com/api/?name=John+Doe&background=667eea&color=fff',
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return const Icon(Icons.person, color: Colors.white);
                      },
                    ),
            ),
          ),
        ),
      ] : [],
    );
  }

  // Update the _navigateToSettingsScreen method to handle instant theme changes
  void _navigateToSettingsScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => StudentSettingsScreen(
          onBack: () => Navigator.pop(context),
          themeMode: _themeMode,
          onThemeChanged: (String value) {
            // Apply theme change instantly
            setState(() {
              _themeMode = value;
            });
            String message;
            IconData icon;
            switch (value) {
              case 'light':
                message = 'Light mode enabled';
                icon = Icons.light_mode;
                break;
              case 'dark':
                message = 'Dark mode enabled';
                icon = Icons.dark_mode;
                break;
              case 'system':
              default:
                message = 'System theme enabled';
                icon = Icons.brightness_auto;
                break;
            }
            _showSnackBar(message, successColor, icon: icon);
          },
          primaryColor: primaryColor,
          secondaryColor: secondaryColor,
          textColor: textColor,
          textMuted: textMuted,
          bgColor: bgColor,
          cardBg: cardBg,
          borderColor: borderColor,
        ),
      ),
    );
  }

// Update the _buildCurrentScreen method to properly handle course navigation
Widget _buildCurrentScreen(AdaptiveScreenManager adaptive) {
  Widget screen;
  
  switch (_currentScreen) {
    case 'dashboard':
      screen = _buildDashboard(adaptive);
      break;
    case 'courses':
      // Use the dedicated courses screen with proper theming and navigation
      return StudentCoursesScreen(
        courses: _courses,
        isDarkMode: _effectiveIsDark,
        primaryColor: primaryColor,
        secondaryColor: secondaryColor,
        successColor: successColor,
        dangerColor: dangerColor,
        warningColor: warningColor,
        textColor: textColor,
        textMuted: textMuted,
        bgColor: bgColor,
        cardBg: cardBg,
        borderColor: borderColor,
      );
    case 'profile':
      screen = _buildProfile(adaptive);
      break;
    case 'attendance-history':
      return StudentAttendanceHistoryScreen(
        records: _attendanceRecords,
        onBack: _handleBackPress,
        onViewDetail: (record) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => Scaffold(
                backgroundColor: bgColor,
                appBar: AppBar(
                  backgroundColor: primaryColor,
                  elevation: 0,
                  flexibleSpace: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [primaryColor, secondaryColor],
                      ),
                    ),
                  ),
                  title: Text(
                    'Attendance Details',
                    style: TextStyle(
                      fontSize: adaptive.sp(18),
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                  leading: IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () => Navigator.pop(context),
                  ),
                ),
                body: StudentAttendanceDetailScreen(
                  record: record,
                  onBack: () => Navigator.pop(context),
                  isDarkMode: _effectiveIsDark,
                  primaryColor: primaryColor,
                  secondaryColor: secondaryColor,
                  textColor: textColor,
                  textMuted: textMuted,
                  bgColor: bgColor,
                  cardBg: cardBg,
                  borderColor: borderColor,
                ),
              ),
            ),
          );
        },
        isDarkMode: _effectiveIsDark,
        primaryColor: primaryColor,
        secondaryColor: secondaryColor,
        textColor: textColor,
        textMuted: textMuted,
        bgColor: bgColor,
        cardBg: cardBg,
        borderColor: borderColor,
      );
    case 'change-password':
      return _buildChangePasswordScreen(adaptive);
    case 'summary':
      return StudentCalendarScreen(
        isDarkMode: _effectiveIsDark,
        primaryColor: primaryColor,
        secondaryColor: secondaryColor,
        successColor: successColor,
        dangerColor: dangerColor,
        warningColor: warningColor,
        textColor: textColor,
        textMuted: textMuted,
        bgColor: bgColor,
        cardBg: cardBg,
        borderColor: borderColor,
      );
    default:
      screen = _buildDashboard(adaptive);
  }
  
  return Container(
    color: bgColor,
    child: screen,
  );
}

  // Navigate to settings screen as a separate page with its own AppBar
  

  void _navigateToNotifications() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Scaffold(
          appBar: AppBar(
            backgroundColor: primaryColor,
            elevation: 0,
            flexibleSpace: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [primaryColor, secondaryColor],
                ),
              ),
            ),
            title: Text(
              'Notifications',
              style: TextStyle(
                fontSize: context.adaptive.sp(18),
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
            leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.pop(context),
            ),
          ),
          body: StudentNotificationsScreen(
            onBack: () => Navigator.pop(context),
            isDarkMode: _effectiveIsDark,
            primaryColor: primaryColor,
            secondaryColor: secondaryColor,
            textColor: textColor,
            textMuted: textMuted,
            bgColor: bgColor,
            cardBg: cardBg,
            borderColor: borderColor,
          ),
        ),
      ),
    );
  }

  Widget _buildDashboard(AdaptiveScreenManager adaptive) {
    return RefreshIndicator(
      onRefresh: _refreshData,
      color: primaryColor,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: adaptive.responsivePadding(all: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Welcome Card - exact match to HTML
            Container(
              width: double.infinity,
              padding: adaptive.responsivePadding(all: 20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [primaryColor, secondaryColor],
                ),
                borderRadius: adaptive.responsiveBorderRadius(12),
                boxShadow: [
                  BoxShadow(
                    color: _shadowColor,
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Hello, John Doe!',
                    style: TextStyle(
                      fontSize: adaptive.sp(20),
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: adaptive.scale(5)),
                  Text(
                    'Computer Science - Level 300',
                    style: TextStyle(
                      fontSize: adaptive.sp(14),
                      color: Colors.white.withValues(alpha: 0.9),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: adaptive.scale(20)),

            // Quick Stats - exact 3-column layout
            Row(
              children: [
                Expanded(child: _buildStatCard(adaptive, '85%', 'Attendance', successColor)),
                SizedBox(width: adaptive.scale(12)),
                Expanded(child: _buildStatCard(adaptive, '12', 'Present', primaryColor)),
                SizedBox(width: adaptive.scale(12)),
                Expanded(child: _buildStatCard(adaptive, '2', 'Absent', dangerColor)),
              ],
            ),
            SizedBox(height: adaptive.scale(20)),

            // Today's Classes Section
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Today\'s Classes',
                  style: TextStyle(
                    fontSize: adaptive.sp(16),
                    fontWeight: FontWeight.w600,
                    color: textColor,
                  ),
                ),
                GestureDetector(
                  onTap: () => _navigateToScreen('courses'),
                  child: Text(
                    'View All',
                    style: TextStyle(
                      fontSize: adaptive.sp(12),
                      color: primaryColor,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: adaptive.scale(15)),

          // Today's Classes Cards - exact HTML structure
          _buildTodayClassCard(
            adaptive, 
            'Data Structures & Algorithms', 
            'CS301 • Computer Science • Dr. Sarah Wilson', 
            '10:00 AM - 12:00 PM', 
            AttendanceStatus.present, 
            'Already Checked In'
          ),
          SizedBox(height: adaptive.scale(12)),
          _buildTodayClassCard(
            adaptive, 
            'Linear Algebra', 
            'MATH201 • Mathematics • Prof. David Brown', 
            '2:00 PM - 4:00 PM', 
            AttendanceStatus.pending, 
            'Check In Now'
          ),
          SizedBox(height: adaptive.scale(12)),
          _buildTodayClassCard(
            adaptive, 
            'Operating Systems', 
            'CS302 • Computer Science • Dr. Michael Lee', 
            '8:00 AM - 10:00 AM', 
            AttendanceStatus.absent, 
            'Class Ended'
          ),
          SizedBox(height: adaptive.scale(20)),

          // Recent Attendance Section
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Recent Attendance',
                style: TextStyle(
                  fontSize: adaptive.sp(16),
                  fontWeight: FontWeight.w600,
                  color: textColor,
                ),
              ),
              GestureDetector(
                onTap: () => _navigateToScreen('attendance-history'),
                child: Text(
                  'View All',
                  style: TextStyle(
                    fontSize: adaptive.sp(12),
                    color: primaryColor,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: adaptive.scale(15)),

          // Recent Attendance Items
          ..._attendanceRecords.take(3).map((record) => 
            _buildAttendanceItem(adaptive, record)
          ),
        ],
      ),
    ),
  );
}

  Future<void> _refreshData() async {
    setState(() {
      _isLoading = true;
    });
    
    await Future.delayed(const Duration(seconds: 2));
    
    setState(() {
      _isLoading = false;
    });
    
    _showSnackBar(
      'Attendance data refreshed successfully',
      successColor,
      icon: Icons.refresh,
    );
  }

  Widget _buildStatCard(AdaptiveScreenManager adaptive, String number, String label, Color accentColor) {
    return Container(
      padding: adaptive.responsivePadding(all: 15),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: adaptive.responsiveBorderRadius(10),
        boxShadow: [
          BoxShadow(
            color: _shadowColor,
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            number,
            style: TextStyle(
              fontSize: adaptive.sp(20),
              fontWeight: FontWeight.bold,
              color: accentColor,
            ),
          ),
          SizedBox(height: adaptive.scale(5)),
          Text(
            label,
            style: TextStyle(
              fontSize: adaptive.sp(12),
              color: textMuted,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

// Update the course card click handler to navigate to course detail
Widget _buildTodayClassCard(AdaptiveScreenManager adaptive, String title, String subtitle, String time, AttendanceStatus status, String buttonText) {
  String statusText;
  bool canCheckIn = false;
  
  switch (status) {
    case AttendanceStatus.present:
      statusText = 'Present';
      break;
    case AttendanceStatus.absent:
      statusText = 'Absent';
      break;
    case AttendanceStatus.pending:
      statusText = 'Pending';
      canCheckIn = true;
      break;
    case AttendanceStatus.late:
      statusText = 'Late';
      break;
  }

  // Extract course code from subtitle
  String courseCode = subtitle.split(' • ')[0];
  Course? course = _courses.firstWhere((c) => c.code == courseCode, orElse: () => _courses.first);

  return GestureDetector(
    onTap: () {
      // Navigate to course detail
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => Scaffold(
            backgroundColor: bgColor,
            appBar: AppBar(
              backgroundColor: primaryColor,
              elevation: 0,
              flexibleSpace: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [primaryColor, secondaryColor],
                  ),
                ),
              ),
              title: Text(
                course.title,
                style: TextStyle(
                  fontSize: adaptive.sp(18),
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => Navigator.pop(context),
              ),
            ),
            body: StudentCourseDetailScreen(
              course: course,
              onBack: () => Navigator.pop(context),
              isDarkMode: _effectiveIsDark,
              primaryColor: primaryColor,
              secondaryColor: secondaryColor,
              successColor: successColor,
              dangerColor: dangerColor,
              warningColor: warningColor,
              textColor: textColor,
              textMuted: textMuted,
              bgColor: bgColor,
              cardBg: cardBg,
              borderColor: borderColor,
            ),
          ),
        ),
      );
    },
    child: Container(
      padding: adaptive.responsivePadding(all: 15),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: adaptive.responsiveBorderRadius(12),
        border: Border.all(color: borderColor),
        boxShadow: [
          BoxShadow(
            color: const Color(0x1A000000),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: adaptive.sp(16),
                        fontWeight: FontWeight.w600,
                        color: textColor,
                      ),
                    ),
                    SizedBox(height: adaptive.scale(5)),
                    Text(
                      subtitle,
                      style: TextStyle(
                        fontSize: adaptive.sp(13),
                        color: textMuted,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: adaptive.responsivePadding(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: status == AttendanceStatus.present 
                      ? const Color(0xFFD4EDDA)  // HTML: #d4edda
                      : status == AttendanceStatus.absent
                      ? const Color(0xFFF8D7DA)  // HTML: #f8d7da
                      : const Color(0xFFFFF3CD), // HTML: #fff3cd
                  borderRadius: adaptive.responsiveBorderRadius(12),
                ),
                child: Text(
                  statusText,
                  style: TextStyle(
                    fontSize: adaptive.sp(11),
                    fontWeight: FontWeight.w500,
                    color: status == AttendanceStatus.present 
                        ? const Color(0xFF155724)  // HTML: #155724
                        : status == AttendanceStatus.absent
                        ? const Color(0xFF721C24)  // HTML: #721c24
                        : const Color(0xFF856404), // HTML: #856404
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: adaptive.scale(8)),
          Row(
            children: [
              Icon(
                Icons.access_time,
                size: adaptive.responsiveIconSize(14),
                color: textMuted,
              ),
              SizedBox(width: adaptive.scale(5)),
              Text(
                time,
                style: TextStyle(
                  fontSize: adaptive.sp(13),
                  color: textMuted,
                ),
              ),
            ],
          ),
          SizedBox(height: adaptive.scale(8)),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: canCheckIn ? () => _showCheckInModal(courseCode) : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: canCheckIn 
                    ? primaryColor 
                    : borderColor,
                foregroundColor: canCheckIn ? Colors.white : textMuted,
                padding: adaptive.responsivePadding(vertical: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: adaptive.responsiveBorderRadius(6),
                ),
                elevation: 0,
              ),
              child: Text(
                buttonText,
                style: TextStyle(
                  fontSize: adaptive.sp(14),
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

  Widget _buildAttendanceItem(AdaptiveScreenManager adaptive, AttendanceRecord record) {
    IconData statusIcon;
    Color statusColor;
    
    switch (record.status) {
      case AttendanceStatus.present:
        statusIcon = Icons.check_circle;
        statusColor = successColor;
        break;
      case AttendanceStatus.absent:
        statusIcon = Icons.cancel;
        statusColor = dangerColor;
        break;
      case AttendanceStatus.late:
        statusIcon = Icons.access_time;
        statusColor = warningColor;
        break;
      case AttendanceStatus.pending:
        statusIcon = Icons.schedule;
        statusColor = _infoColor;
        break;
    }

    return GestureDetector(
    onTap: () {
      // Navigate to attendance detail
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => Scaffold(
            appBar: AppBar(
              backgroundColor: primaryColor,
              elevation: 0,
              flexibleSpace: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [primaryColor, secondaryColor],
                  ),
                ),
              ),
              title: Text(
                'Attendance Details',
                style: TextStyle(
                  fontSize: adaptive.sp(18),
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => Navigator.pop(context),
              ),
            ),
            body: StudentAttendanceDetailScreen(
              record: record,
              onBack: () => Navigator.pop(context),
              isDarkMode: _effectiveIsDark,
              primaryColor: primaryColor,
              secondaryColor: secondaryColor,
              textColor: textColor,
              textMuted: textMuted,
              bgColor: bgColor,
              cardBg: cardBg,
              borderColor: borderColor,
            ),
          ),
        ),
      );
    },
    child: Container(
      margin: adaptive.responsiveMargin(bottom: 10),
      padding: adaptive.responsivePadding(all: 15),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: adaptive.responsiveBorderRadius(8),
        border: Border.all(color: borderColor),
        boxShadow: [
          BoxShadow(
            color: _shadowColor,
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: adaptive.responsivePadding(all: 8),
            decoration: BoxDecoration(
              color: statusColor.withValues(alpha: 0.1),
              borderRadius: adaptive.responsiveBorderRadius(8),
            ),
            child: Icon(
              statusIcon,
              color: statusColor,
              size: adaptive.responsiveIconSize(20),
            ),
          ),
          SizedBox(width: adaptive.scale(12)),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  record.courseTitle,
                  style: TextStyle(
                    fontSize: adaptive.sp(14),
                    fontWeight: FontWeight.w500,
                    color: textColor,
                  ),
                ),
                SizedBox(height: adaptive.scale(4)),
                Text(
                  '${record.date} • ${record.time} • ${record.status.name.toUpperCase()}',
                  style: TextStyle(
                    fontSize: adaptive.sp(12),
                    color: textMuted,
                  ),
                ),
              ],
            ),
          ),
          Icon(
            Icons.chevron_right,
            color: textMuted,
            size: adaptive.responsiveIconSize(16),
          ),
        ],
      ),
    ),
  );
}

  

  Widget _buildProfile(AdaptiveScreenManager adaptive) {
    return SingleChildScrollView(
      padding: adaptive.responsivePadding(all: 20),
      child: Column(
        children: [
          // Profile header matching HTML exactly
          Container(
            padding: adaptive.responsivePadding(vertical: 25, horizontal: 20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [primaryColor, secondaryColor],
              ),
              borderRadius: adaptive.responsiveBorderRadius(12),
              boxShadow: [
                BoxShadow(
                  color: _shadowColor,
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              children: [
                Stack(
                  children: [
                    Container(
                      width: adaptive.scale(120),
                      height: adaptive.scale(120),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 3),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.2),
                            blurRadius: 20,
                            offset: const Offset(0, 10),
                          ),
                        ],
                      ),
                      child: CircleAvatar(
                        radius: adaptive.scale(58),
                        backgroundColor: primaryColor.withValues(alpha: 0.1),
                        child: _profileImage != null
                            ? ClipOval(
                                child: Image.file(
                                  _profileImage!,
                                  width: adaptive.scale(116),
                                  height: adaptive.scale(116),
                                  fit: BoxFit.cover,
                                  errorBuilder: (context, error, stackTrace) {
                                    return Icon(
                                      Icons.person,
                                      size: adaptive.scale(60),
                                      color: primaryColor,
                                    );
                                  },
                                ),
                              )
                            : ClipOval(
                                child: Image.network(
                                  'https://ui-avatars.com/api/?name=John+Doe&background=667eea&color=fff&size=200',  // Updated
                                  width: adaptive.scale(116),
                                  height: adaptive.scale(116),
                                  fit: BoxFit.cover,
                                  loadingBuilder: (context, child, loadingProgress) {
                                    if (loadingProgress == null) return child;
                                    return Center(
                                      child: CircularProgressIndicator(
                                        value: loadingProgress.expectedTotalBytes != null
                                            ? loadingProgress.cumulativeBytesLoaded /
                                                loadingProgress.expectedTotalBytes!
                                            : null,
                                        color: primaryColor,
                                      ),
                                    );
                                  },
                                  errorBuilder: (context, error, stackTrace) {
                                    return Container(
                                      width: adaptive.scale(116),
                                      height: adaptive.scale(116),
                                      color: primaryColor.withValues(alpha: 0.1),
                                      child: Icon(
                                        Icons.person,
                                        size: adaptive.scale(60),
                                        color: primaryColor,
                                      ),
                                    );
                                  },
                                ),
                              ),
                      ),
                    ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: GestureDetector(
                        onTap: () => _showImagePickerOptions(adaptive),
                        child: Container(
                          width: adaptive.scale(36),
                          height: adaptive.scale(36),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.1),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Icon(
                            Icons.camera_alt,
                            color: primaryColor,
                            size: adaptive.responsiveIconSize(18),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: adaptive.scale(20)),
                Text(
                  'John Doe',
                  style: TextStyle(
                    fontSize: adaptive.sp(20),
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: adaptive.scale(5)),
                Text(
                  'CS2021001 • Computer Science • Level 300',
                  style: TextStyle(
                    fontSize: adaptive.sp(14),
                    color: Colors.white.withValues(alpha: 0.9),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: adaptive.scale(20)),

          // Personal Information Card
          _buildProfileSection(
            adaptive,
            'Personal Information',
            [
              _buildProfileInfoItem(adaptive, 'Email:', 'john.doe@university.edu'),
              _buildProfileInfoItem(adaptive, 'Phone:', '+237 6XX XXX XXX'),
              _buildProfileInfoItem(adaptive, 'Date of Birth:', '15/03/2002'),
              _buildProfileInfoItem(adaptive, 'Department:', 'Computer Science'),
              _buildProfileInfoItem(adaptive, 'Level:', '300'),
            ],
          ),
          SizedBox(height: adaptive.scale(15)),

          // Account Settings Card
          _buildProfileSection(
            adaptive,
            'Account Settings',
            [
              _buildProfileActionItem(adaptive, 'Change Password', () => _navigateToScreen('change-password')),
              _buildProfileActionItem(adaptive, 'Update Facial Data', () => _showFacialDataModal()),
              _buildProfileActionItem(adaptive, 'App Settings', () => _navigateToSettingsScreen()),
              _buildProfileActionItem(adaptive, 'Logout', () => _showLogoutDialog(), isDestructive: true),
            ],
          ),
        ],
      ),
    );
  }

   Widget _buildChangePasswordScreen(AdaptiveScreenManager adaptive) {
  return Container(
    color: bgColor,
    child: SingleChildScrollView(
      padding: adaptive.responsivePadding(all: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Change Password',
            style: TextStyle(
              fontSize: adaptive.sp(18),
              fontWeight: FontWeight.w600,
              color: textColor,
            ),
          ),
          SizedBox(height: adaptive.scale(20)),
          Container(
            padding: adaptive.responsivePadding(all: 20),
            decoration: BoxDecoration(
              color: cardBg,
              borderRadius: adaptive.responsiveBorderRadius(12),
              border: Border.all(color: borderColor),
              boxShadow: [
                BoxShadow(
                  color: _shadowColor,
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Current Password',
                  style: TextStyle(
                    fontSize: adaptive.sp(14),
                    fontWeight: FontWeight.w500,
                    color: textColor,
                  ),
                ),
                SizedBox(height: adaptive.scale(8)),
                TextFormField(
                  obscureText: true,
                  decoration: InputDecoration(
                    hintText: 'Enter current password',
                    border: OutlineInputBorder(
                      borderRadius: adaptive.responsiveBorderRadius(8),
                    ),
                    contentPadding: adaptive.responsivePadding(horizontal: 12, vertical: 12),
                  ),
                ),
                SizedBox(height: adaptive.scale(16)),
                Text(
                  'New Password',
                  style: TextStyle(
                    fontSize: adaptive.sp(14),
                    fontWeight: FontWeight.w500,
                    color: textColor,
                  ),
                ),
                SizedBox(height: adaptive.scale(8)),
                TextFormField(
                  obscureText: true,
                  decoration: InputDecoration(
                    hintText: 'Enter new password',
                    border: OutlineInputBorder(
                      borderRadius: adaptive.responsiveBorderRadius(8),
                    ),
                    contentPadding: adaptive.responsivePadding(horizontal: 12, vertical: 12),
                  ),
                ),
                SizedBox(height: adaptive.scale(16)),
                Text(
                  'Confirm New Password',
                  style: TextStyle(
                    fontSize: adaptive.sp(14),
                    fontWeight: FontWeight.w500,
                    color: textColor,
                  ),
                ),
                SizedBox(height: adaptive.scale(8)),
                TextFormField(
                  obscureText: true,
                  decoration: InputDecoration(
                    hintText: 'Confirm new password',
                    border: OutlineInputBorder(
                      borderRadius: adaptive.responsiveBorderRadius(8),
                    ),
                    contentPadding: adaptive.responsivePadding(horizontal: 12, vertical: 12),
                  ),
                ),
                SizedBox(height: adaptive.scale(24)),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      _showSnackBar(
                        'Password changed successfully!',
                        successColor,
                        icon: Icons.check_circle,
                      );
                      _handleBackPress();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: primaryColor,
                      foregroundColor: Colors.white,
                      padding: adaptive.responsivePadding(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: adaptive.responsiveBorderRadius(8),
                      ),
                    ),
                    child: Text(
                      'Change Password',
                      style: TextStyle(
                        fontSize: adaptive.sp(16),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

  Widget _buildProfileSection(AdaptiveScreenManager adaptive, String title, List<Widget> children) {
    return Container(
      padding: adaptive.responsivePadding(all: 20),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: adaptive.responsiveBorderRadius(12),
        border: Border.all(color: borderColor),
        boxShadow: [
          BoxShadow(
            color: _shadowColor,
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: adaptive.sp(16),
              fontWeight: FontWeight.w600,
              color: textColor,
            ),
          ),
          SizedBox(height: adaptive.scale(15)),
          ...children,
        ],
      ),
    );
  }

  Widget _buildProfileInfoItem(AdaptiveScreenManager adaptive, String label, String value) {
    return Padding(
      padding: adaptive.responsivePadding(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: adaptive.sp(14),
              color: textMuted,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: adaptive.sp(14),
              color: textColor,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileActionItem(AdaptiveScreenManager adaptive, String title, VoidCallback onTap, {bool isDestructive = false}) {
    return InkWell(
      onTap: onTap,
      borderRadius: adaptive.responsiveBorderRadius(8),
      child: Padding(
        padding: adaptive.responsivePadding(vertical: 12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              title,
              style: TextStyle(
                fontSize: adaptive.sp(14),
                color: isDestructive ? dangerColor : textColor,
              ),
            ),
            Icon(
              Icons.chevron_right,
              size: adaptive.responsiveIconSize(16),
              color: isDestructive ? dangerColor : textMuted,
            ),
          ],
        ),
      ),
    );
  }

  void _showImagePickerOptions(AdaptiveScreenManager adaptive) {
    showModalBottomSheet(
      context: context,
      backgroundColor: cardBg,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(adaptive.scale(20)),
        ),
      ),
      builder: (BuildContext context) {
        return Container(
          padding: adaptive.responsivePadding(all: 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: adaptive.scale(40),
                height: adaptive.scale(4),
                decoration: BoxDecoration(
                  color: borderColor,
                  borderRadius: adaptive.responsiveBorderRadius(2),
                ),
              ),
              SizedBox(height: adaptive.scale(20)),
              Text(
                'Change Profile Picture',
                style: TextStyle(
                  fontSize: adaptive.sp(18),
                  fontWeight: FontWeight.bold,
                  color: textColor,
                ),
              ),
              SizedBox(height: adaptive.scale(20)),
              ListTile(
                leading: Icon(Icons.camera_alt, color: primaryColor),
                title: Text(
                  'Take Photo',
                  style: TextStyle(
                    fontSize: adaptive.sp(16),
                    color: textColor,
                  ),
                ),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.camera);
                },
              ),
              ListTile(
                leading: Icon(Icons.photo_library, color: primaryColor),
                title: Text(
                  'Choose from Gallery',
                  style: TextStyle(
                    fontSize: adaptive.sp(16),
                    color: textColor,
                  ),
                ),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.gallery);
                },
              ),
              if (_profileImage != null)
                ListTile(
                  leading: Icon(Icons.delete, color: dangerColor),
                  title: Text(
                    'Remove Photo',
                    style: TextStyle(
                      fontSize: adaptive.sp(16),
                      color: dangerColor,
                    ),
                  ),
                  onTap: () {
                    Navigator.pop(context);
                    _removePhoto();
                  },
                ),
              ListTile(
                leading: Icon(Icons.close, color: textMuted),
                title: Text(
                  'Cancel',
                  style: TextStyle(
                    fontSize: adaptive.sp(16),
                    color: textMuted,
                  ),
                ),
                onTap: () => Navigator.pop(context),
              ),
              SizedBox(height: adaptive.scale(20)),
            ],
          ),
        );
      },
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? image = await _picker.pickImage(source: source);
      if (image != null) {
        setState(() {
          _profileImage = File(image.path);
        });
        _showSnackBar(
          'Profile image updated successfully!',
          successColor,
          icon: Icons.check_circle,
        );
      }
    } catch (e) {
      _showSnackBar(
        'Failed to pick image. Please try again.',
        dangerColor,
        icon: Icons.error,
        action: SnackBarAction(
          label: 'Retry',
          textColor: Colors.white,
          onPressed: () => _pickImage(source),
        ),
      );
    }
  }

  void _removePhoto() {
    setState(() {
      _profileImage = null;
    });
    _showSnackBar(
      'Profile picture removed',
      successColor,
      icon: Icons.delete,
    );
  }

  void _showSnackBar(String message, Color backgroundColor, {IconData? icon, SnackBarAction? action}) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              if (icon != null) ...[
                Icon(icon, color: Colors.white),
                const SizedBox(width: 8),
              ],
              Expanded(child: Text(message)),
            ],
          ),
          backgroundColor: backgroundColor,
          duration: const Duration(seconds: 3),
          action: action,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  void _navigateToScreen(String screen) {
  setState(() {
    // Only add to history if we're not going to a main tab
    if (!['dashboard', 'courses', 'profile', 'summary'].contains(screen)) {
      if (_navigationHistory.isEmpty || _navigationHistory.last != _currentScreen) {
        _navigationHistory.add(_currentScreen);
      }
    } else {
      // Clear history when navigating to main tabs
      _navigationHistory.clear();
    }
    
    _currentScreen = screen;
    
    // Update bottom nav index for main tabs
    switch (screen) {
      case 'dashboard':
        _currentIndex = 0;
        break;
      case 'courses':
        _currentIndex = 1;
        break;
      case 'summary':
        _currentIndex = 2;
        break;
      case 'profile':
        _currentIndex = 3;
        break;
    }
  });
}

  bool _shouldShowBottomNav() {
    return ['dashboard', 'courses', 'summary', 'profile'].contains(_currentScreen);
  }

  bool _shouldShowBackButton() {
    return _navigationHistory.isNotEmpty && !['dashboard', 'courses', 'profile', 'summary'].contains(_currentScreen);
  }

  String _getScreenTitle([String? screen]) {
  final targetScreen = screen ?? _currentScreen;
  switch (targetScreen) {
    case 'dashboard': return 'My Attendance';
    case 'courses': return 'My Courses';
    case 'profile': return 'My Profile';
    case 'attendance-history': return 'Attendance Records';
    case 'settings': return 'Settings';
    case 'change-password': return 'Change Password';
    case 'summary': return 'Attendance Summary';
    default: return 'AttendEase';
  }
}

  void _handleBackPress() {
  setState(() {
    if (_navigationHistory.isNotEmpty) {
      String previousScreen = _navigationHistory.removeLast();
      _currentScreen = previousScreen;
      
      // Update bottom nav index if returning to main tab
      switch (previousScreen) {
        case 'dashboard':
          _currentIndex = 0;
          break;
        case 'courses':
          _currentIndex = 1;
          break;
        case 'summary':
          _currentIndex = 2;
          break;
        case 'profile':
          _currentIndex = 3;
          break;
      }
    } else {
      // If no history, default to dashboard
      _currentScreen = 'dashboard';
      _currentIndex = 0;
    }
  });
}

void _handleSystemBackPress() {
  if (_shouldShowBackButton()) {
    // If we're on a sub-screen, go back to previous screen
    _handleBackPress();
  } else if (_currentScreen != 'dashboard') {
    // If we're on a main screen but not dashboard, go to dashboard
    setState(() {
      _currentScreen = 'dashboard';
      _currentIndex = 0;
      _navigationHistory.clear();
    });
  } else {
    // If we're on dashboard, implement double-press to exit
    final now = DateTime.now();
    if (_lastBackPressed == null || now.difference(_lastBackPressed!) > const Duration(seconds: 2)) {
      _lastBackPressed = now;
      _showSnackBar(
        'Press back again to exit',
        warningColor,
        icon: Icons.exit_to_app,
      );
    } else {
      _showExitConfirmationDialog();
    }
  }
}

// Fix the check-in modal method signature
void _showCheckInModal(String courseCode) {
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (BuildContext context) {
      return StudentCheckInModal(
        courseCode: courseCode,
        onSuccess: () {
          setState(() {
            // Update UI to show checked in
          });
          _showSnackBar(
            'Successfully checked in to $courseCode',
            successColor,
            icon: Icons.check_circle,
          );
        },
        primaryColor: primaryColor,
        textColor: textColor,
        textMuted: textMuted,
        bgColor: bgColor,
        cardBg: cardBg,
        isDarkMode: _effectiveIsDark,
      );
    },
  );
}

  void _showFacialDataModal() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        final adaptive = context.adaptive;
        
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            decoration: BoxDecoration(
              color: cardBg,
              borderRadius: adaptive.responsiveBorderRadius(12),
            ),
            padding: adaptive.responsivePadding(all: 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Update Facial Data',
                  style: TextStyle(
                    fontSize: adaptive.sp(18),
                    fontWeight: FontWeight.w600,
                    color: textColor,
                  ),
                ),
                SizedBox(height: adaptive.scale(10)),
                Text(
                  'For secure attendance check-in',
                  style: TextStyle(
                    fontSize: adaptive.sp(14),
                    color: textMuted,
                  ),
                ),
                SizedBox(height: adaptive.scale(20)),
                
                Container(
                  width: adaptive.scale(200),
                  height: adaptive.scale(200),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: primaryColor,
                      width: 2,
                      style: BorderStyle.solid,
                    ),
                    borderRadius: adaptive.responsiveBorderRadius(8),
                    color: const Color(0xFFF8F9FA),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.person,
                        size: adaptive.responsiveIconSize(40),
                        color: primaryColor,
                      ),
                      SizedBox(height: adaptive.scale(10)),
                      Text(
                        'Position your face in the frame',
                        style: TextStyle(
                          fontSize: adaptive.sp(14),
                          color: textMuted,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
                SizedBox(height: adaptive.scale(15)),
                
                Text(
                  'Please ensure good lighting and remove any face coverings',
                  style: TextStyle(
                    fontSize: adaptive.sp(13),
                    color: textMuted,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: adaptive.scale(20)),
                
                Column(
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                          _showSnackBar(
                            'Facial data update started',
                            primaryColor,
                            icon: Icons.face,
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: primaryColor,
                          foregroundColor: Colors.white,
                          padding: adaptive.responsivePadding(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: adaptive.responsiveBorderRadius(8),
                          ),
                        ),
                        child: Text(
                          'Capture New Image',
                          style: TextStyle(
                            fontSize: adaptive.sp(16),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: adaptive.scale(10)),
                    SizedBox(
                      width: double.infinity,
                      child: TextButton(
                        onPressed: () => Navigator.of(context).pop(),
                        style: TextButton.styleFrom(
                          backgroundColor: borderColor,
                          foregroundColor: textColor,
                          padding: adaptive.responsivePadding(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: adaptive.responsiveBorderRadius(8),
                          ),
                        ),
                        child: Text(
                          'Cancel',
                          style: TextStyle(
                            fontSize: adaptive.sp(16),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              Icon(Icons.logout, color: dangerColor),
              const SizedBox(width: 8),
              const Text('Logout'),
            ],
          ),
          content: const Text('Are you sure you want to logout? You will need to sign in again to access your attendance data.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                Navigator.of(context).pop();
                setState(() {
                  _isLoading = true;
                });
                
                await UserDataService.setCurrentUserRole(UserRole.student);
                
                if (mounted && context.mounted) {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const HomepageScreen(),
                    ),
                    (route) => false,
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: dangerColor,
                foregroundColor: Colors.white,
              ),
              child: const Text('Logout'),
            ),
          ],
        );
      },
    );
  }

void _showExitConfirmationDialog() {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        backgroundColor: cardBg,
        title: Row(
          children: [
            Icon(Icons.exit_to_app, color: warningColor),
            const SizedBox(width: 8),
            Text('Exit App', style: TextStyle(color: textColor)),
          ],
        ),
        content: Text(
          'Are you sure you want to exit the app? You will remain logged in for your next session.',
          style: TextStyle(color: textColor),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Cancel', style: TextStyle(color: textColor)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              // Exit the app
              SystemNavigator.pop();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: warningColor,
              foregroundColor: Colors.white,
            ),
            child: const Text('Exit'),
          ),
        ],
      );
    },
  );
}

Widget _buildNavigationBreadcrumb(AdaptiveScreenManager adaptive) {
  if (_navigationHistory.isEmpty) return const SizedBox.shrink();
  
  return Row(
    children: [
      Icon(Icons.arrow_back_ios, size: adaptive.responsiveIconSize(12), color: Colors.white70),
      SizedBox(width: adaptive.scale(5)),
      Text(
        _getScreenTitle(_navigationHistory.last),
        style: TextStyle(
          fontSize: adaptive.sp(12),
          color: Colors.white70,
        ),
      ),
    ],
  );
}

  Widget _buildBottomNav(AdaptiveScreenManager adaptive) {
    return Container(
      decoration: BoxDecoration(
        color: cardBg,
        border: Border(top: BorderSide(color: borderColor)),
        boxShadow: [
          BoxShadow(
            color: _shadowColor,
            blurRadius: 20,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
            switch (index) {
              case 0:
                _currentScreen = 'dashboard';
                break;
              case 1:
                _currentScreen = 'courses';
                break;
              case 2:
                _currentScreen = 'summary';
                break;
              case 3:
                _currentScreen = 'profile';
                break;
            }
          });
        },
        backgroundColor: cardBg,
        selectedItemColor: primaryColor,
        unselectedItemColor: textMuted,
        selectedLabelStyle: TextStyle(
          fontSize: adaptive.sp(10),
          fontWeight: FontWeight.w600,
        ),
        unselectedLabelStyle: TextStyle(
          fontSize: adaptive.sp(10),
        ),
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(
            icon: Text('🏠', style: TextStyle(fontSize: 24)),
            label: 'Home',
            tooltip: 'View dashboard and today\'s classes',
          ),
          BottomNavigationBarItem(
            icon: Text('📚', style: TextStyle(fontSize: 24)),
            label: 'Courses',
            tooltip: 'View all enrolled courses',
          ),
          BottomNavigationBarItem(
            icon: Text('📊', style: TextStyle(fontSize: 24)),
            label: 'Summary',
            tooltip: 'View attendance summary and calendar',
          ),
          BottomNavigationBarItem(
            icon: Text('👤', style: TextStyle(fontSize: 24)),
            label: 'Profile',
            tooltip: 'Manage your profile and settings',
          ),
        ],
      ),
    );
  }
}
