import 'package:flutter/material.dart';
import '../../utils/adaptive_screen_manager.dart';

class StudentNotificationsScreen extends StatefulWidget {
  final Color secondaryColor;
  final Color primaryColor;
  final bool isDarkMode;
  final VoidCallback onBack;
  final Color textColor;
  final Color textMuted;
  final Color bgColor;
  final Color cardBg;
  final Color borderColor;

  const StudentNotificationsScreen({
    super.key,
    required this.secondaryColor,
    required this.primaryColor,
    required this.isDarkMode,
    required this.onBack,
    required this.textColor,
    required this.textMuted,
    required this.bgColor,
    required this.cardBg,
    required this.borderColor,
  });

  @override
  State<StudentNotificationsScreen> createState() => _StudentNotificationsScreenState();
}

class _StudentNotificationsScreenState extends State<StudentNotificationsScreen> {
  final List<StudentNotification> _notifications = [
    StudentNotification(
      id: '1',
      title: 'Class Reminder',
      message: 'Linear Algebra class starts in 30 minutes',
      type: NotificationType.reminder,
      time: '30 min ago',
      isRead: false,
      courseCode: 'MATH201',
    ),
    StudentNotification(
      id: '2',
      title: 'Attendance Warning',
      message: 'Your attendance in Operating Systems is below 75%',
      type: NotificationType.warning,
      time: '2 hours ago',
      isRead: false,
      courseCode: 'CS302',
    ),
    StudentNotification(
      id: '3',
      title: 'Check-in Successful',
      message: 'Successfully checked into Data Structures class',
      type: NotificationType.success,
      time: '1 day ago',
      isRead: true,
      courseCode: 'CS301',
    ),
    StudentNotification(
      id: '4',
      title: 'Schedule Update',
      message: 'Technical Writing class moved to Room 205',
      type: NotificationType.info,
      time: '2 days ago',
      isRead: true,
      courseCode: 'ENG101',
    ),
    StudentNotification(
      id: '5',
      title: 'Missed Class',
      message: 'You missed Operating Systems class today',
      type: NotificationType.alert,
      time: '3 days ago',
      isRead: true,
      courseCode: 'CS302',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    final unreadCount = _notifications.where((n) => !n.isRead).length;

    return Scaffold(
      backgroundColor: widget.bgColor,
      body: Column(
        children: [
          _buildNotificationsHeader(adaptive, unreadCount),
          Expanded(
            child: SingleChildScrollView(
              padding: adaptive.responsivePadding(all: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (unreadCount > 0) ...[
                    _buildUnreadSection(adaptive),
                    SizedBox(height: adaptive.scale(25)),
                  ],
                  _buildAllNotifications(adaptive),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationsHeader(AdaptiveScreenManager adaptive, int unreadCount) {
    return Container(
      padding: adaptive.responsivePadding(all: 20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [widget.primaryColor, widget.secondaryColor],
        ),
      ),
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Notifications',
                  style: TextStyle(
                    fontSize: adaptive.sp(24),
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                if (unreadCount > 0)
                  Container(
                    padding: adaptive.responsivePadding(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFF9800),
                      borderRadius: adaptive.responsiveBorderRadius(20),
                    ),
                    child: Text(
                      '$unreadCount new',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: adaptive.sp(12),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
              ],
            ),
            SizedBox(height: adaptive.scale(10)),
            Text(
              'Stay updated with your classes and attendance',
              style: TextStyle(
                fontSize: adaptive.sp(14),
                color: Colors.white.withValues(alpha: 0.8),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUnreadSection(AdaptiveScreenManager adaptive) {
    final unreadNotifications = _notifications.where((n) => !n.isRead).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Unread (${unreadNotifications.length})',
              style: TextStyle(
                fontSize: adaptive.sp(18),
                fontWeight: FontWeight.bold,
                color: widget.textColor,
              ),
            ),
            TextButton(
              onPressed: () {
                setState(() {
                  for (var notification in _notifications) {
                    notification.isRead = true;
                  }
                });
              },
              child: Text(
                'Mark all as read',
                style: TextStyle(
                  fontSize: adaptive.sp(14),
                  color: widget.primaryColor,
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: adaptive.scale(15)),
        ...unreadNotifications.map((notification) => 
          _buildNotificationCard(adaptive, notification)
        ),
      ],
    );
  }

  Widget _buildAllNotifications(AdaptiveScreenManager adaptive) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'All Notifications',
          style: TextStyle(
            fontSize: adaptive.sp(18),
            fontWeight: FontWeight.bold,
            color: widget.textColor,
          ),
        ),
        SizedBox(height: adaptive.scale(15)),
        ..._notifications.map((notification) => 
          _buildNotificationCard(adaptive, notification)
        ),
      ],
    );
  }

  Widget _buildNotificationCard(AdaptiveScreenManager adaptive, StudentNotification notification) {
    Color typeColor;
    IconData typeIcon;

    switch (notification.type) {
      case NotificationType.reminder:
        typeColor = widget.primaryColor;
        typeIcon = Icons.schedule;
        break;
      case NotificationType.warning:
        typeColor = const Color(0xFFFF9800);
        typeIcon = Icons.warning;
        break;
      case NotificationType.success:
        typeColor = const Color(0xFF4CAF50);
        typeIcon = Icons.check_circle;
        break;
      case NotificationType.info:
        typeColor = widget.primaryColor;
        typeIcon = Icons.info;
        break;
      case NotificationType.alert:
        typeColor = const Color(0xFFF44336);
        typeIcon = Icons.error;
        break;
    }

    return Container(
      margin: adaptive.responsiveMargin(bottom: 12),
      decoration: BoxDecoration(
        color: widget.cardBg,
        borderRadius: adaptive.responsiveBorderRadius(12),
        border: Border.all(
          color: notification.isRead 
              ? widget.borderColor
              : typeColor.withValues(alpha: 0.3),
          width: notification.isRead ? 1 : 2,
        ),
        boxShadow: [
          BoxShadow(
            color: widget.isDarkMode 
                ? Colors.black.withValues(alpha: 0.3)
                : Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ListTile(
        contentPadding: adaptive.responsivePadding(all: 16),
        leading: Container(
          padding: adaptive.responsivePadding(all: 8),
          decoration: BoxDecoration(
            color: typeColor.withValues(alpha: 0.1),
            borderRadius: adaptive.responsiveBorderRadius(8),
          ),
          child: Icon(
            typeIcon,
            color: typeColor,
            size: adaptive.responsiveIconSize(20),
          ),
        ),
        title: Text(
          notification.title,
          style: TextStyle(
            fontSize: adaptive.sp(16),
            fontWeight: notification.isRead ? FontWeight.w500 : FontWeight.bold,
            color: widget.textColor,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: adaptive.scale(4)),
            Text(
              notification.message,
              style: TextStyle(
                fontSize: adaptive.sp(14),
                color: widget.textMuted,
              ),
            ),
            SizedBox(height: adaptive.scale(8)),
            Row(
              children: [
                if (notification.courseCode != null) ...[
                  Container(
                    padding: adaptive.responsivePadding(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: typeColor.withValues(alpha: 0.1),
                      borderRadius: adaptive.responsiveBorderRadius(12),
                    ),
                    child: Text(
                      notification.courseCode!,
                      style: TextStyle(
                        fontSize: adaptive.sp(11),
                        color: typeColor,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  SizedBox(width: adaptive.scale(8)),
                ],
                Text(
                  notification.time,
                  style: TextStyle(
                    fontSize: adaptive.sp(12),
                    color: widget.textMuted,
                  ),
                ),
              ],
            ),
          ],
        ),
        trailing: !notification.isRead
            ? Container(
                width: adaptive.scale(8),
                height: adaptive.scale(8),
                decoration: BoxDecoration(
                  color: typeColor,
                  shape: BoxShape.circle,
                ),
              )
            : null,
        onTap: () {
          setState(() {
            notification.isRead = true;
          });
        },
      ),
    );
  }
}

class StudentNotification {
  final String id;
  final String title;
  final String message;
  final NotificationType type;
  final String time;
  bool isRead;
  final String? courseCode;

  StudentNotification({
    required this.id,
    required this.title,
    required this.message,
    required this.type,
    required this.time,
    required this.isRead,
    this.courseCode,
  });
}

enum NotificationType {
  reminder,
  warning,
  success,
  info,
  alert,
}
