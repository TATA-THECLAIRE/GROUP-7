import 'package:flutter/material.dart';
import '../../utils/adaptive_screen_manager.dart';
import 'student_models.dart';
import 'student_course_detail_screen.dart';

class StudentCoursesScreen extends StatelessWidget {
  final List<Course> courses;
  final bool isDarkMode;
  final Color primaryColor;
  final Color secondaryColor;
  final Color successColor;
  final Color dangerColor;
  final Color warningColor;
  final Color textColor;
  final Color textMuted;
  final Color bgColor;
  final Color cardBg;
  final Color borderColor;

  const StudentCoursesScreen({
    super.key,
    required this.courses,
    required this.isDarkMode,
    required this.primaryColor,
    required this.secondaryColor,
    required this.successColor,
    required this.dangerColor,
    this.warningColor = const Color(0xFFFFC107),
    required this.textColor,
    required this.textMuted,
    required this.bgColor,
    required this.cardBg,
    required this.borderColor,
  });

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;

    return Container(
      color: bgColor, // Apply dark mode background
      child: SingleChildScrollView(
        padding: adaptive.responsivePadding(all: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'My Courses',
                  style: TextStyle(
                    fontSize: adaptive.sp(16),
                    fontWeight: FontWeight.w600,
                    color: textColor,
                  ),
                ),
                Text(
                  'Semester 1, 2024',
                  style: TextStyle(
                    fontSize: adaptive.sp(12),
                    fontWeight: FontWeight.normal,
                    color: textMuted,
                  ),
                ),
              ],
            ),
            SizedBox(height: adaptive.scale(15)),
            ...courses.map((course) => _buildCourseCard(adaptive, course, context)),
          ],
        ),
      ),
    );
  }

  Widget _buildCourseCard(AdaptiveScreenManager adaptive, Course course, BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Scaffold(
              backgroundColor: bgColor,
              appBar: AppBar(
                backgroundColor: primaryColor,
                elevation: 0,
                flexibleSpace: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [primaryColor, secondaryColor],
                    ),
                  ),
                ),
                title: Text(
                  course.title,
                  style: TextStyle(
                    fontSize: adaptive.sp(18),
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
                leading: IconButton(
                  icon: const Icon(Icons.arrow_back, color: Colors.white),
                  onPressed: () => Navigator.pop(context),
                ),
              ),
              body: StudentCourseDetailScreen(
                course: course,
                onBack: () => Navigator.pop(context),
                isDarkMode: isDarkMode,
                primaryColor: primaryColor,
                secondaryColor: secondaryColor,
                successColor: successColor,
                dangerColor: dangerColor,
                warningColor: warningColor,
                textColor: textColor,
                textMuted: textMuted,
                bgColor: bgColor,
                cardBg: cardBg,
                borderColor: borderColor,
              ),
            ),
          ),
        );
      },
      child: Container(
        margin: adaptive.responsiveMargin(bottom: 12),
        padding: adaptive.responsivePadding(all: 15),
        decoration: BoxDecoration(
          color: cardBg,
          borderRadius: adaptive.responsiveBorderRadius(12),
          border: Border.all(color: borderColor),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.1),
              blurRadius: 6,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              course.title,
              style: TextStyle(
                fontSize: adaptive.sp(16),
                fontWeight: FontWeight.w600,
                color: textColor,
              ),
            ),
            SizedBox(height: adaptive.scale(5)),
            Text(
              '${course.code} • ${course.department} • ${course.lecturer}',
              style: TextStyle(
                fontSize: adaptive.sp(13),
                color: textMuted,
              ),
            ),
            SizedBox(height: adaptive.scale(10)),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Attendance',
                      style: TextStyle(
                        fontSize: adaptive.sp(12),
                        color: textMuted,
                      ),
                    ),
                    Text(
                      '${course.attendance}%',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: course.attendance >= 75 ? successColor : dangerColor,
                        fontSize: adaptive.sp(14),
                      ),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      'Next Class',
                      style: TextStyle(
                        fontSize: adaptive.sp(12),
                        color: textMuted,
                      ),
                    ),
                    Text(
                      course.nextClass,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: textColor,
                        fontSize: adaptive.sp(14),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
