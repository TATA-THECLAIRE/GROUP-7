import 'package:flutter/material.dart';
import '../../utils/adaptive_screen_manager.dart';
import 'student_models.dart';

class StudentCourseDetailScreen extends StatefulWidget {
  final Course course;
  final VoidCallback onBack;
  final bool isDarkMode;
  final Color primaryColor;
  final Color secondaryColor;
  final Color successColor;
  final Color dangerColor;
  final Color warningColor;
  final Color textColor;
  final Color textMuted;
  final Color bgColor;
  final Color cardBg;
  final Color borderColor;

  const StudentCourseDetailScreen({
    super.key,
    required this.course,
    required this.onBack,
    required this.isDarkMode,
    required this.primaryColor,
    required this.secondaryColor,
    required this.successColor,
    required this.dangerColor,
    this.warningColor = const Color(0xFFFFC107),
    required this.textColor,
    required this.textMuted,
    required this.bgColor,
    required this.cardBg,
    required this.borderColor,
  });

  @override
  State<StudentCourseDetailScreen> createState() => _StudentCourseDetailScreenState();
}

class _StudentCourseDetailScreenState extends State<StudentCourseDetailScreen> {
  int currentMonth = DateTime.now().month - 1; // 0-based
  int currentYear = DateTime.now().year;

  final List<String> monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;

    return Scaffold(
      backgroundColor: widget.bgColor, // Apply dark mode background
      body: Container(
        color: widget.bgColor, // Ensure full background coverage
        child: SingleChildScrollView(
          padding: adaptive.responsivePadding(all: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildCourseHeader(adaptive),
              SizedBox(height: adaptive.scale(20)),
              _buildAttendanceSummary(adaptive),
              SizedBox(height: adaptive.scale(20)),
              _buildCalendar(adaptive), // Fixed calendar implementation
              SizedBox(height: adaptive.scale(20)),
              _buildAttendanceHistory(adaptive),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCourseHeader(AdaptiveScreenManager adaptive) {
    return Row(
      children: [
        Container(
          width: adaptive.scale(50),
          height: adaptive.scale(50),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [widget.primaryColor, widget.secondaryColor],
            ),
            borderRadius: adaptive.responsiveBorderRadius(8),
          ),
          child: Center(
            child: Text(
              widget.course.code.substring(0, 2).toUpperCase(),
              style: TextStyle(
                color: Colors.white,
                fontSize: adaptive.sp(20),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        SizedBox(width: adaptive.scale(15)),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.course.title,
                style: TextStyle(
                  fontSize: adaptive.sp(18),
                  fontWeight: FontWeight.w600,
                  color: widget.textColor,
                ),
              ),
              SizedBox(height: adaptive.scale(5)),
              Text(
                '${widget.course.code} • ${widget.course.lecturer}',
                style: TextStyle(
                  fontSize: adaptive.sp(14),
                  color: widget.textMuted,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildAttendanceSummary(AdaptiveScreenManager adaptive) {
    return Container(
      padding: adaptive.responsivePadding(all: 20),
      decoration: BoxDecoration(
        color: widget.cardBg,
        borderRadius: adaptive.responsiveBorderRadius(12),
        border: Border.all(color: widget.borderColor),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Attendance Summary',
            style: TextStyle(
              fontSize: adaptive.sp(16),
              fontWeight: FontWeight.w600,
              color: widget.textColor,
            ),
          ),
          SizedBox(height: adaptive.scale(20)),
          Row(
            children: [
              Expanded(
                child: _buildSummaryCard(adaptive, 'Attendance', '${widget.course.attendance}%', widget.successColor),
              ),
              SizedBox(width: adaptive.scale(15)),
              Expanded(
                child: _buildSummaryCard(adaptive, 'Sessions Attended', '${widget.course.present}/${widget.course.total}', widget.primaryColor),
              ),
            ],
          ),
          SizedBox(height: adaptive.scale(15)),
          Row(
            children: [
              Expanded(
                child: _buildSummaryCard(adaptive, 'On Time', '${widget.course.present - widget.course.late}', widget.primaryColor),
              ),
              SizedBox(width: adaptive.scale(15)),
              Expanded(
                child: _buildSummaryCard(adaptive, 'Late', '${widget.course.late}', widget.warningColor),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryCard(AdaptiveScreenManager adaptive, String title, String value, Color color) {
    return Container(
      padding: adaptive.responsivePadding(all: 15),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.05),
        borderRadius: adaptive.responsiveBorderRadius(8),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      child: Column(
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: adaptive.sp(14),
              color: widget.textMuted,
            ),
          ),
          SizedBox(height: adaptive.scale(5)),
          Text(
            value,
            style: TextStyle(
              fontSize: adaptive.sp(24),
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  // FIXED: Complete calendar implementation matching HTML exactly
  Widget _buildCalendar(AdaptiveScreenManager adaptive) {
    return Container(
      padding: adaptive.responsivePadding(all: 15),
      decoration: BoxDecoration(
        color: widget.cardBg,
        borderRadius: adaptive.responsiveBorderRadius(10),
        border: Border.all(color: widget.borderColor),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          _buildCalendarHeader(adaptive),
          SizedBox(height: adaptive.scale(15)),
          _buildCalendarGrid(adaptive),
        ],
      ),
    );
  }

  Widget _buildCalendarHeader(AdaptiveScreenManager adaptive) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          '${monthNames[currentMonth]} $currentYear',
          style: TextStyle(
            fontSize: adaptive.sp(16),
            fontWeight: FontWeight.w600,
            color: widget.textColor,
          ),
        ),
        Row(
          children: [
            IconButton(
              onPressed: () => _changeMonth(-1),
              icon: const Icon(Icons.chevron_left),
              iconSize: adaptive.responsiveIconSize(16),
              color: widget.textMuted,
            ),
            IconButton(
              onPressed: () => _changeMonth(1),
              icon: const Icon(Icons.chevron_right),
              iconSize: adaptive.responsiveIconSize(16),
              color: widget.textMuted,
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildCalendarGrid(AdaptiveScreenManager adaptive) {
    return Column(
      children: [
        // Day headers - exactly like HTML
        Container(
          margin: adaptive.responsiveMargin(bottom: 10),
          child: Row(
            children: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
                .map((day) => Expanded(
                      child: Center(
                        child: Text(
                          day,
                          style: TextStyle(
                            fontSize: adaptive.sp(12),
                            fontWeight: FontWeight.w600,
                            color: widget.textMuted,
                          ),
                        ),
                      ),
                    ))
                .toList(),
          ),
        ),
        // Calendar days grid - matching HTML layout exactly
        ..._buildCalendarRows(adaptive),
      ],
    );
  }

  List<Widget> _buildCalendarRows(AdaptiveScreenManager adaptive) {
    final rows = <Widget>[];
    final daysInMonth = DateTime(currentYear, currentMonth + 2, 0).day;
    final firstDayOfMonth = DateTime(currentYear, currentMonth + 1, 1);
    final startingWeekday = firstDayOfMonth.weekday % 7;
    
    int dayCounter = 1;
    
    // Generate weeks (max 6 weeks to cover all possible month layouts)
    for (int week = 0; week < 6; week++) {
      final weekDays = <Widget>[];
      
      for (int dayOfWeek = 0; dayOfWeek < 7; dayOfWeek++) {
        Widget dayWidget;
        
        if (week == 0 && dayOfWeek < startingWeekday) {
          // Empty cells before month starts
          dayWidget = Expanded(child: Container());
        } else if (dayCounter <= daysInMonth) {
          // Valid days in month
          dayWidget = Expanded(
            child: _buildCalendarDay(adaptive, dayCounter),
          );
          dayCounter++;
        } else {
          // Empty cells after month ends
          dayWidget = Expanded(child: Container());
        }
        
        weekDays.add(dayWidget);
      }
      
      rows.add(
        Container(
          margin: adaptive.responsiveMargin(bottom: 5),
          child: Row(children: weekDays),
        ),
      );
      
      // Stop if we've shown all days
      if (dayCounter > daysInMonth) break;
    }
    
    return rows;
  }

  Widget _buildCalendarDay(AdaptiveScreenManager adaptive, int day) {
    final isToday = day == 15; // Simulate today being the 15th
    final isPresent = [9, 13, 15].contains(day);
    final isAbsent = [10].contains(day);
    final isLate = [12].contains(day);
    
    Color? dayBgColor;
    Color dayTextColor = widget.textColor;
    
    if (isToday) {
      dayBgColor = widget.primaryColor;
      dayTextColor = Colors.white;
    }
    
    return Container(
      height: adaptive.scale(35),
      margin: adaptive.responsiveMargin(all: 1),
      decoration: BoxDecoration(
        color: dayBgColor,
        borderRadius: adaptive.responsiveBorderRadius(6),
      ),
      child: Stack(
        children: [
          Center(
            child: Text(
              day.toString(),
              style: TextStyle(
                fontSize: adaptive.sp(12),
                fontWeight: isToday ? FontWeight.bold : FontWeight.normal,
                color: dayTextColor,
              ),
            ),
          ),
          // Attendance indicator dot - exactly like HTML
          if (isPresent || isAbsent || isLate)
            Positioned(
              bottom: 2,
              left: 0,
              right: 0,
              child: Center(
                child: Container(
                  width: 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: isPresent 
                      ? widget.successColor 
                      : isAbsent 
                        ? widget.dangerColor 
                        : widget.warningColor,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildAttendanceHistory(AdaptiveScreenManager adaptive) {
    return Container(
      padding: adaptive.responsivePadding(all: 20),
      decoration: BoxDecoration(
        color: widget.cardBg,
        borderRadius: adaptive.responsiveBorderRadius(12),
        border: Border.all(color: widget.borderColor),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Attendance History',
            style: TextStyle(
              fontSize: adaptive.sp(16),
              fontWeight: FontWeight.w600,
              color: widget.textColor,
            ),
          ),
          SizedBox(height: adaptive.scale(15)),
          _buildHistoryItem(adaptive, 'Week 10: Linked Lists', 'May 15, 2024 • 10:00 AM • Present', Icons.check, widget.successColor),
          _buildHistoryItem(adaptive, 'Week 9: Trees', 'May 8, 2024 • 10:00 AM • Present', Icons.check, widget.successColor),
          _buildHistoryItem(adaptive, 'Week 8: Stacks & Queues', 'May 1, 2024 • 10:00 AM • Late', Icons.access_time, widget.warningColor),
        ],
      ),
    );
  }

  Widget _buildHistoryItem(AdaptiveScreenManager adaptive, String title, String subtitle, IconData icon, Color color) {
    return Container(
      margin: adaptive.responsiveMargin(bottom: 10),
      padding: adaptive.responsivePadding(all: 15),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.05),
        borderRadius: adaptive.responsiveBorderRadius(8),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: adaptive.sp(14),
                    fontWeight: FontWeight.w500,
                    color: widget.textColor,
                  ),
                ),
                SizedBox(height: adaptive.scale(4)),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: adaptive.sp(12),
                    color: widget.textMuted,
                  ),
                ),
              ],
            ),
          ),
          Icon(
            icon,
            color: color,
            size: adaptive.responsiveIconSize(20),
          ),
        ],
      ),
    );
  }

  void _changeMonth(int offset) {
    setState(() {
      currentMonth += offset;
      if (currentMonth > 11) {
        currentMonth = 0;
        currentYear++;
      } else if (currentMonth < 0) {
        currentMonth = 11;
        currentYear--;
      }
    });
  }
}
