// Student-specific data models
class Course {
  final String code;
  final String title;
  final String lecturer;
  final String department;
  final int attendance;
  final int present;
  final int total;
  final int late;
  final String nextClass;
  final String schedule;

  Course({
    required this.code,
    required this.title,
    required this.lecturer,
    required this.department,
    required this.attendance,
    required this.present,
    required this.total,
    required this.late,
    required this.nextClass,
    required this.schedule,
  });
}

class AttendanceRecord {
  final String id;
  final String courseCode;
  final String courseTitle;
  final String date;
  final String time;
  final AttendanceStatus status;
  final String? checkInTime;
  final String location;
  final String? confidence;
  final String topic;

  AttendanceRecord({
    required this.id,
    required this.courseCode,
    required this.courseTitle,
    required this.date,
    required this.time,
    required this.status,
    this.checkInTime,
    required this.location,
    this.confidence,
    required this.topic,
  });
}

enum AttendanceStatus { present, absent, late, pending }
