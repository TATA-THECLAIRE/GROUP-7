import 'package:flutter/material.dart';
import '../../utils/adaptive_screen_manager.dart';
import 'student_models.dart';

class StudentCalendarScreen extends StatefulWidget {
  final bool isDarkMode;
  final Color primaryColor;
  final Color secondaryColor;
  final Color successColor;
  final Color dangerColor;
  final Color warningColor;
  final Color textColor;
  final Color textMuted;
  final Color bgColor;
  final Color cardBg;
  final Color borderColor;

  const StudentCalendarScreen({
    super.key,
    required this.isDarkMode,
    required this.primaryColor,
    required this.secondaryColor,
    required this.successColor,
    required this.dangerColor,
    required this.warningColor,
    required this.textColor,
    required this.textMuted,
    required this.bgColor,
    required this.cardBg,
    required this.borderColor,
  });

  @override
  State<StudentCalendarScreen> createState() => _StudentCalendarScreenState();
}

class _StudentCalendarScreenState extends State<StudentCalendarScreen> {
  DateTime _selectedDate = DateTime.now();
  DateTime _focusedDate = DateTime.now();
  
  // Sample attendance data mapped to dates
  final Map<DateTime, List<DailyAttendanceRecord>> _attendanceData = {
    DateTime(2024, 6, 20): [
      DailyAttendanceRecord(
        courseCode: 'CS301',
        courseTitle: 'Data Structures & Algorithms',
        time: '10:00 AM - 12:00 PM',
        status: AttendanceStatus.present,
        checkInTime: '10:02 AM',
        location: 'Lecture Hall A',
        lecturer: 'Dr. Sarah Wilson',
      ),
      DailyAttendanceRecord(
        courseCode: 'MATH201',
        courseTitle: 'Linear Algebra',
        time: '2:00 PM - 4:00 PM',
        status: AttendanceStatus.present,
        checkInTime: '2:01 PM',
        location: 'Math Building 201',
        lecturer: 'Prof. David Brown',
      ),
    ],
    DateTime(2024, 6, 19): [
      DailyAttendanceRecord(
        courseCode: 'CS302',
        courseTitle: 'Operating Systems',
        time: '8:00 AM - 10:00 AM',
        status: AttendanceStatus.late,
        checkInTime: '8:15 AM',
        location: 'Computer Lab 3',
        lecturer: 'Dr. Michael Lee',
      ),
    ],
    DateTime(2024, 6, 18): [
      DailyAttendanceRecord(
        courseCode: 'CS301',
        courseTitle: 'Data Structures & Algorithms',
        time: '10:00 AM - 12:00 PM',
        status: AttendanceStatus.absent,
        location: 'Lecture Hall A',
        lecturer: 'Dr. Sarah Wilson',
      ),
      DailyAttendanceRecord(
        courseCode: 'MATH201',
        courseTitle: 'Linear Algebra',
        time: '2:00 PM - 4:00 PM',
        status: AttendanceStatus.present,
        checkInTime: '1:58 PM',
        location: 'Math Building 201',
        lecturer: 'Prof. David Brown',
      ),
    ],
    DateTime(2024, 6, 17): [
      DailyAttendanceRecord(
        courseCode: 'CS302',
        courseTitle: 'Operating Systems',
        time: '8:00 AM - 10:00 AM',
        status: AttendanceStatus.present,
        checkInTime: '7:55 AM',
        location: 'Computer Lab 3',
        lecturer: 'Dr. Michael Lee',
      ),
    ],
  };

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    
    return Container(
      color: widget.bgColor,
      child: SingleChildScrollView(
        padding: adaptive.responsivePadding(all: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Text(
              'My Attendance Summary',
              style: TextStyle(
                fontSize: adaptive.sp(18),
                fontWeight: FontWeight.w600,
                color: widget.textColor,
              ),
            ),
            SizedBox(height: adaptive.scale(5)),
            Text(
              'Track your attendance patterns and view detailed calendar',
              style: TextStyle(
                fontSize: adaptive.sp(14),
                color: widget.textMuted,
              ),
            ),
            SizedBox(height: adaptive.scale(20)),
            
            // Attendance Summary Cards
            _buildAttendanceSummary(adaptive),
            SizedBox(height: adaptive.scale(20)),
            
            // Calendar Widget
            _buildCalendar(adaptive),
            
            SizedBox(height: adaptive.scale(20)),
            
            // Selected Date Details
            if (_attendanceData.containsKey(_getDateKey(_selectedDate)))
              _buildSelectedDateDetails(adaptive)
            else
              _buildNoAttendanceMessage(adaptive),
          ],
        ),
      ),
    );
  }

  Widget _buildAttendanceSummary(AdaptiveScreenManager adaptive) {
    // Calculate summary statistics
    int totalClasses = 0;
    int presentCount = 0;
    int absentCount = 0;
    int lateCount = 0;
    
    for (var dayRecords in _attendanceData.values) {
      for (var record in dayRecords) {
        totalClasses++;
        switch (record.status) {
          case AttendanceStatus.present:
            presentCount++;
            break;
          case AttendanceStatus.absent:
            absentCount++;
            break;
          case AttendanceStatus.late:
            lateCount++;
            break;
          case AttendanceStatus.pending:
            break;
        }
      }
    }
    
    double attendanceRate = totalClasses > 0 ? (presentCount / totalClasses) * 100 : 0;
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Quick Stats Row
        Row(
          children: [
            Expanded(
              child: _buildSummaryCard(
                adaptive,
                '${attendanceRate.toStringAsFixed(1)}%',
                'Overall Rate',
                '📈',
                widget.successColor,
              ),
            ),
            SizedBox(width: adaptive.scale(12)),
            Expanded(
              child: _buildSummaryCard(
                adaptive,
                '$presentCount',
                'Present',
                '✅',
                widget.successColor,
              ),
            ),
            SizedBox(width: adaptive.scale(12)),
            Expanded(
              child: _buildSummaryCard(
                adaptive,
                '$absentCount',
                'Absent',
                '❌',
                widget.dangerColor,
              ),
            ),
            SizedBox(width: adaptive.scale(12)),
            Expanded(
              child: _buildSummaryCard(
                adaptive,
                '$lateCount',
                'Late',
                '⏰',
                widget.warningColor,
              ),
            ),
          ],
        ),
        SizedBox(height: adaptive.scale(15)),
        
        // Quick Insights
        Container(
          padding: adaptive.responsivePadding(all: 15),
          decoration: BoxDecoration(
            color: widget.cardBg,
            borderRadius: adaptive.responsiveBorderRadius(12),
            border: Border.all(color: widget.borderColor),
            boxShadow: [
              BoxShadow(
                color: const Color(0x1A000000),
                blurRadius: 6,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            children: [
              Text('💡', style: TextStyle(fontSize: adaptive.sp(20))),
              SizedBox(width: adaptive.scale(10)),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Quick Insight',
                      style: TextStyle(
                        fontSize: adaptive.sp(14),
                        fontWeight: FontWeight.w600,
                        color: widget.textColor,
                      ),
                    ),
                    SizedBox(height: adaptive.scale(4)),
                    Text(
                      attendanceRate >= 85 
                          ? 'Great job! Your attendance is excellent 🎉'
                          : attendanceRate >= 75
                          ? 'Good attendance! Try to maintain consistency 👍'
                          : 'Your attendance needs improvement. Stay consistent! 💪',
                      style: TextStyle(
                        fontSize: adaptive.sp(12),
                        color: widget.textMuted,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSummaryCard(AdaptiveScreenManager adaptive, String value, String label, String emoji, Color color) {
    return Container(
      padding: adaptive.responsivePadding(all: 12),
      decoration: BoxDecoration(
        color: widget.cardBg,
        borderRadius: adaptive.responsiveBorderRadius(10),
        border: Border.all(color: widget.borderColor),
        boxShadow: [
          BoxShadow(
            color: const Color(0x1A000000),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(emoji, style: TextStyle(fontSize: adaptive.sp(20))),
          SizedBox(height: adaptive.scale(4)),
          Text(
            value,
            style: TextStyle(
              fontSize: adaptive.sp(16),
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          SizedBox(height: adaptive.scale(2)),
          Text(
            label,
            style: TextStyle(
              fontSize: adaptive.sp(10),
              color: widget.textMuted,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildCalendar(AdaptiveScreenManager adaptive) {
    return Container(
      padding: adaptive.responsivePadding(all: 15),
      decoration: BoxDecoration(
        color: widget.cardBg,
        borderRadius: adaptive.responsiveBorderRadius(12),
        border: Border.all(color: widget.borderColor),
        boxShadow: [
          BoxShadow(
            color: const Color(0x1A000000),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          // Calendar Header
          _buildCalendarHeader(adaptive),
          SizedBox(height: adaptive.scale(15)),
          
          // Days of week
          _buildDaysOfWeekHeader(adaptive),
          SizedBox(height: adaptive.scale(10)),
          
          // Calendar Grid
          _buildCalendarGrid(adaptive),
        ],
      ),
    );
  }

  Widget _buildCalendarHeader(AdaptiveScreenManager adaptive) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        IconButton(
          onPressed: () {
            setState(() {
              _focusedDate = DateTime(_focusedDate.year, _focusedDate.month - 1);
            });
          },
          icon: Text('◀️', style: TextStyle(fontSize: adaptive.sp(20))),
        ),
        Text(
          _getMonthYearString(_focusedDate),
          style: TextStyle(
            fontSize: adaptive.sp(18),
            fontWeight: FontWeight.w600,
            color: widget.textColor,
          ),
        ),
        IconButton(
          onPressed: () {
            setState(() {
              _focusedDate = DateTime(_focusedDate.year, _focusedDate.month + 1);
            });
          },
          icon: Text('▶️', style: TextStyle(fontSize: adaptive.sp(20))),
        ),
      ],
    );
  }

  Widget _buildDaysOfWeekHeader(AdaptiveScreenManager adaptive) {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    
    return Row(
      children: days.map((day) => Expanded(
        child: Center(
          child: Text(
            day,
            style: TextStyle(
              fontSize: adaptive.sp(12),
              fontWeight: FontWeight.w500,
              color: widget.textMuted,
            ),
          ),
        ),
      )).toList(),
    );
  }

  Widget _buildCalendarGrid(AdaptiveScreenManager adaptive) {
    final firstDayOfMonth = DateTime(_focusedDate.year, _focusedDate.month, 1);
    final lastDayOfMonth = DateTime(_focusedDate.year, _focusedDate.month + 1, 0);
    final firstDayWeekday = firstDayOfMonth.weekday % 7;
    
    List<Widget> dayWidgets = [];
    
    // Add empty cells for days before the first day of the month
    for (int i = 0; i < firstDayWeekday; i++) {
      dayWidgets.add(const SizedBox());
    }
    
    // Add day cells
    for (int day = 1; day <= lastDayOfMonth.day; day++) {
      final date = DateTime(_focusedDate.year, _focusedDate.month, day);
      dayWidgets.add(_buildDayCell(adaptive, date));
    }
    
    // Create rows of 7 days each
    List<Widget> rows = [];
    for (int i = 0; i < dayWidgets.length; i += 7) {
      rows.add(
        Row(
          children: dayWidgets
              .skip(i)
              .take(7)
              .map((widget) => Expanded(child: widget))
              .toList(),
        ),
      );
    }
    
    return Column(children: rows);
  }

  Widget _buildDayCell(AdaptiveScreenManager adaptive, DateTime date) {
    final isSelected = _isSameDay(date, _selectedDate);
    final isToday = _isSameDay(date, DateTime.now());
    final hasAttendance = _attendanceData.containsKey(_getDateKey(date));
    
    Color? backgroundColor;
    Color? textColor = widget.textColor;
    
    if (isSelected) {
      backgroundColor = widget.primaryColor;
      textColor = Colors.white;
    } else if (isToday) {
      backgroundColor = widget.primaryColor.withValues(alpha: 0.1);
      textColor = widget.primaryColor;
    }
    
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedDate = date;
        });
      },
      child: Container(
        height: adaptive.scale(45),
        margin: adaptive.responsiveMargin(all: 2),
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: adaptive.responsiveBorderRadius(8),
          border: hasAttendance && !isSelected
              ? Border.all(color: widget.primaryColor, width: 1)
              : null,
        ),
        child: Stack(
          children: [
            Center(
              child: Text(
                date.day.toString(),
                style: TextStyle(
                  fontSize: adaptive.sp(14),
                  fontWeight: isSelected || isToday ? FontWeight.w600 : FontWeight.normal,
                  color: textColor,
                ),
              ),
            ),
            if (hasAttendance && !isSelected)
              Positioned(
                top: adaptive.scale(4),
                right: adaptive.scale(4),
                child: Container(
                  width: adaptive.scale(6),
                  height: adaptive.scale(6),
                  decoration: BoxDecoration(
                    color: widget.primaryColor,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildSelectedDateDetails(AdaptiveScreenManager adaptive) {
    final attendanceRecords = _attendanceData[_getDateKey(_selectedDate)]!;
    
    return Container(
      padding: adaptive.responsivePadding(all: 20),
      decoration: BoxDecoration(
        color: widget.cardBg,
        borderRadius: adaptive.responsiveBorderRadius(12),
        border: Border.all(color: widget.borderColor),
        boxShadow: [
          BoxShadow(
            color: const Color(0x1A000000),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text('📅', style: TextStyle(fontSize: adaptive.sp(20))),
              SizedBox(width: adaptive.scale(8)),
              Text(
                _getFormattedDate(_selectedDate),
                style: TextStyle(
                  fontSize: adaptive.sp(16),
                  fontWeight: FontWeight.w600,
                  color: widget.textColor,
                ),
              ),
            ],
          ),
          SizedBox(height: adaptive.scale(15)),
          
          Text(
            '${attendanceRecords.length} ${attendanceRecords.length == 1 ? 'Class' : 'Classes'}',
            style: TextStyle(
              fontSize: adaptive.sp(14),
              color: widget.textMuted,
            ),
          ),
          SizedBox(height: adaptive.scale(15)),
          
          ...attendanceRecords.map((record) => _buildAttendanceRecordCard(adaptive, record)),
        ],
      ),
    );
  }

  Widget _buildAttendanceRecordCard(AdaptiveScreenManager adaptive, DailyAttendanceRecord record) {
    Color statusColor;
    IconData statusIcon;
    
    switch (record.status) {
      case AttendanceStatus.present:
        statusColor = widget.successColor;
        statusIcon = Icons.check_circle;
        break;
      case AttendanceStatus.absent:
        statusColor = widget.dangerColor;
        statusIcon = Icons.cancel;
        break;
      case AttendanceStatus.late:
        statusColor = widget.warningColor;
        statusIcon = Icons.access_time;
        break;
      case AttendanceStatus.pending:
        statusColor = widget.textMuted;
        statusIcon = Icons.schedule;
        break;
    }
    
    return Container(
      margin: adaptive.responsiveMargin(bottom: 12),
      padding: adaptive.responsivePadding(all: 15),
      decoration: BoxDecoration(
        color: widget.bgColor,
        borderRadius: adaptive.responsiveBorderRadius(8),
        border: Border.all(color: widget.borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      record.courseTitle,
                      style: TextStyle(
                        fontSize: adaptive.sp(14),
                        fontWeight: FontWeight.w600,
                        color: widget.textColor,
                      ),
                    ),
                    SizedBox(height: adaptive.scale(2)),
                    Text(
                      '${record.courseCode} • ${record.lecturer}',
                      style: TextStyle(
                        fontSize: adaptive.sp(12),
                        color: widget.textMuted,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: adaptive.responsivePadding(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: statusColor.withValues(alpha: 0.1),
                  borderRadius: adaptive.responsiveBorderRadius(12),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      statusIcon,
                      size: adaptive.responsiveIconSize(14),
                      color: statusColor,
                    ),
                    SizedBox(width: adaptive.scale(4)),
                    Text(
                      record.status.name.toUpperCase(),
                      style: TextStyle(
                        fontSize: adaptive.sp(10),
                        fontWeight: FontWeight.w600,
                        color: statusColor,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: adaptive.scale(8)),
          
          Row(
            children: [
              Text('🕐', style: TextStyle(fontSize: adaptive.sp(14))),
              SizedBox(width: adaptive.scale(4)),
              Text(
                record.time,
                style: TextStyle(
                  fontSize: adaptive.sp(12),
                  color: widget.textMuted,
                ),
              ),
              SizedBox(width: adaptive.scale(15)),
              Text('📍', style: TextStyle(fontSize: adaptive.sp(14))),
              SizedBox(width: adaptive.scale(4)),
              Text(
                record.location,
                style: TextStyle(
                  fontSize: adaptive.sp(12),
                  color: widget.textMuted,
                ),
              ),
            ],
          ),
          
          if (record.checkInTime != null) ...[
            SizedBox(height: adaptive.scale(8)),
            Row(
              children: [
                Text('✅', style: TextStyle(fontSize: adaptive.sp(14))),
                SizedBox(width: adaptive.scale(4)),
                Text(
                  'Checked in at ${record.checkInTime}',
                  style: TextStyle(
                    fontSize: adaptive.sp(12),
                    color: widget.textMuted,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildNoAttendanceMessage(AdaptiveScreenManager adaptive) {
    return Container(
      padding: adaptive.responsivePadding(all: 30),
      decoration: BoxDecoration(
        color: widget.cardBg,
        borderRadius: adaptive.responsiveBorderRadius(12),
        border: Border.all(color: widget.borderColor),
      ),
      child: Center(
        child: Column(
          children: [
            Text('📅', style: TextStyle(fontSize: adaptive.sp(48))),
            SizedBox(height: adaptive.scale(15)),
            Text(
              'No Classes',
              style: TextStyle(
                fontSize: adaptive.sp(16),
                fontWeight: FontWeight.w600,
                color: widget.textColor,
              ),
            ),
            SizedBox(height: adaptive.scale(5)),
            Text(
              'You had no scheduled classes on ${_getFormattedDate(_selectedDate)}',
              style: TextStyle(
                fontSize: adaptive.sp(14),
                color: widget.textMuted,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // Helper methods
  DateTime _getDateKey(DateTime date) {
    return DateTime(date.year, date.month, date.day);
  }

  bool _isSameDay(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }

  String _getMonthYearString(DateTime date) {
    const months = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return '${months[date.month - 1]} ${date.year}';
  }

  String _getFormattedDate(DateTime date) {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return '${months[date.month - 1]} ${date.day}, ${date.year}';
  }
}

// New model for daily attendance records
class DailyAttendanceRecord {
  final String courseCode;
  final String courseTitle;
  final String time;
  final AttendanceStatus status;
  final String? checkInTime;
  final String location;
  final String lecturer;

  DailyAttendanceRecord({
    required this.courseCode,
    required this.courseTitle,
    required this.time,
    required this.status,
    this.checkInTime,
    required this.location,
    required this.lecturer,
  });
}
