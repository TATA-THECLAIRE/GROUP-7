import 'package:flutter/material.dart';


class StudentAttendanceScreen extends StatefulWidget {
  final Color primaryColor;
  final Color textColor;
  final Color textMuted;
  final Color bgColor;
  final Color cardBg;
  final bool isDarkMode;

  const StudentAttendanceScreen({
    super.key,
    required this.primaryColor,
    required this.textColor,
    required this.textMuted,
    required this.bgColor,
    required this.cardBg,
    required this.isDarkMode,
  });

  @override
  State<StudentAttendanceScreen> createState() => _StudentAttendanceScreenState();
}

class _StudentAttendanceScreenState extends State<StudentAttendanceScreen> {
  bool _hasCheckedIn = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Student Attendance'),
        backgroundColor: widget.primaryColor,
      ),
      backgroundColor: widget.bgColor,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              _hasCheckedIn ? 'You have checked in!' : 'You have not checked in.',
              style: TextStyle(
                color: widget.textColor,
                fontSize: 20,
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: widget.primaryColor,
                foregroundColor: widget.textColor,
              ),
              onPressed: _hasCheckedIn ? null : _showCheckInModal,
              child: const Text('Check In'),
            ),
          ],
        ),
      ),
    );
  }

  void _showCheckInModal() {
    showDialog(
      context: context,
      builder: (BuildContext context) => StudentCheckInModal(
        courseCode: 'MATH201',
        onSuccess: () {
          setState(() {
            _hasCheckedIn = true;
          });
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('Successfully checked in!'),
              backgroundColor: widget.primaryColor,
            ),
          );
        },
        primaryColor: widget.primaryColor,
        textColor: widget.textColor,
        textMuted: widget.textMuted,
        bgColor: widget.bgColor,
        cardBg: widget.cardBg,
        isDarkMode: widget.isDarkMode,
      ),
    );
  }
}

class StudentCheckInModal extends StatelessWidget {
  final String courseCode;
  final VoidCallback onSuccess;
  final Color primaryColor;
  final Color textColor;
  final Color textMuted;
  final Color bgColor;
  final Color cardBg;
  final bool isDarkMode;

  const StudentCheckInModal({
    super.key,
    required this.courseCode,
    required this.onSuccess,
    required this.primaryColor,
    required this.textColor,
    required this.textMuted,
    required this.bgColor,
    required this.cardBg,
    required this.isDarkMode,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: cardBg,
      title: Text(
        'Check In',
        style: TextStyle(color: textColor),
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'Are you sure you want to check in for $courseCode?',
            style: TextStyle(color: textColor),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text(
            'Cancel',
            style: TextStyle(color: textColor),
          ),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: primaryColor,
            foregroundColor: textColor,
          ),
          onPressed: () {
            onSuccess();
            Navigator.of(context).pop();
          },
          child: const Text('Check In'),
        ),
      ],
    );
  }
}
