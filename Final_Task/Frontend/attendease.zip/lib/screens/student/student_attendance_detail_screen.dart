import 'package:flutter/material.dart';
import '../../utils/adaptive_screen_manager.dart';
import 'student_models.dart';

class StudentAttendanceDetailScreen extends StatelessWidget {
  final AttendanceRecord record;
  final VoidCallback onBack;
  final bool isDarkMode;
  final Color primaryColor;
  final Color secondaryColor;
  final Color textColor;
  final Color textMuted;
  final Color bgColor;
  final Color cardBg;
  final Color borderColor;

  const StudentAttendanceDetailScreen({
    super.key,
    required this.record,
    required this.onBack,
    this.isDarkMode = false,
    this.primaryColor = const Color(0xFF667EEA),
    this.secondaryColor = const Color(0xFF764BA2),
    this.textColor = const Color(0xFF333333),
    this.textMuted = const Color(0xFF6C757D),
    this.bgColor = const Color(0xFFFFFFFF),
    this.cardBg = const Color(0xFFFFFFFF),
    this.borderColor = const Color(0xFFE0E0E0),
  });

  // EXACT theme colors from HTML CSS
  static const Color _successColor = Color(0xFF28A745);
  static const Color _dangerColor = Color(0xFFDC3545);
  static const Color _warningColor = Color(0xFFFFC107);
  static const Color _shadowColor = Color(0x1A000000);

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;

    return Container(
      color: bgColor,
      child: SingleChildScrollView(
        padding: adaptive.responsivePadding(all: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Attendance Details',
              style: TextStyle(
                fontSize: adaptive.sp(16),
                fontWeight: FontWeight.w600,
                color: textColor,
              ),
            ),
            SizedBox(height: adaptive.scale(20)),
            _buildAttendanceCard(adaptive),
            SizedBox(height: adaptive.scale(20)),
            _buildSessionInfo(adaptive),
          ],
        ),
      ),
    );
  }

  Widget _buildAttendanceCard(AdaptiveScreenManager adaptive) {
    Color statusColor;
    
    switch (record.status) {
      case AttendanceStatus.present:
        statusColor = _successColor;
        break;
      case AttendanceStatus.absent:
        statusColor = _dangerColor;
        break;
      case AttendanceStatus.late:
        statusColor = _warningColor;
        break;
      case AttendanceStatus.pending:
        statusColor = textMuted;
        break;
    }

    return Container(
      padding: adaptive.responsivePadding(all: 20),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: adaptive.responsiveBorderRadius(12),
        border: Border.all(color: borderColor),
        boxShadow: const [
          BoxShadow(
            color: _shadowColor,
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            record.courseTitle,
            style: TextStyle(
              fontSize: adaptive.sp(18),
              fontWeight: FontWeight.w600,
              color: textColor,
            ),
          ),
          SizedBox(height: adaptive.scale(5)),
          Text(
            '${record.courseCode} • ${record.date} • ${record.time}',
            style: TextStyle(
              fontSize: adaptive.sp(14),
              color: textMuted,
            ),
          ),
          SizedBox(height: adaptive.scale(15)),
          // Status row matching HTML layout
          Row(
            children: [
              Expanded(
                child: _buildDetailItem(adaptive, 'Status', record.status.name.toUpperCase(), statusColor),
              ),
              if (record.checkInTime != null)
                Expanded(
                  child: _buildDetailItem(adaptive, 'Checked In At', record.checkInTime!, textColor),
                ),
              Expanded(
                child: _buildDetailItem(adaptive, 'Location', record.location, textColor),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDetailItem(AdaptiveScreenManager adaptive, String label, String value, Color valueColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: adaptive.sp(12),
            color: textMuted,
          ),
        ),
        SizedBox(height: adaptive.scale(2)),
        Text(
          value,
          style: TextStyle(
            fontSize: adaptive.sp(14),
            fontWeight: FontWeight.bold,
            color: valueColor,
          ),
        ),
      ],
    );
  }

  Widget _buildSessionInfo(AdaptiveScreenManager adaptive) {
    return Container(
      padding: adaptive.responsivePadding(all: 20),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: adaptive.responsiveBorderRadius(12),
        border: Border.all(color: borderColor),
        boxShadow: const [
          BoxShadow(
            color: _shadowColor,
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Session Information',
            style: TextStyle(
              fontSize: adaptive.sp(16),
              fontWeight: FontWeight.w600,
              color: textColor,
            ),
          ),
          SizedBox(height: adaptive.scale(15)),
          _buildInfoRow(adaptive, 'Lecturer', 'Dr. Michael Lee'),
          _buildInfoRow(adaptive, 'Topic', record.topic),
          _buildInfoRow(adaptive, 'Duration', '2 hours'),
          _buildInfoRow(adaptive, 'Class Size', '30 students'),
          _buildInfoRow(adaptive, 'Attendance', '25/30 (83%)'),
          if (record.confidence != null)
            _buildInfoRow(adaptive, 'Confidence', record.confidence!),
        ],
      ),
    );
  }

  Widget _buildInfoRow(AdaptiveScreenManager adaptive, String label, String value) {
    return Container(
      padding: adaptive.responsivePadding(vertical: 8),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: borderColor,
            width: 0.5,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: adaptive.sp(14),
              color: textMuted,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: adaptive.sp(14),
              color: textColor,
            ),
          ),
        ],
      ),
    );
  }
}
