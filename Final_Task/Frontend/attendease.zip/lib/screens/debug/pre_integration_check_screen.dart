import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../services/health/health_check_service.dart';
import '../../services/face_recognition/face_recognition_service.dart';
import '../../config/feature_flags.dart';
import '../../config/api_config.dart';

class PreIntegrationCheckScreen extends StatefulWidget {
  const PreIntegrationCheckScreen({Key? key}) : super(key: key);

  @override
  State<PreIntegrationCheckScreen> createState() => _PreIntegrationCheckScreenState();
}

class _PreIntegrationCheckScreenState extends State<PreIntegrationCheckScreen> {
  SystemHealthStatus? _healthStatus;
  bool _isLoading = false;
  bool _showDetails = false;

  @override
  void initState() {
    super.initState();
    _runHealthCheck();
  }

  Future<void> _runHealthCheck() async {
    setState(() => _isLoading = true);

    try {
      final status = await HealthCheckService.checkSystemHealth();
      if (mounted) {
        setState(() => _healthStatus = status);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Health check failed: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pre-Integration Check'),
        actions: [
          IconButton(
            icon: const Icon(Icons.home),
            onPressed: () => Navigator.pushReplacementNamed(context, '/home'),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildWelcomeCard(),
            const SizedBox(height: 20),
            _buildConfigurationCard(),
            const SizedBox(height: 20),
            _buildHealthCheckCard(),
            const SizedBox(height: 20),
            _buildActionsCard(),
          ],
        ),
      ),
    );
  }

  Widget _buildWelcomeCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.integration_instructions, color: Colors.blue),
                const SizedBox(width: 8),
                Text(
                  'AttendEase Integration Check',
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
              ],
            ),
            const SizedBox(height: 12),
            const Text(
              'This screen helps verify that your app is ready for backend integration. '
              'Run the health check to ensure all systems are working properly.',
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.blue.shade200),
              ),
              child: const Row(
                children: [
                  Icon(Icons.info, color: Colors.blue),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Currently running in mock data mode. Integration will be enabled step by step.',
                      style: TextStyle(color: Colors.blue),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildConfigurationCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Configuration',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 12),
            _buildConfigItem('Backend URL', ApiConfig.BASE_URL),
            _buildConfigItem('Integration Phase', FeatureFlags.currentPhase),
            const SizedBox(height: 12),
            const Text(
              'Feature Flags:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            _buildFeatureFlag('Real API', FeatureFlags.USE_REAL_API),
            _buildFeatureFlag('Authentication', FeatureFlags.ENABLE_AUTH_API),
            _buildFeatureFlag('Read Operations', FeatureFlags.ENABLE_READ_OPERATIONS),
            _buildFeatureFlag('Write Operations', FeatureFlags.ENABLE_WRITE_OPERATIONS),
            _buildFeatureFlag('Face Recognition', FeatureFlags.ENABLE_FACE_RECOGNITION),
            _buildFeatureFlag('Geolocation', FeatureFlags.ENABLE_GEOLOCATION),
          ],
        ),
      ),
    );
  }

  Widget _buildConfigItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              '$label:',
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontFamily: 'monospace'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureFlag(String name, bool value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          Icon(
            value ? Icons.check_circle : Icons.cancel,
            color: value ? Colors.green : Colors.red,
            size: 16,
          ),
          const SizedBox(width: 8),
          Text(name),
        ],
      ),
    );
  }

  Widget _buildHealthCheckCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'System Health Check',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                if (_healthStatus != null)
                  Icon(
                    _healthStatus!.isHealthy
                        ? Icons.check_circle
                        : _healthStatus!.hasErrors
                            ? Icons.error
                            : Icons.warning,
                    color: _healthStatus!.isHealthy
                        ? Colors.green
                        : _healthStatus!.hasErrors
                            ? Colors.red
                            : Colors.orange,
                  ),
              ],
            ),
            const SizedBox(height: 12),
            if (_isLoading)
              const Center(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: CircularProgressIndicator(),
                ),
              )
            else if (_healthStatus != null)
              _buildHealthResults()
            else
              const Text('No health check data available'),
            const SizedBox(height: 12),
            Row(
              children: [
                ElevatedButton.icon(
                  onPressed: _isLoading ? null : _runHealthCheck,
                  icon: const Icon(Icons.refresh),
                  label: const Text('Run Health Check Again'),
                ),
                const SizedBox(width: 12),
                TextButton(
                  onPressed: () => setState(() => _showDetails = !_showDetails),
                  child: Text(_showDetails ? 'Hide Details' : 'Show Details'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHealthResults() {
    final status = _healthStatus!;
    
    return Column(
      children: [
        ...status.results.entries.map((entry) => 
          _buildHealthItem(entry.key, entry.value)
        ),
        if (_showDetails) ...[
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Details:',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text('Timestamp: ${status.timestamp}'),
                if (status.hasErrors)
                  Text('Failed Services: ${status.failedServices.join(', ')}'),
                if (status.hasWarnings)
                  Text('Warning Services: ${status.warningServices.join(', ')}'),
              ],
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildHealthItem(String service, HealthCheckResult item) {
    Color color;
    IconData icon;
    
    switch (item.status) {
      case HealthItemStatus.healthy:
        color = Colors.green;
        icon = Icons.check_circle;
        break;
      case HealthItemStatus.warning:
        color = Colors.orange;
        icon = Icons.warning;
        break;
      case HealthItemStatus.unhealthy:
        color = Colors.red;
        icon = Icons.error;
        break;
    }
    
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  service.toUpperCase(),
                  style: const TextStyle(fontWeight: FontWeight.w500),
                ),
                Text(
                  item.message,
                  style: TextStyle(
                    color: Colors.grey.shade600,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionsCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Test Actions',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ElevatedButton.icon(
                  onPressed: _testBackendConnection,
                  icon: const Icon(Icons.cloud),
                  label: const Text('Test Backend Connection'),
                ),
                ElevatedButton.icon(
                  onPressed: _testFaceRecognition,
                  icon: const Icon(Icons.face),
                  label: const Text('Test Face Recognition'),
                ),
                ElevatedButton.icon(
                  onPressed: _copyBackendUrl,
                  icon: const Icon(Icons.copy),
                  label: const Text('Copy Backend URL'),
                ),
                ElevatedButton.icon(
                  onPressed: () => Navigator.pushReplacementNamed(context, '/home'),
                  icon: const Icon(Icons.home),
                  label: const Text('Go to App'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _testBackendConnection() async {
    if (!mounted) return;
    
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Testing backend connection...')),
    );
    
    try {
      final status = await HealthCheckService.checkSystemHealth();
      final backendStatus = status.results['backend'];
      
      if (!mounted) return;
      
      if (backendStatus?.status == HealthItemStatus.healthy) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('✅ Backend connection successful!'),
            backgroundColor: Colors.green,
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('❌ Backend connection failed: ${backendStatus?.message}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('❌ Backend test failed: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _testFaceRecognition() async {
    if (!FeatureFlags.ENABLE_FACE_RECOGNITION) {
      if (!mounted) return;
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('ℹ️ Face recognition is currently disabled via feature flags'),
          backgroundColor: Colors.blue,
        ),
      );
      return;
    }
    
    try {
      final isInitialized = await FaceRecognitionService.isInitialized();
      
      if (!mounted) return;
      
      if (isInitialized) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('✅ Face recognition service is ready!'),
            backgroundColor: Colors.green,
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('⚠️ Face recognition service not initialized'),
            backgroundColor: Colors.orange,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('❌ Face recognition test failed: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _copyBackendUrl() {
    Clipboard.setData(ClipboardData(text: ApiConfig.BASE_URL));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('📋 Backend URL copied to clipboard'),
        backgroundColor: Colors.blue,
      ),
    );
  }
}
