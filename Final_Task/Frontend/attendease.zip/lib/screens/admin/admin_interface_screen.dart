import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../../utils/adaptive_screen_manager.dart';
import '../homepage_screen.dart';
import 'admin_dashboard_tab.dart';
import 'admin_students_tab.dart';
import 'admin_lecturers_tab.dart';
import 'admin_courses_tab.dart';
import 'admin_geofence_tab.dart';
import 'admin_reports_tab.dart';
import 'admin_settings_tab.dart';

class AdminInterfaceScreen extends StatefulWidget {
  const AdminInterfaceScreen({super.key});

  @override
  State<AdminInterfaceScreen> createState() => _AdminInterfaceScreenState();
}

class _AdminInterfaceScreenState extends State<AdminInterfaceScreen> with WidgetsBindingObserver {
  int _currentIndex = 0;
  ThemeMode _themeMode = ThemeMode.system;
  String _currentTitle = 'Admin Dashboard';
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();
  
  // Navigation stack to track where user came from
  final List<Map<String, dynamic>> _navigationStack = [
    {'index': 0, 'title': 'Admin Dashboard'}
  ];

  late final List<Widget> _screens;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _screens = [
      AdminDashboardTab(onNavigate: _navigateToScreen),
      const AdminStudentsTab(),
      const AdminLecturersTab(),
      const AdminCoursesTab(),
      const AdminGeofenceTab(),
      const AdminReportsTab(),
      const AdminSettingsTab(),
    ];
    
    // Show welcome message
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Welcome to AttendEase Admin Dashboard!'),
            duration: Duration(seconds: 3),
            backgroundColor: Color(0xFF667EEA),
          ),
        );
      }
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangePlatformBrightness() {
    if (_themeMode == ThemeMode.system) {
      setState(() {
        // Trigger rebuild to reflect system theme change
      });
    }
  }

  final List<String> _titles = [
    'Admin Dashboard',
    'Manage Students',
    'Manage Lecturers',
    'Manage Courses',
    'Geofence Areas',
    'Attendance Reports',
    'System Settings',
  ];

  void _navigateToScreen(String screenName) {
    int index;
    switch (screenName) {
      case 'manage-students':
        index = 1;
        break;
      case 'manage-lecturers':
        index = 2;
        break;
      case 'manage-courses':
        index = 3;
        break;
      case 'geofence-management':
        index = 4;
        break;
      case 'attendance-reports':
        index = 5;
        break;
      case 'system-settings':
        index = 6;
        break;
      default:
        return;
    }
    
    // Add to navigation stack
    _navigationStack.add({
      'index': index,
      'title': _titles[index],
    });
    
    setState(() {
      _currentIndex = index;
      _currentTitle = _titles[index];
    });
  }

  void _onTabTapped(int index) {
    if (index == _currentIndex) return; // Don't navigate to the same tab
    
    // Add to navigation stack
    _navigationStack.add({
      'index': index,
      'title': _titles[index],
    });
    
    setState(() {
      _currentIndex = index;
      _currentTitle = _titles[index];
    });
  }

  // Handle back navigation - go back the same way user came
  void _handleBackNavigation() {
    // If we have navigation history, go back to previous screen
    if (_navigationStack.length > 1) {
      // Remove current screen from stack
      _navigationStack.removeLast();
      
      // Get previous screen
      final previousScreen = _navigationStack.last;
      
      setState(() {
        _currentIndex = previousScreen['index'];
        _currentTitle = previousScreen['title'];
      });
      return;
    }
    
    // If we're at the root (dashboard), show logout confirmation
    _showLogoutConfirmation();
  }

  void _showLogoutConfirmation() {
    showDialog(
      context: context,
      barrierDismissible: false, // Prevent dismissing by tapping outside
      builder: (context) => AlertDialog(
        title: const Text('Leave Admin Interface'),
        content: const Text('Do you want to logout and return to homepage?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Stay'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _logout();
            },
            child: const Text('Logout'),
          ),
        ],
      ),
    );
  }

  void _toggleTheme() {
    setState(() {
      switch (_themeMode) {
        case ThemeMode.system:
          _themeMode = ThemeMode.light;
          break;
        case ThemeMode.light:
          _themeMode = ThemeMode.dark;
          break;
        case ThemeMode.dark:
          _themeMode = ThemeMode.system;
          break;
      }
    });
    
    String themeName;
    switch (_themeMode) {
      case ThemeMode.system:
        themeName = 'system default';
        break;
      case ThemeMode.light:
        themeName = 'light';
        break;
      case ThemeMode.dark:
        themeName = 'dark';
        break;
    }
    
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Switched to $themeName theme'),
          duration: const Duration(seconds: 2),
          backgroundColor: const Color(0xFF667EEA),
        ),
      );
    }
  }

  void _showProfileOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: _getCurrentTheme().scaffoldBackgroundColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.grey[400],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.camera_alt, color: Color(0xFF667EEA)),
                title: const Text('Camera'),
                onTap: () {
                  Navigator.pop(context);
                  _pickImageFromCamera();
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_library, color: Color(0xFF667EEA)),
                title: const Text('Gallery'),
                onTap: () {
                  Navigator.pop(context);
                  _pickImageFromGallery();
                },
              ),
              ListTile(
                leading: const Icon(Icons.person, color: Color(0xFF667EEA)),
                title: const Text('View Profile'),
                onTap: () {
                  Navigator.pop(context);
                  _showProfile();
                },
              ),
              if (_profileImage != null)
                ListTile(
                  leading: const Icon(Icons.delete, color: Colors.red),
                  title: const Text('Remove Picture'),
                  onTap: () {
                    Navigator.pop(context);
                    _removeProfilePicture();
                  },
                ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickImageFromCamera() async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.camera,
        maxWidth: 512,
        maxHeight: 512,
        imageQuality: 80,
      );
      
      if (image != null) {
        setState(() {
          _profileImage = File(image.path);
        });
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Profile picture updated from camera'),
              backgroundColor: Color(0xFF28A745),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to capture image from camera'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _pickImageFromGallery() async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 512,
        maxHeight: 512,
        imageQuality: 80,
      );
      
      if (image != null) {
        setState(() {
          _profileImage = File(image.path);
        });
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Profile picture updated from gallery'),
              backgroundColor: Color(0xFF28A745),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to select image from gallery'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _removeProfilePicture() {
    setState(() {
      _profileImage = null;
    });
    
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Profile picture removed'),
          backgroundColor: Color(0xFF667EEA),
        ),
      );
    }
  }

  void _showProfile() {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Profile: System Administrator'),
          duration: Duration(seconds: 2),
          backgroundColor: Color(0xFF667EEA),
        ),
      );
    }
  }
  
  void _logout() {
    // Clear navigation stack
    _navigationStack.clear();
    
    // Navigate to homepage and remove all previous routes
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (context) => const HomepageScreen()),
      (route) => false,
    );
  }

  ThemeData _getCurrentTheme() {
    switch (_themeMode) {
      case ThemeMode.light:
        return ThemeData.light();
      case ThemeMode.dark:
        return ThemeData.dark();
      case ThemeMode.system:
        final brightness = MediaQuery.of(context).platformBrightness;
        return brightness == Brightness.dark ? ThemeData.dark() : ThemeData.light();
    }
  }

  bool _isDarkMode() {
    switch (_themeMode) {
      case ThemeMode.light:
        return false;
      case ThemeMode.dark:
        return true;
      case ThemeMode.system:
        return MediaQuery.of(context).platformBrightness == Brightness.dark;
    }
  }

  String _getThemeIcon() {
    switch (_themeMode) {
      case ThemeMode.light:
        return '☀️';
      case ThemeMode.dark:
        return '🌙';
      case ThemeMode.system:
        return '🔄';
    }
  }

  Widget _buildProfileIcon(adaptive) {
    return GestureDetector(
      onTap: _showProfileOptions,
      child: Container(
        width: adaptive.responsiveIconSize(32.0),
        height: adaptive.responsiveIconSize(32.0),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.2),
          borderRadius: BorderRadius.circular(16),
          border: _profileImage != null 
            ? Border.all(color: Colors.white, width: 2)
            : null,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: _profileImage != null
            ? Image.file(
                _profileImage!,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return Center(
                    child: Text(
                      '👤',
                      style: TextStyle(fontSize: adaptive.sp(16.0)),
                    ),
                  );
                },
              )
            : Center(
                child: Text(
                  '👤',
                  style: TextStyle(fontSize: adaptive.sp(16.0)),
                ),
              ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    final isDark = _isDarkMode();
    
    return PopScope(
      canPop: false, // Prevent default back navigation
      onPopInvoked: (didPop) {
        if (!didPop) {
          _handleBackNavigation();
        }
      },
      child: Theme(
        data: _getCurrentTheme(),
        child: Scaffold(
          body: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: isDark 
                  ? [const Color(0xFF4A5568), const Color(0xFF553C9A)]
                  : [const Color(0xFF667EEA), const Color(0xFF764BA2)],
              ),
            ),
            child: SafeArea(
              child: Container(
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF1A1A1A) : Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: isDark ? 0.3 : 0.1),
                      blurRadius: 30,
                      spreadRadius: 0,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    // Header with simplified app bar
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: isDark 
                            ? [const Color(0xFF4A5568), const Color(0xFF553C9A)]
                            : [const Color(0xFF667EEA), const Color(0xFF764BA2)],
                        ),
                      ),
                      padding: adaptive.responsivePadding(all: 20.0),
                      child: Row(
                        children: [
                          // Logo on the left
                          Container(
                            width: adaptive.responsiveIconSize(40.0),
                            height: adaptive.responsiveIconSize(40.0),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Image.asset(
                                'assets/images/logo.png',
                                width: adaptive.responsiveIconSize(40.0),
                                height: adaptive.responsiveIconSize(40.0),
                                fit: BoxFit.contain,
                                errorBuilder: (context, error, stackTrace) {
                                  return Container(
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Center(
                                      child: Text(
                                        'AE',
                                        style: TextStyle(
                                          color: const Color(0xFF667EEA),
                                          fontSize: adaptive.sp(16.0),
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),
                          const Spacer(),
                          // Profile icon with image support
                          _buildProfileIcon(adaptive),
                          SizedBox(width: adaptive.scale(15.0)),
                          // Theme toggle icon with system support
                          GestureDetector(
                            onTap: _toggleTheme,
                            child: Container(
                              width: adaptive.responsiveIconSize(32.0),
                              height: adaptive.responsiveIconSize(32.0),
                              decoration: BoxDecoration(
                                color: Colors.white.withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Center(
                                child: Text(
                                  _getThemeIcon(),
                                  style: TextStyle(fontSize: adaptive.sp(16.0)),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    // Main Content
                    Expanded(
                      child: _screens[_currentIndex],
                    ),
                  ],
                ),
              ),
            ),
          ),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              color: isDark ? const Color(0xFF2D2D2D) : Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: isDark ? 0.3 : 0.1),
                  blurRadius: 20,
                  offset: const Offset(0, -4),
                ),
              ],
              border: Border(
                top: BorderSide(
                  color: isDark ? const Color(0xFF404040) : const Color(0xFFE0E0E0),
                  width: 1,
                ),
              ),
            ),
            child: SafeArea(
              child: Padding(
                padding: adaptive.responsivePadding(vertical: 15.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildNavItem(0, '🏠', 'Dashboard', adaptive),
                    _buildNavItem(1, '👥', 'Students', adaptive),
                    _buildNavItem(2, '👨‍🏫', 'Lecturers', adaptive),
                    _buildNavItem(5, '📊', 'Reports', adaptive),
                    _buildNavItem(6, '⚙️', 'Settings', adaptive),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(int index, String icon, String label, adaptive) {
    final isActive = _currentIndex == index;
    final isDark = _isDarkMode();
    final color = isActive 
      ? const Color(0xFF667EEA) 
      : (isDark ? const Color(0xFFB0B0B0) : const Color(0xFF666666));

    return GestureDetector(
      onTap: () => _onTabTapped(index),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: adaptive.responsiveIconSize(24.0),
            height: adaptive.responsiveIconSize(24.0),
            child: Center(
              child: Text(
                icon,
                style: TextStyle(fontSize: adaptive.sp(18.0)),
              ),
            ),
          ),
          SizedBox(height: adaptive.scale(4.0)),
          Text(
            label,
            style: TextStyle(
              fontSize: adaptive.sp(10.0),
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
