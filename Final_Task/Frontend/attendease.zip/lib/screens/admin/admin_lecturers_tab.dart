import 'package:flutter/material.dart';
import '../../utils/adaptive_screen_manager.dart';
import 'modals/add_lecturer_modal.dart';
import 'modals/course_assignment_modal.dart';

class AdminLecturersTab extends StatefulWidget {
  const AdminLecturersTab({super.key});

  @override
  State<AdminLecturersTab> createState() => _AdminLecturersTabState();
}

class _AdminLecturersTabState extends State<AdminLecturersTab> {
  final TextEditingController _searchController = TextEditingController();
  
  final List<Map<String, String>> _lecturers = [
    {
      'name': 'Dr. Sarah Wilson',
      'id': 'LEC001',
      'department': 'Computer Science',
      'courses': '3 Courses',
    },
    {
      'name': 'Prof. David Brown',
      'id': 'LEC002',
      'department': 'Mathematics',
      'courses': '2 Courses',
    },
    {
      'name': 'Dr. Lisa Chen',
      'id': 'LEC003',
      'department': 'Physics',
      'courses': '4 Courses',
    },
  ];

  void _showAddLecturerModal() {
    showDialog(
      context: context,
      builder: (context) => const AddLecturerModal(),
    );
  }

  void _assignCourses(String lecturerId, String lecturerName) {
    showDialog(
      context: context,
      builder: (context) => CourseAssignmentModal(
        lecturerId: lecturerId,
        lecturerName: lecturerName,
      ),
    );
  }

  void _editLecturer(String lecturerId) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Editing lecturer $lecturerId'),
        duration: const Duration(seconds: 2),
        backgroundColor: const Color(0xFF667EEA),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    
    return Padding(
      padding: adaptive.responsivePadding(all: 20.0, bottom: 100.0),
      child: Column(
        children: [
          // Search Bar
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Search lecturers...',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: isDarkMode ? const Color(0xFF404040) : const Color(0xFFE0E0E0),
                        width: 2,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(
                        color: Color(0xFF667EEA),
                        width: 2,
                      ),
                    ),
                    contentPadding: adaptive.responsivePadding(horizontal: 12.0, vertical: 10.0),
                    filled: true,
                    fillColor: isDarkMode ? const Color(0xFF383838) : Colors.white,
                  ),
                  style: TextStyle(
                    fontSize: adaptive.sp(14.0),
                    color: isDarkMode ? Colors.white : const Color(0xFF333333),
                  ),
                ),
              ),
              SizedBox(width: adaptive.scale(10.0)),
              ElevatedButton(
                onPressed: _showAddLecturerModal,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF667EEA),
                  foregroundColor: Colors.white,
                  padding: adaptive.responsivePadding(horizontal: 15.0, vertical: 10.0),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: Text(
                  '+ Add',
                  style: TextStyle(fontSize: adaptive.sp(14.0)),
                ),
              ),
            ],
          ),
          SizedBox(height: adaptive.scale(20.0)),
          
          // Lecturers List
          Expanded(
            child: ListView.builder(
              itemCount: _lecturers.length,
              itemBuilder: (context, index) {
                final lecturer = _lecturers[index];
                return Container(
                  margin: EdgeInsets.only(bottom: adaptive.scale(10.0)),
                  padding: adaptive.responsivePadding(all: 15.0),
                  decoration: BoxDecoration(
                    color: isDarkMode ? const Color(0xFF2D2D2D) : Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: isDarkMode ? 0.3 : 0.1),
                        blurRadius: 6,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              lecturer['name']!,
                              style: TextStyle(
                                fontSize: adaptive.sp(14.0),
                                fontWeight: FontWeight.w600,
                                color: isDarkMode ? Colors.white : const Color(0xFF333333),
                              ),
                            ),
                            SizedBox(height: adaptive.scale(4.0)),
                            Text(
                              'ID: ${lecturer['id']} • ${lecturer['department']} • ${lecturer['courses']}',
                              style: TextStyle(
                                fontSize: adaptive.sp(12.0),
                                color: isDarkMode ? const Color(0xFFB0B0B0) : const Color(0xFF666666),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ElevatedButton(
                            onPressed: () => _assignCourses(lecturer['id']!, lecturer['name']!),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF667EEA),
                              foregroundColor: Colors.white,
                              padding: adaptive.responsivePadding(horizontal: 12.0, vertical: 6.0),
                              minimumSize: Size.zero,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6),
                              ),
                            ),
                            child: Text(
                              'Assign',
                              style: TextStyle(fontSize: adaptive.sp(12.0)),
                            ),
                          ),
                          SizedBox(width: adaptive.scale(8.0)),
                          ElevatedButton(
                            onPressed: () => _editLecturer(lecturer['id']!),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF6C757D),
                              foregroundColor: Colors.white,
                              padding: adaptive.responsivePadding(horizontal: 12.0, vertical: 6.0),
                              minimumSize: Size.zero,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6),
                              ),
                            ),
                            child: Text(
                              'Edit',
                              style: TextStyle(fontSize: adaptive.sp(12.0)),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
