import 'package:flutter/material.dart';
import '../../utils/adaptive_screen_manager.dart';

class AdminDashboardTab extends StatefulWidget {
  const AdminDashboardTab({super.key, required this.onNavigate});
  
  final Function(String) onNavigate;

  @override
  State<AdminDashboardTab> createState() => _AdminDashboardTabState();
}

class _AdminDashboardTabState extends State<AdminDashboardTab> {

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    
    return SingleChildScrollView(
      padding: adaptive.responsivePadding(all: 20.0, bottom: 100.0),
      child: Column(
        children: [
          // Stats Row
          Row(
            children: [
              Expanded(
                child: _buildStatCard('156', 'Total Students', adaptive, isDarkMode),
              ),
              SizedBox(width: adaptive.scale(12.0)),
              Expanded(
                child: _buildStatCard('12', 'Lecturers', adaptive, isDarkMode),
              ),
              SizedBox(width: adaptive.scale(12.0)),
              Expanded(
                child: _buildStatCard('8', 'Active Sessions', adaptive, isDarkMode),
              ),
            ],
          ),
          SizedBox(height: adaptive.scale(25.0)),
          
          // Dashboard Grid - Fixed overflow issue
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: adaptive.scale(15.0),
            mainAxisSpacing: adaptive.scale(15.0),
            childAspectRatio: 1.3, // Increased from 1.2 to prevent overflow
            children: [
              _buildDashboardCard(
                '👥', 'Manage Students', 'Add, edit, view students',
                const Color(0xFF667EEA), 'manage-students', adaptive, isDarkMode,
              ),
              _buildDashboardCard(
                '👨‍🏫', 'Manage Lecturers', 'Add, assign lecturers',
                const Color(0xFF28A745), 'manage-lecturers', adaptive, isDarkMode,
              ),
              _buildDashboardCard(
                '📚', 'Manage Courses', 'Create, edit courses',
                const Color(0xFFFFC107), 'manage-courses', adaptive, isDarkMode,
              ),
              _buildDashboardCard(
                '📍', 'Geofence Areas', 'Define class locations',
                const Color(0xFF17A2B8), 'geofence-management', adaptive, isDarkMode,
              ),
              _buildDashboardCard(
                '📊', 'Reports', 'View attendance data',
                const Color(0xFF6F42C1), 'attendance-reports', adaptive, isDarkMode,
              ),
              _buildDashboardCard(
                '⚙️', 'Settings', 'System configuration',
                const Color(0xFF6C757D), 'system-settings', adaptive, isDarkMode,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String number, String label, adaptive, bool isDarkMode) {
    return Container(
      padding: adaptive.responsivePadding(all: 15.0),
      decoration: BoxDecoration(
        color: isDarkMode ? const Color(0xFF2D2D2D) : Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDarkMode ? 0.3 : 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min, // Added to prevent overflow
        children: [
          Text(
            number,
            style: TextStyle(
              fontSize: adaptive.sp(24.0),
              fontWeight: FontWeight.bold,
              color: const Color(0xFF667EEA),
            ),
          ),
          SizedBox(height: adaptive.scale(5.0)),
          Text(
            label,
            style: TextStyle(
              fontSize: adaptive.sp(12.0),
              color: isDarkMode ? const Color(0xFFB0B0B0) : const Color(0xFF666666),
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildDashboardCard(String icon, String title, String description, 
      Color iconColor, String screenName, adaptive, bool isDarkMode) {
    return GestureDetector(
      onTap: () => widget.onNavigate(screenName),
      child: Container(
        padding: adaptive.responsivePadding(all: 14.0), // Reduced from 16.0
        decoration: BoxDecoration(
          color: isDarkMode ? const Color(0xFF2D2D2D) : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.transparent, width: 2),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDarkMode ? 0.3 : 0.1),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: FittedBox( // Added FittedBox to scale content if needed
          fit: BoxFit.scaleDown,
          child: Column(
            mainAxisSize: MainAxisSize.min, // Changed to min to prevent overflow
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: adaptive.responsiveIconSize(30.0),
                height: adaptive.responsiveIconSize(30.0),
                decoration: BoxDecoration(
                  color: iconColor.withOpacity(0.15), // Increased opacity from 0.1 to 0.15
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Center(
                  child: Text(
                    icon,
                    style: TextStyle(fontSize: adaptive.sp(15.0)),
                  ),
                ),
              ),
              SizedBox(height: adaptive.scale(6.0)), // Reduced from 8.0
              Text(
                title,
                style: TextStyle(
                  fontSize: adaptive.sp(12.0), // Reduced from 13.0
                  fontWeight: FontWeight.w600,
                  color: isDarkMode ? Colors.white : const Color(0xFF333333),
                ),
                textAlign: TextAlign.center,
                maxLines: 1, // Reduced from 2
                overflow: TextOverflow.ellipsis,
              ),
              SizedBox(height: adaptive.scale(3.0)), // Reduced from 4.0
              Text(
                description,
                style: TextStyle(
                  fontSize: adaptive.sp(10.0), // Reduced from 11.0
                  color: isDarkMode ? const Color(0xFFB0B0B0) : const Color(0xFF666666),
                ),
                textAlign: TextAlign.center,
                maxLines: 1, // Reduced from 2
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
