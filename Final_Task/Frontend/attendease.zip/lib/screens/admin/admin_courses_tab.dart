import 'package:flutter/material.dart';
import '../../utils/adaptive_screen_manager.dart';
import 'modals/add_course_modal.dart';

class AdminCoursesTab extends StatefulWidget {
  const AdminCoursesTab({super.key});

  @override
  State<AdminCoursesTab> createState() => _AdminCoursesTabState();
}

class _AdminCoursesTabState extends State<AdminCoursesTab> {
  final TextEditingController _searchController = TextEditingController();
  
  final List<Map<String, String>> _courses = [
    {
      'title': 'Data Structures & Algorithms',
      'code': 'CS301',
      'department': 'Computer Science',
      'level': 'Level 300',
      'lecturer': 'Dr. Sarah Wilson',
    },
    {
      'title': 'Linear Algebra',
      'code': 'MATH201',
      'department': 'Mathematics',
      'level': 'Level 200',
      'lecturer': 'Prof. David Brown',
    },
    {
      'title': 'Quantum Physics',
      'code': 'PHY401',
      'department': 'Physics',
      'level': 'Level 400',
      'lecturer': 'Dr. Lisa Chen',
    },
  ];

  void _showAddCourseModal() {
    showDialog(
      context: context,
      builder: (context) => const AddCourseModal(),
    );
  }

  void _editCourse(String courseCode) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Editing course $courseCode'),
        duration: const Duration(seconds: 2),
        backgroundColor: const Color(0xFF667EEA),
      ),
    );
  }

  void _deleteCourse(String courseCode) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Course'),
        content: Text('Are you sure you want to delete course $courseCode?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Course $courseCode deleted successfully!'),
                  duration: const Duration(seconds: 2),
                  backgroundColor: const Color(0xFF667EEA),
                ),
              );
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    
    return Padding(
      padding: adaptive.responsivePadding(all: 20.0, bottom: 100.0),
      child: Column(
        children: [
          // Search Bar
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Search courses...',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: isDarkMode ? const Color(0xFF404040) : const Color(0xFFE0E0E0),
                        width: 2,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(
                        color: Color(0xFF667EEA),
                        width: 2,
                      ),
                    ),
                    contentPadding: adaptive.responsivePadding(horizontal: 12.0, vertical: 10.0),
                    filled: true,
                    fillColor: isDarkMode ? const Color(0xFF383838) : Colors.white,
                  ),
                  style: TextStyle(
                    fontSize: adaptive.sp(14.0),
                    color: isDarkMode ? Colors.white : const Color(0xFF333333),
                  ),
                ),
              ),
              SizedBox(width: adaptive.scale(10.0)),
              ElevatedButton(
                onPressed: _showAddCourseModal,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF667EEA),
                  foregroundColor: Colors.white,
                  padding: adaptive.responsivePadding(horizontal: 15.0, vertical: 10.0),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: Text(
                  '+ Add',
                  style: TextStyle(fontSize: adaptive.sp(14.0)),
                ),
              ),
            ],
          ),
          SizedBox(height: adaptive.scale(20.0)),
          
          // Courses List
          Expanded(
            child: ListView.builder(
              itemCount: _courses.length,
              itemBuilder: (context, index) {
                final course = _courses[index];
                return Container(
                  margin: EdgeInsets.only(bottom: adaptive.scale(10.0)),
                  padding: adaptive.responsivePadding(all: 15.0),
                  decoration: BoxDecoration(
                    color: isDarkMode ? const Color(0xFF2D2D2D) : Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: isDarkMode ? 0.3 : 0.1),
                        blurRadius: 6,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              course['title']!,
                              style: TextStyle(
                                fontSize: adaptive.sp(14.0),
                                fontWeight: FontWeight.w600,
                                color: isDarkMode ? Colors.white : const Color(0xFF333333),
                              ),
                            ),
                            SizedBox(height: adaptive.scale(4.0)),
                            Text(
                              '${course['code']} • ${course['department']} • ${course['level']} • ${course['lecturer']}',
                              style: TextStyle(
                                fontSize: adaptive.sp(12.0),
                                color: isDarkMode ? const Color(0xFFB0B0B0) : const Color(0xFF666666),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ElevatedButton(
                            onPressed: () => _editCourse(course['code']!),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF667EEA),
                              foregroundColor: Colors.white,
                              padding: adaptive.responsivePadding(horizontal: 12.0, vertical: 6.0),
                              minimumSize: Size.zero,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6),
                              ),
                            ),
                            child: Text(
                              'Edit',
                              style: TextStyle(fontSize: adaptive.sp(12.0)),
                            ),
                          ),
                          SizedBox(width: adaptive.scale(8.0)),
                          ElevatedButton(
                            onPressed: () => _deleteCourse(course['code']!),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFDC3545),
                              foregroundColor: Colors.white,
                              padding: adaptive.responsivePadding(horizontal: 12.0, vertical: 6.0),
                              minimumSize: Size.zero,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6),
                              ),
                            ),
                            child: Text(
                              'Delete',
                              style: TextStyle(fontSize: adaptive.sp(12.0)),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
