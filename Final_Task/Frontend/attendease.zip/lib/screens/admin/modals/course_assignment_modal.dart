import 'package:flutter/material.dart';
import '../../../utils/adaptive_screen_manager.dart';

class CourseAssignmentModal extends StatefulWidget {
  final String lecturerId;
  final String lecturerName;
  
  const CourseAssignmentModal({
    super.key,
    required this.lecturerId,
    required this.lecturerName,
  });

  @override
  State<CourseAssignmentModal> createState() => _CourseAssignmentModalState();
}

class _CourseAssignmentModalState extends State<CourseAssignmentModal> {
  final List<Map<String, dynamic>> _availableCourses = [
    {
      'code': 'CS301',
      'title': 'Data Structures & Algorithms',
      'isSelected': false,
    },
    {
      'code': 'CS201',
      'title': 'Programming Fundamentals',
      'isSelected': false,
    },
    {
      'code': 'CS401',
      'title': 'Software Engineering',
      'isSelected': false,
    },
    {
      'code': 'MATH301',
      'title': 'Discrete Mathematics',
      'isSelected': false,
    },
  ];

  void _assignCoursesToLecturer() {
    final selectedCourses = _availableCourses.where((course) => course['isSelected']).length;
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$selectedCourses courses assigned successfully!'),
        duration: const Duration(seconds: 2),
        backgroundColor: const Color(0xFF667EEA),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    
    return Dialog(
      backgroundColor: isDarkMode ? const Color(0xFF2D2D2D) : Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Container(
        width: MediaQuery.of(context).size.width * 0.9,
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.8,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header
            Container(
              padding: adaptive.responsivePadding(all: 20.0),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      'Assign Courses to Lecturer',
                      style: TextStyle(
                        fontSize: adaptive.sp(18.0),
                        fontWeight: FontWeight.w600,
                        color: isDarkMode ? Colors.white : const Color(0xFF333333),
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: adaptive.responsiveIconSize(32.0),
                      height: adaptive.responsiveIconSize(32.0),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Center(
                        child: Text(
                          '×',
                          style: TextStyle(
                            fontSize: adaptive.sp(24.0),
                            color: isDarkMode ? const Color(0xFFB0B0B0) : const Color(0xFF666666),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            
            // Lecturer Info
            Container(
              padding: adaptive.responsivePadding(horizontal: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  RichText(
                    text: TextSpan(
                      style: TextStyle(
                        fontSize: adaptive.sp(14.0),
                        color: isDarkMode ? Colors.white : const Color(0xFF333333),
                      ),
                      children: [
                        const TextSpan(text: 'Lecturer: '),
                        TextSpan(
                          text: widget.lecturerName,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: adaptive.scale(20.0)),
                  Text(
                    'Available Courses',
                    style: TextStyle(
                      fontSize: adaptive.sp(14.0),
                      fontWeight: FontWeight.w500,
                      color: isDarkMode ? Colors.white : const Color(0xFF333333),
                    ),
                  ),
                  SizedBox(height: adaptive.scale(8.0)),
                ],
              ),
            ),
            
            // Courses List
            Expanded(
              child: Container(
                margin: adaptive.responsivePadding(horizontal: 20.0),
                padding: adaptive.responsivePadding(all: 10.0),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: isDarkMode ? const Color(0xFF404040) : const Color(0xFFE0E0E0),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: _availableCourses.length,
                  itemBuilder: (context, index) {
                    final course = _availableCourses[index];
                    return Container(
                      margin: EdgeInsets.only(bottom: adaptive.scale(10.0)),
                      child: Row(
                        children: [
                          Checkbox(
                            value: course['isSelected'],
                            activeColor: const Color(0xFF667EEA),
                            onChanged: (bool? value) {
                              setState(() {
                                course['isSelected'] = value ?? false;
                              });
                            },
                          ),
                          SizedBox(width: adaptive.scale(10.0)),
                          Expanded(
                            child: Text(
                              '${course['code']} - ${course['title']}',
                              style: TextStyle(
                                fontSize: adaptive.sp(14.0),
                                color: isDarkMode ? Colors.white : const Color(0xFF333333),
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),
            
            // Assign Button
            Container(
              padding: adaptive.responsivePadding(all: 20.0),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _assignCoursesToLecturer,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF667EEA),
                    foregroundColor: Colors.white,
                    padding: adaptive.responsivePadding(vertical: 12.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: Text(
                    'Assign Selected Courses',
                    style: TextStyle(
                      fontSize: adaptive.sp(16.0),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
