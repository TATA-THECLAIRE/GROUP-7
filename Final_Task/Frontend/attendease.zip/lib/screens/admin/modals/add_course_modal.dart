import 'package:flutter/material.dart';
import '../../../utils/adaptive_screen_manager.dart';

class AddCourseModal extends StatefulWidget {
  const AddCourseModal({super.key});

  @override
  State<AddCourseModal> createState() => _AddCourseModalState();
}

class _AddCourseModalState extends State<AddCourseModal> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _codeController = TextEditingController();
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _creditsController = TextEditingController();
  
  String _selectedDepartment = '';
  String _selectedLevel = '';
  String _selectedSemester = '';

  final List<String> _departments = [
    'Computer Science',
    'Electrical Engineering',
    'Mechanical Engineering',
    'Mathematics',
    'Physics',
    'Chemistry',
  ];

  final List<String> _levels = [
    'Level 100',
    'Level 200',
    'Level 300',
    'Level 400',
  ];

  final List<String> _semesters = [
    'First Semester',
    'Second Semester',
  ];

  void _addCourse() {
    if (_formKey.currentState!.validate()) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Course added successfully!'),
          duration: Duration(seconds: 2),
          backgroundColor: Color(0xFF667EEA),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    
    return Dialog(
      backgroundColor: isDarkMode ? const Color(0xFF2D2D2D) : Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Container(
        width: MediaQuery.of(context).size.width * 0.9,
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.8,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header
            Container(
              padding: adaptive.responsivePadding(all: 20.0),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      'Add New Course',
                      style: TextStyle(
                        fontSize: adaptive.sp(18.0),
                        fontWeight: FontWeight.w600,
                        color: isDarkMode ? Colors.white : const Color(0xFF333333),
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: adaptive.responsiveIconSize(32.0),
                      height: adaptive.responsiveIconSize(32.0),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Center(
                        child: Text(
                          '×',
                          style: TextStyle(
                            fontSize: adaptive.sp(24.0),
                            color: isDarkMode ? const Color(0xFFB0B0B0) : const Color(0xFF666666),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            
            // Form Content
            Expanded(
              child: SingleChildScrollView(
                padding: adaptive.responsivePadding(horizontal: 20.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      // Course Code
                      _buildFormField(
                        'Course Code',
                        TextFormField(
                          controller: _codeController,
                          decoration: _getInputDecoration('e.g., CS301', isDarkMode, adaptive),
                          style: _getTextStyle(isDarkMode, adaptive),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter course code';
                            }
                            return null;
                          },
                        ),
                        adaptive,
                        isDarkMode,
                      ),
                      
                      // Course Title
                      _buildFormField(
                        'Course Title',
                        TextFormField(
                          controller: _titleController,
                          decoration: _getInputDecoration('e.g., Data Structures & Algorithms', isDarkMode, adaptive),
                          style: _getTextStyle(isDarkMode, adaptive),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter course title';
                            }
                            return null;
                          },
                        ),
                        adaptive,
                        isDarkMode,
                      ),
                      
                      // Department
                      _buildFormField(
                        'Department',
                        DropdownButtonFormField<String>(
                          value: _selectedDepartment.isEmpty ? null : _selectedDepartment,
                          decoration: _getInputDecoration('Select Department', isDarkMode, adaptive),
                          style: _getTextStyle(isDarkMode, adaptive),
                          dropdownColor: isDarkMode ? const Color(0xFF383838) : Colors.white,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please select a department';
                            }
                            return null;
                          },
                          onChanged: (String? newValue) {
                            setState(() {
                              _selectedDepartment = newValue ?? '';
                            });
                          },
                          items: _departments.map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                        ),
                        adaptive,
                        isDarkMode,
                      ),
                      
                      // Level
                      _buildFormField(
                        'Level',
                        DropdownButtonFormField<String>(
                          value: _selectedLevel.isEmpty ? null : _selectedLevel,
                          decoration: _getInputDecoration('Select Level', isDarkMode, adaptive),
                          style: _getTextStyle(isDarkMode, adaptive),
                          dropdownColor: isDarkMode ? const Color(0xFF383838) : Colors.white,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please select a level';
                            }
                            return null;
                          },
                          onChanged: (String? newValue) {
                            setState(() {
                              _selectedLevel = newValue ?? '';
                            });
                          },
                          items: _levels.map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                        ),
                        adaptive,
                        isDarkMode,
                      ),
                      
                      // Credit Units
                      _buildFormField(
                        'Credit Units',
                        TextFormField(
                          controller: _creditsController,
                          keyboardType: TextInputType.number,
                          decoration: _getInputDecoration('3', isDarkMode, adaptive),
                          style: _getTextStyle(isDarkMode, adaptive),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter credit units';
                            }
                            final credits = int.tryParse(value);
                            if (credits == null || credits < 1 || credits > 6) {
                              return 'Credit units must be between 1 and 6';
                            }
                            return null;
                          },
                        ),
                        adaptive,
                        isDarkMode,
                      ),
                      
                      // Semester
                      _buildFormField(
                        'Semester',
                        DropdownButtonFormField<String>(
                          value: _selectedSemester.isEmpty ? null : _selectedSemester,
                          decoration: _getInputDecoration('Select Semester', isDarkMode, adaptive),
                          style: _getTextStyle(isDarkMode, adaptive),
                          dropdownColor: isDarkMode ? const Color(0xFF383838) : Colors.white,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please select a semester';
                            }
                            return null;
                          },
                          onChanged: (String? newValue) {
                            setState(() {
                              _selectedSemester = newValue ?? '';
                            });
                          },
                          items: _semesters.map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                        ),
                        adaptive,
                        isDarkMode,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            
            // Submit Button
            Container(
              padding: adaptive.responsivePadding(all: 20.0),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _addCourse,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF667EEA),
                    foregroundColor: Colors.white,
                    padding: adaptive.responsivePadding(vertical: 12.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: Text(
                    'Add Course',
                    style: TextStyle(
                      fontSize: adaptive.sp(16.0),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFormField(String label, Widget child, adaptive, bool isDarkMode) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: adaptive.sp(14.0),
            fontWeight: FontWeight.w500,
            color: isDarkMode ? Colors.white : const Color(0xFF333333),
          ),
        ),
        SizedBox(height: adaptive.scale(8.0)),
        child,
        SizedBox(height: adaptive.scale(20.0)),
      ],
    );
  }

  InputDecoration _getInputDecoration(String hint, bool isDarkMode, adaptive) {
    return InputDecoration(
      hintText: hint,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(
          color: isDarkMode ? const Color(0xFF404040) : const Color(0xFFE0E0E0),
          width: 2,
        ),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(
          color: Color(0xFF667EEA),
          width: 2,
        ),
      ),
      contentPadding: adaptive.responsivePadding(all: 12.0),
      filled: true,
      fillColor: isDarkMode ? const Color(0xFF383838) : Colors.white,
    );
  }

  TextStyle _getTextStyle(bool isDarkMode, adaptive) {
    return TextStyle(
      fontSize: adaptive.sp(16.0),
      color: isDarkMode ? Colors.white : const Color(0xFF333333),
    );
  }
}
