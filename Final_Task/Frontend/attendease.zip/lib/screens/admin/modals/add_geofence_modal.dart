import 'package:flutter/material.dart';
import '../../../utils/adaptive_screen_manager.dart';

class AddGeofenceModal extends StatefulWidget {
  const AddGeofenceModal({super.key});

  @override
  State<AddGeofenceModal> createState() => _AddGeofenceModalState();
}

class _AddGeofenceModalState extends State<AddGeofenceModal> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _latitudeController = TextEditingController();
  final TextEditingController _longitudeController = TextEditingController();
  final TextEditingController _radiusController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();

  void _addGeofence() {
    if (_formKey.currentState!.validate()) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Geofence location added successfully!'),
          duration: Duration(seconds: 2),
          backgroundColor: Color(0xFF667EEA),
        ),
      );
    }
  }

  void _getCurrentLocation() {
    // Simulate getting current location
    setState(() {
      _latitudeController.text = '5.954700';
      _longitudeController.text = '10.169700';
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Current location captured!'),
        duration: Duration(seconds: 2),
        backgroundColor: Color(0xFF667EEA),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    
    return Dialog(
      backgroundColor: isDarkMode ? const Color(0xFF2D2D2D) : Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Container(
        width: MediaQuery.of(context).size.width * 0.9,
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.8,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header
            Container(
              padding: adaptive.responsivePadding(all: 20.0),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      'Add Geofence Location',
                      style: TextStyle(
                        fontSize: adaptive.sp(18.0),
                        fontWeight: FontWeight.w600,
                        color: isDarkMode ? Colors.white : const Color(0xFF333333),
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: adaptive.responsiveIconSize(32.0),
                      height: adaptive.responsiveIconSize(32.0),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Center(
                        child: Text(
                          '×',
                          style: TextStyle(
                            fontSize: adaptive.sp(24.0),
                            color: isDarkMode ? const Color(0xFFB0B0B0) : const Color(0xFF666666),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            
            // Form Content
            Expanded(
              child: SingleChildScrollView(
                padding: adaptive.responsivePadding(horizontal: 20.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      // Location Name
                      _buildFormField(
                        'Location Name',
                        TextFormField(
                          controller: _nameController,
                          decoration: _getInputDecoration('e.g., Lecture Hall A', isDarkMode, adaptive),
                          style: _getTextStyle(isDarkMode, adaptive),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter location name';
                            }
                            return null;
                          },
                        ),
                        adaptive,
                        isDarkMode,
                      ),
                      
                      // Latitude
                      _buildFormField(
                        'Latitude',
                        TextFormField(
                          controller: _latitudeController,
                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          decoration: _getInputDecoration('5.9547', isDarkMode, adaptive),
                          style: _getTextStyle(isDarkMode, adaptive),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter latitude';
                            }
                            final lat = double.tryParse(value);
                            if (lat == null) {
                              return 'Please enter a valid latitude';
                            }
                            return null;
                          },
                        ),
                        adaptive,
                        isDarkMode,
                      ),
                      
                      // Longitude
                      _buildFormField(
                        'Longitude',
                        TextFormField(
                          controller: _longitudeController,
                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          decoration: _getInputDecoration('10.1697', isDarkMode, adaptive),
                          style: _getTextStyle(isDarkMode, adaptive),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter longitude';
                            }
                            final lng = double.tryParse(value);
                            if (lng == null) {
                              return 'Please enter a valid longitude';
                            }
                            return null;
                          },
                        ),
                        adaptive,
                        isDarkMode,
                      ),
                      
                      // Radius
                      _buildFormField(
                        'Radius (meters)',
                        TextFormField(
                          controller: _radiusController,
                          keyboardType: TextInputType.number,
                          decoration: _getInputDecoration('50', isDarkMode, adaptive),
                          style: _getTextStyle(isDarkMode, adaptive),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter radius';
                            }
                            final radius = int.tryParse(value);
                            if (radius == null || radius < 10 || radius > 200) {
                              return 'Radius must be between 10 and 200 meters';
                            }
                            return null;
                          },
                        ),
                        adaptive,
                        isDarkMode,
                      ),
                      
                      // Description
                      _buildFormField(
                        'Description',
                        TextFormField(
                          controller: _descriptionController,
                          decoration: _getInputDecoration('Building location details', isDarkMode, adaptive),
                          style: _getTextStyle(isDarkMode, adaptive),
                        ),
                        adaptive,
                        isDarkMode,
                      ),
                      
                      // Use Current Location Button
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: _getCurrentLocation,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF6C757D),
                            foregroundColor: Colors.white,
                            padding: adaptive.responsivePadding(vertical: 12.0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                '📍 Use Current Location',
                                style: TextStyle(
                                  fontSize: adaptive.sp(16.0),
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: adaptive.scale(10.0)),
                    ],
                  ),
                ),
              ),
            ),
            
            // Submit Button
            Container(
              padding: adaptive.responsivePadding(all: 20.0),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _addGeofence,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF667EEA),
                    foregroundColor: Colors.white,
                    padding: adaptive.responsivePadding(vertical: 12.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: Text(
                    'Add Location',
                    style: TextStyle(
                      fontSize: adaptive.sp(16.0),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFormField(String label, Widget child, adaptive, bool isDarkMode) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: adaptive.sp(14.0),
            fontWeight: FontWeight.w500,
            color: isDarkMode ? Colors.white : const Color(0xFF333333),
          ),
        ),
        SizedBox(height: adaptive.scale(8.0)),
        child,
        SizedBox(height: adaptive.scale(20.0)),
      ],
    );
  }

  InputDecoration _getInputDecoration(String hint, bool isDarkMode, adaptive) {
    return InputDecoration(
      hintText: hint,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(
          color: isDarkMode ? const Color(0xFF404040) : const Color(0xFFE0E0E0),
          width: 2,
        ),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(
          color: Color(0xFF667EEA),
          width: 2,
        ),
      ),
      contentPadding: adaptive.responsivePadding(all: 12.0),
      filled: true,
      fillColor: isDarkMode ? const Color(0xFF383838) : Colors.white,
    );
  }

  TextStyle _getTextStyle(bool isDarkMode, adaptive) {
    return TextStyle(
      fontSize: adaptive.sp(16.0),
      color: isDarkMode ? Colors.white : const Color(0xFF333333),
    );
  }
}
