import 'package:flutter/material.dart';
import '../../../utils/adaptive_screen_manager.dart';

class AddStudentModal extends StatefulWidget {
  const AddStudentModal({super.key});

  @override
  State<AddStudentModal> createState() => _AddStudentModalState();
}

class _AddStudentModalState extends State<AddStudentModal> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _matricleController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  
  String _selectedDepartment = '';
  String _selectedLevel = '';
  String _selectedGender = '';

  final List<String> _departments = [
    'Computer Science',
    'Electrical Engineering',
    'Mechanical Engineering',
    'Mathematics',
    'Physics',
    'Chemistry',
  ];

  final List<String> _levels = [
    'Level 100',
    'Level 200',
    'Level 300',
    'Level 400',
  ];

  final List<String> _genders = [
    'Male',
    'Female',
  ];

  void _addStudent() {
    if (_formKey.currentState!.validate()) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Student added successfully!'),
          duration: Duration(seconds: 2),
          backgroundColor: Color(0xFF667EEA),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    
    return Dialog(
      backgroundColor: isDarkMode ? const Color(0xFF2D2D2D) : Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Container(
        width: MediaQuery.of(context).size.width * 0.9,
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.8,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header
            Container(
              padding: adaptive.responsivePadding(all: 20.0),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      'Add New Student',
                      style: TextStyle(
                        fontSize: adaptive.sp(18.0),
                        fontWeight: FontWeight.w600,
                        color: isDarkMode ? Colors.white : const Color(0xFF333333),
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: adaptive.responsiveIconSize(32.0),
                      height: adaptive.responsiveIconSize(32.0),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Center(
                        child: Text(
                          '×',
                          style: TextStyle(
                            fontSize: adaptive.sp(24.0),
                            color: isDarkMode ? const Color(0xFFB0B0B0) : const Color(0xFF666666),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            
            // Form Content
            Expanded(
              child: SingleChildScrollView(
                padding: adaptive.responsivePadding(horizontal: 20.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      // Full Name
                      _buildFormField(
                        'Full Name',
                        TextFormField(
                          controller: _nameController,
                          decoration: _getInputDecoration('Enter student\'s full name', isDarkMode, adaptive),
                          style: _getTextStyle(isDarkMode, adaptive),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter student\'s full name';
                            }
                            return null;
                          },
                        ),
                        adaptive,
                        isDarkMode,
                      ),
                      
                      // Matricle Number
                      _buildFormField(
                        'Matricle Number',
                        TextFormField(
                          controller: _matricleController,
                          decoration: _getInputDecoration('e.g., CS2024001', isDarkMode, adaptive),
                          style: _getTextStyle(isDarkMode, adaptive),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter matricle number';
                            }
                            return null;
                          },
                        ),
                        adaptive,
                        isDarkMode,
                      ),
                      
                      // Department
                      _buildFormField(
                        'Department',
                        DropdownButtonFormField<String>(
                          value: _selectedDepartment.isEmpty ? null : _selectedDepartment,
                          decoration: _getInputDecoration('Select Department', isDarkMode, adaptive),
                          style: _getTextStyle(isDarkMode, adaptive),
                          dropdownColor: isDarkMode ? const Color(0xFF383838) : Colors.white,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please select a department';
                            }
                            return null;
                          },
                          onChanged: (String? newValue) {
                            setState(() {
                              _selectedDepartment = newValue ?? '';
                            });
                          },
                          items: _departments.map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                        ),
                        adaptive,
                        isDarkMode,
                      ),
                      
                      // Level
                      _buildFormField(
                        'Level',
                        DropdownButtonFormField<String>(
                          value: _selectedLevel.isEmpty ? null : _selectedLevel,
                          decoration: _getInputDecoration('Select Level', isDarkMode, adaptive),
                          style: _getTextStyle(isDarkMode, adaptive),
                          dropdownColor: isDarkMode ? const Color(0xFF383838) : Colors.white,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please select a level';
                            }
                            return null;
                          },
                          onChanged: (String? newValue) {
                            setState(() {
                              _selectedLevel = newValue ?? '';
                            });
                          },
                          items: _levels.map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                        ),
                        adaptive,
                        isDarkMode,
                      ),
                      
                      // Gender
                      _buildFormField(
                        'Gender',
                        DropdownButtonFormField<String>(
                          value: _selectedGender.isEmpty ? null : _selectedGender,
                          decoration: _getInputDecoration('Select Gender', isDarkMode, adaptive),
                          style: _getTextStyle(isDarkMode, adaptive),
                          dropdownColor: isDarkMode ? const Color(0xFF383838) : Colors.white,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please select gender';
                            }
                            return null;
                          },
                          onChanged: (String? newValue) {
                            setState(() {
                              _selectedGender = newValue ?? '';
                            });
                          },
                          items: _genders.map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                        ),
                        adaptive,
                        isDarkMode,
                      ),
                      
                      // Email
                      _buildFormField(
                        'Email',
                        TextFormField(
                          controller: _emailController,
                          keyboardType: TextInputType.emailAddress,
                          decoration: _getInputDecoration('student@email.com', isDarkMode, adaptive),
                          style: _getTextStyle(isDarkMode, adaptive),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter email address';
                            }
                            if (!value.contains('@')) {
                              return 'Please enter a valid email address';
                            }
                            return null;
                          },
                        ),
                        adaptive,
                        isDarkMode,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            
            // Submit Button
            Container(
              padding: adaptive.responsivePadding(all: 20.0),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _addStudent,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF667EEA),
                    foregroundColor: Colors.white,
                    padding: adaptive.responsivePadding(vertical: 12.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: Text(
                    'Add Student',
                    style: TextStyle(
                      fontSize: adaptive.sp(16.0),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFormField(String label, Widget child, adaptive, bool isDarkMode) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: adaptive.sp(14.0),
            fontWeight: FontWeight.w500,
            color: isDarkMode ? Colors.white : const Color(0xFF333333),
          ),
        ),
        SizedBox(height: adaptive.scale(8.0)),
        child,
        SizedBox(height: adaptive.scale(20.0)),
      ],
    );
  }

  InputDecoration _getInputDecoration(String hint, bool isDarkMode, adaptive) {
    return InputDecoration(
      hintText: hint,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(
          color: isDarkMode ? const Color(0xFF404040) : const Color(0xFFE0E0E0),
          width: 2,
        ),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(
          color: Color(0xFF667EEA),
          width: 2,
        ),
      ),
      contentPadding: adaptive.responsivePadding(all: 12.0),
      filled: true,
      fillColor: isDarkMode ? const Color(0xFF383838) : Colors.white,
    );
  }

  TextStyle _getTextStyle(bool isDarkMode, adaptive) {
    return TextStyle(
      fontSize: adaptive.sp(16.0),
      color: isDarkMode ? Colors.white : const Color(0xFF333333),
    );
  }
}
