import 'package:flutter/material.dart';
import '../../utils/adaptive_screen_manager.dart';

class AdminReportsTab extends StatefulWidget {
  const AdminReportsTab({super.key});

  @override
  State<AdminReportsTab> createState() => _AdminReportsTabState();
}

class _AdminReportsTabState extends State<AdminReportsTab> {
  String _selectedReportType = 'Daily Reports';
  
  final List<String> _reportTypes = [
    'Daily Reports',
    'Weekly Reports',
    'Monthly Reports',
    'Course Reports',
  ];

  final List<Map<String, dynamic>> _recentSessions = [
    {
      'course': 'CS301 - Data Structures',
      'time': 'Today 10:00 AM',
      'attendance': '28/35 students',
      'percentage': '80%',
      'percentageValue': 80,
    },
    {
      'course': 'MATH201 - Linear Algebra',
      'time': 'Today 2:00 PM',
      'attendance': '42/45 students',
      'percentage': '93%',
      'percentageValue': 93,
    },
    {
      'course': 'PHY401 - Quantum Physics',
      'time': 'Yesterday 11:00 AM',
      'attendance': '18/25 students',
      'percentage': '72%',
      'percentageValue': 72,
    },
  ];

  void _exportReports() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Reports exported successfully!'),
        duration: Duration(seconds: 2),
        backgroundColor: Color(0xFF667EEA),
      ),
    );
  }

  Widget _buildStatusBadge(String percentage, int percentageValue, adaptive) {
  Color backgroundColor;
  Color textColor;
  
  // Match HTML logic exactly: 80% and 93% are "status-active", 72% is "status-pending"
  if (percentageValue >= 80) {
    // status-active (green)
    backgroundColor = const Color(0xFFD4EDDA);
    textColor = const Color(0xFF155724);
  } else {
    // status-pending (yellow) 
    backgroundColor = const Color(0xFFFFF3CD);
    textColor = const Color(0xFF856404);
  }
  
  return Container(
    padding: adaptive.responsivePadding(horizontal: 8.0, vertical: 4.0),
    decoration: BoxDecoration(
      color: backgroundColor,
      borderRadius: BorderRadius.circular(12),
    ),
    child: Text(
      percentage,
      style: TextStyle(
        fontSize: adaptive.sp(11.0),
        fontWeight: FontWeight.w500,
        color: textColor,
      ),
    ),
  );
}

  @override
  Widget build(BuildContext context) {
  final adaptive = context.adaptive;
  final isDarkMode = Theme.of(context).brightness == Brightness.dark;
  
  return SingleChildScrollView(
    padding: adaptive.responsivePadding(all: 20.0, bottom: 80.0),
    child: Column(
      children: [
        // Report Type Selector
        Container(
          width: double.infinity,
          padding: adaptive.responsivePadding(horizontal: 12.0, vertical: 12.0),
          decoration: BoxDecoration(
            border: Border.all(
              color: isDarkMode ? const Color(0xFF404040) : const Color(0xFFE0E0E0),
              width: 2,
            ),
            borderRadius: BorderRadius.circular(8),
            color: isDarkMode ? const Color(0xFF383838) : Colors.white,
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: _selectedReportType,
              isExpanded: true,
              style: TextStyle(
                fontSize: adaptive.sp(16.0),
                color: isDarkMode ? Colors.white : const Color(0xFF333333),
              ),
              dropdownColor: isDarkMode ? const Color(0xFF383838) : Colors.white,
              onChanged: (String? newValue) {
                if (newValue != null) {
                  setState(() {
                    _selectedReportType = newValue;
                  });
                }
              },
              items: _reportTypes.map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
          ),
        ),
        SizedBox(height: adaptive.scale(20.0)),
        
        // Stats Row
        Row(
          children: [
            Expanded(
              child: _buildStatCard('85%', 'Avg Attendance', adaptive, isDarkMode),
            ),
            SizedBox(width: adaptive.scale(12.0)),
            Expanded(
              child: _buildStatCard('1,240', 'Total Check-ins', adaptive, isDarkMode),
            ),
            SizedBox(width: adaptive.scale(12.0)),
            Expanded(
              child: _buildStatCard('23', 'Sessions Today', adaptive, isDarkMode),
            ),
          ],
        ),
        SizedBox(height: adaptive.scale(20.0)),
        
        // Recent Sessions Table
        Container(
          decoration: BoxDecoration(
            color: isDarkMode ? const Color(0xFF2D2D2D) : Colors.white,
            borderRadius: BorderRadius.circular(8),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: isDarkMode ? 0.3 : 0.1),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            children: [
              Container(
                width: double.infinity,
                padding: adaptive.responsivePadding(all: 12.0),
                decoration: BoxDecoration(
                  color: isDarkMode ? const Color(0xFF2D2D2D) : const Color(0xFFF8F9FA),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(8),
                    topRight: Radius.circular(8),
                  ),
                  border: Border(
                    bottom: BorderSide(
                      color: isDarkMode ? const Color(0xFF404040) : const Color(0xFFE0E0E0),
                      width: 1,
                    ),
                  ),
                ),
                child: Text(
                  'Recent Attendance Sessions',
                  style: TextStyle(
                    fontSize: adaptive.sp(16.0),
                    fontWeight: FontWeight.w600,
                    color: isDarkMode ? Colors.white : const Color(0xFF333333),
                  ),
                ),
              ),
              ...List.generate(_recentSessions.length, (index) {
                final session = _recentSessions[index];
                final isLast = index == _recentSessions.length - 1;
                
                return Container(
                  padding: adaptive.responsivePadding(all: 12.0),
                  decoration: BoxDecoration(
                    border: isLast ? null : Border(
                      bottom: BorderSide(
                        color: isDarkMode ? const Color(0xFF404040) : const Color(0xFFE0E0E0),
                        width: 1,
                      ),
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              session['course'],
                              style: TextStyle(
                                fontSize: adaptive.sp(14.0),
                                fontWeight: FontWeight.w600,
                                color: isDarkMode ? Colors.white : const Color(0xFF333333),
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            SizedBox(height: adaptive.scale(4.0)),
                            Text(
                              '${session['time']} • ${session['attendance']}',
                              style: TextStyle(
                                fontSize: adaptive.sp(12.0),
                                color: isDarkMode ? const Color(0xFFB0B0B0) : const Color(0xFF666666),
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      _buildStatusBadge(session['percentage'], session['percentageValue'], adaptive),
                    ],
                  ),
                );
              }),
            ],
          ),
        ),
        SizedBox(height: adaptive.scale(16.0)),
        
        // Export Button
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _exportReports,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF667EEA),
              foregroundColor: Colors.white,
              padding: adaptive.responsivePadding(vertical: 12.0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: Text(
              'Export Reports',
              style: TextStyle(
                fontSize: adaptive.sp(16.0),
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ),
      ],
    ),
  );
}

  Widget _buildStatCard(String number, String label, adaptive, bool isDarkMode) {
  return Container(
    padding: adaptive.responsivePadding(all: 12.0),
    decoration: BoxDecoration(
      color: isDarkMode ? const Color(0xFF2D2D2D) : Colors.white,
      borderRadius: BorderRadius.circular(10),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withValues(alpha: isDarkMode ? 0.3 : 0.1),
          blurRadius: 8,
          offset: const Offset(0, 2),
        ),
      ],
    ),
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        FittedBox(
          child: Text(
            number,
            style: TextStyle(
              fontSize: adaptive.sp(22.0),
              fontWeight: FontWeight.bold,
              color: const Color(0xFF667EEA),
            ),
          ),
        ),
        SizedBox(height: adaptive.scale(4.0)),
        Text(
          label,
          style: TextStyle(
            fontSize: adaptive.sp(11.0),
            color: isDarkMode ? const Color(0xFFB0B0B0) : const Color(0xFF666666),
          ),
          textAlign: TextAlign.center,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    ),
  );
}
}
