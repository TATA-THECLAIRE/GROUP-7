import 'package:flutter/material.dart';
import '../../utils/adaptive_screen_manager.dart';
import 'modals/add_student_modal.dart';

class AdminStudentsTab extends StatefulWidget {
  const AdminStudentsTab({super.key});

  @override
  State<AdminStudentsTab> createState() => _AdminStudentsTabState();
}

class _AdminStudentsTabState extends State<AdminStudentsTab> {
  final TextEditingController _searchController = TextEditingController();
  
  final List<Map<String, String>> _students = [
    {
      'name': 'John Doe',
      'matricle': 'CS2021001',
      'department': 'Computer Science',
      'level': 'Level 200',
    },
    {
      'name': 'Jane Smith',
      'matricle': 'EE2021015',
      'department': 'Electrical Engineering',
      'level': 'Level 300',
    },
    {
      'name': 'Mike Johnson',
      'matricle': 'ME2020087',
      'department': 'Mechanical Engineering',
      'level': 'Level 400',
    },
  ];

  void _showAddStudentModal() {
    showDialog(
      context: context,
      builder: (context) => const AddStudentModal(),
    );
  }

  void _editStudent(String matricle) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Editing student $matricle'),
        duration: const Duration(seconds: 2),
        backgroundColor: const Color(0xFF667EEA),
      ),
    );
  }

  void _deleteStudent(String matricle) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Student'),
        content: Text('Are you sure you want to delete student $matricle?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Student $matricle deleted successfully!'),
                  duration: const Duration(seconds: 2),
                  backgroundColor: const Color(0xFF667EEA),
                ),
              );
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    
    return Padding(
      padding: adaptive.responsivePadding(all: 20.0, bottom: 100.0),
      child: Column(
        children: [
          // Search Bar
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Search students...',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: isDarkMode ? const Color(0xFF404040) : const Color(0xFFE0E0E0),
                        width: 2,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(
                        color: Color(0xFF667EEA),
                        width: 2,
                      ),
                    ),
                    contentPadding: adaptive.responsivePadding(horizontal: 12.0, vertical: 10.0),
                    filled: true,
                    fillColor: isDarkMode ? const Color(0xFF383838) : Colors.white,
                  ),
                  style: TextStyle(
                    fontSize: adaptive.sp(14.0),
                    color: isDarkMode ? Colors.white : const Color(0xFF333333),
                  ),
                ),
              ),
              SizedBox(width: adaptive.scale(10.0)),
              ElevatedButton(
                onPressed: _showAddStudentModal,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF667EEA),
                  foregroundColor: Colors.white,
                  padding: adaptive.responsivePadding(horizontal: 15.0, vertical: 10.0),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: Text(
                  '+ Add',
                  style: TextStyle(fontSize: adaptive.sp(14.0)),
                ),
              ),
            ],
          ),
          SizedBox(height: adaptive.scale(20.0)),
          
          // Students List
          Expanded(
            child: ListView.builder(
              itemCount: _students.length,
              itemBuilder: (context, index) {
                final student = _students[index];
                return Container(
                  margin: EdgeInsets.only(bottom: adaptive.scale(10.0)),
                  padding: adaptive.responsivePadding(all: 15.0),
                  decoration: BoxDecoration(
                    color: isDarkMode ? const Color(0xFF2D2D2D) : Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: isDarkMode ? 0.3 : 0.1),
                        blurRadius: 6,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              student['name']!,
                              style: TextStyle(
                                fontSize: adaptive.sp(14.0),
                                fontWeight: FontWeight.w600,
                                color: isDarkMode ? Colors.white : const Color(0xFF333333),
                              ),
                            ),
                            SizedBox(height: adaptive.scale(4.0)),
                            Text(
                              'Matricle: ${student['matricle']} • ${student['department']} • ${student['level']}',
                              style: TextStyle(
                                fontSize: adaptive.sp(12.0),
                                color: isDarkMode ? const Color(0xFFB0B0B0) : const Color(0xFF666666),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ElevatedButton(
                            onPressed: () => _editStudent(student['matricle']!),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF667EEA),
                              foregroundColor: Colors.white,
                              padding: adaptive.responsivePadding(horizontal: 12.0, vertical: 6.0),
                              minimumSize: Size.zero,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6),
                              ),
                            ),
                            child: Text(
                              'Edit',
                              style: TextStyle(fontSize: adaptive.sp(12.0)),
                            ),
                          ),
                          SizedBox(width: adaptive.scale(8.0)),
                          ElevatedButton(
                            onPressed: () => _deleteStudent(student['matricle']!),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFDC3545),
                              foregroundColor: Colors.white,
                              padding: adaptive.responsivePadding(horizontal: 12.0, vertical: 6.0),
                              minimumSize: Size.zero,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6),
                              ),
                            ),
                            child: Text(
                              'Delete',
                              style: TextStyle(fontSize: adaptive.sp(12.0)),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
