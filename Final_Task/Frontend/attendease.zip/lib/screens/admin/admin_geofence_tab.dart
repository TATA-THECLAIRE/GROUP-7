import 'package:flutter/material.dart';
import '../../utils/adaptive_screen_manager.dart';
import 'modals/add_geofence_modal.dart';

class AdminGeofenceTab extends StatefulWidget {
  const AdminGeofenceTab({super.key});

  @override
  State<AdminGeofenceTab> createState() => _AdminGeofenceTabState();
}

class _AdminGeofenceTabState extends State<AdminGeofenceTab> {
  final TextEditingController _searchController = TextEditingController();
  
  final List<Map<String, dynamic>> _geofences = [
    {
      'name': 'Lecture Hall A',
      'id': 'LHA',
      'radius': '50m',
      'status': 'Active',
      'isActive': true,
    },
    {
      'name': 'Computer Lab 1',
      'id': 'CL1',
      'radius': '30m',
      'status': 'Active',
      'isActive': true,
    },
    {
      'name': 'Physics Laboratory',
      'id': 'PL1',
      'radius': '40m',
      'status': 'Inactive',
      'isActive': false,
    },
  ];

  void _showAddGeofenceModal() {
    showDialog(
      context: context,
      builder: (context) => const AddGeofenceModal(),
    );
  }

  void _editGeofence(String geofenceId) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Editing geofence $geofenceId'),
        duration: const Duration(seconds: 2),
        backgroundColor: const Color(0xFF667EEA),
      ),
    );
  }

  void _testGeofence(String geofenceId) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Testing geofence $geofenceId... Signal strength: Good'),
        duration: const Duration(seconds: 2),
        backgroundColor: const Color(0xFF667EEA),
      ),
    );
  }

  Widget _buildStatusBadge(String status, bool isActive, adaptive) {
    return Container(
      padding: adaptive.responsivePadding(horizontal: 8.0, vertical: 4.0),
      decoration: BoxDecoration(
        color: isActive 
          ? const Color(0xFFD4EDDA) 
          : const Color(0xFFF8D7DA),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        status,
        style: TextStyle(
          fontSize: adaptive.sp(11.0),
          fontWeight: FontWeight.w500,
          color: isActive 
            ? const Color(0xFF155724) 
            : const Color(0xFF721C24),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    
    return Padding(
      padding: adaptive.responsivePadding(all: 20.0, bottom: 100.0),
      child: Column(
        children: [
          // Search Bar
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Search locations...',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: isDarkMode ? const Color(0xFF404040) : const Color(0xFFE0E0E0),
                        width: 2,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(
                        color: Color(0xFF667EEA),
                        width: 2,
                      ),
                    ),
                    contentPadding: adaptive.responsivePadding(horizontal: 12.0, vertical: 10.0),
                    filled: true,
                    fillColor: isDarkMode ? const Color(0xFF383838) : Colors.white,
                  ),
                  style: TextStyle(
                    fontSize: adaptive.sp(14.0),
                    color: isDarkMode ? Colors.white : const Color(0xFF333333),
                  ),
                ),
              ),
              SizedBox(width: adaptive.scale(10.0)),
              ElevatedButton(
                onPressed: _showAddGeofenceModal,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF667EEA),
                  foregroundColor: Colors.white,
                  padding: adaptive.responsivePadding(horizontal: 15.0, vertical: 10.0),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: Text(
                  '+ Add',
                  style: TextStyle(fontSize: adaptive.sp(14.0)),
                ),
              ),
            ],
          ),
          SizedBox(height: adaptive.scale(20.0)),
          
          // Geofences List
          Expanded(
            child: ListView.builder(
              itemCount: _geofences.length,
              itemBuilder: (context, index) {
                final geofence = _geofences[index];
                return Container(
                  margin: EdgeInsets.only(bottom: adaptive.scale(10.0)),
                  padding: adaptive.responsivePadding(all: 15.0),
                  decoration: BoxDecoration(
                    color: isDarkMode ? const Color(0xFF2D2D2D) : Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: isDarkMode ? 0.3 : 0.1),
                        blurRadius: 6,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              geofence['name']!,
                              style: TextStyle(
                                fontSize: adaptive.sp(14.0),
                                fontWeight: FontWeight.w600,
                                color: isDarkMode ? Colors.white : const Color(0xFF333333),
                              ),
                            ),
                            SizedBox(height: adaptive.scale(4.0)),
                            Row(
                              children: [
                                Text(
                                  'Radius: ${geofence['radius']} • Status: ',
                                  style: TextStyle(
                                    fontSize: adaptive.sp(12.0),
                                    color: isDarkMode ? const Color(0xFFB0B0B0) : const Color(0xFF666666),
                                  ),
                                ),
                                _buildStatusBadge(geofence['status'], geofence['isActive'], adaptive),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ElevatedButton(
                            onPressed: () => _editGeofence(geofence['id']!),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF667EEA),
                              foregroundColor: Colors.white,
                              padding: adaptive.responsivePadding(horizontal: 12.0, vertical: 6.0),
                              minimumSize: Size.zero,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6),
                              ),
                            ),
                            child: Text(
                              'Edit',
                              style: TextStyle(fontSize: adaptive.sp(12.0)),
                            ),
                          ),
                          SizedBox(width: adaptive.scale(8.0)),
                          ElevatedButton(
                            onPressed: () => _testGeofence(geofence['id']!),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF6C757D),
                              foregroundColor: Colors.white,
                              padding: adaptive.responsivePadding(horizontal: 12.0, vertical: 6.0),
                              minimumSize: Size.zero,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6),
                              ),
                            ),
                            child: Text(
                              'Test',
                              style: TextStyle(fontSize: adaptive.sp(12.0)),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
