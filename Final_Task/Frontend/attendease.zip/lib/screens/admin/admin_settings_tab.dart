import 'package:flutter/material.dart';
import '../../utils/adaptive_screen_manager.dart';

class AdminSettingsTab extends StatefulWidget {
  const AdminSettingsTab({super.key});

  @override
  State<AdminSettingsTab> createState() => _AdminSettingsTabState();
}

class _AdminSettingsTabState extends State<AdminSettingsTab> {
  String _selectedAcademicYear = '2024/2025';
  String _selectedSemester = 'First Semester';
  String _selectedTheme = 'system';
  final TextEditingController _facultyController = TextEditingController(text: 'Faculty of Science and Technology');
  final TextEditingController _sessionDurationController = TextEditingController(text: '120');
  final TextEditingController _geofenceRadiusController = TextEditingController(text: '50');
  double _confidenceThreshold = 0.85;

  final List<String> _academicYears = ['2024/2025', '2025/2026'];
  final List<String> _semesters = ['First Semester', 'Second Semester'];
  final List<Map<String, String>> _themes = [
    {'value': 'system', 'display': 'System Default'},
    {'value': 'light', 'display': 'Light Mode'},
    {'value': 'dark', 'display': 'Dark Mode'},
  ];

  void _saveSettings() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Settings saved successfully!'),
        duration: Duration(seconds: 2),
        backgroundColor: Color(0xFF28A745),
      ),
    );
  }

  void _changeThemeFromSettings(String themeValue) {
    setState(() {
      _selectedTheme = themeValue;
    });
    
    String displayName = _themes.firstWhere((theme) => theme['value'] == themeValue)['display']!;
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Theme changed to $displayName'),
        duration: const Duration(seconds: 2),
        backgroundColor: const Color(0xFF667EEA),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    
    return SingleChildScrollView(
      padding: adaptive.responsivePadding(all: 20.0, bottom: 100.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Academic Year
          _buildFormGroup(
            'Academic Year',
            DropdownButtonFormField<String>(
              value: _selectedAcademicYear,
              decoration: _getInputDecoration(isDarkMode, adaptive),
              style: TextStyle(
                fontSize: adaptive.sp(16.0),
                color: isDarkMode ? Colors.white : const Color(0xFF333333),
              ),
              dropdownColor: isDarkMode ? const Color(0xFF383838) : Colors.white,
              onChanged: (String? newValue) {
                if (newValue != null) {
                  setState(() {
                    _selectedAcademicYear = newValue;
                  });
                }
              },
              items: _academicYears.map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            adaptive,
            isDarkMode,
          ),
          
          // Current Semester
          _buildFormGroup(
            'Current Semester',
            DropdownButtonFormField<String>(
              value: _selectedSemester,
              decoration: _getInputDecoration(isDarkMode, adaptive),
              style: TextStyle(
                fontSize: adaptive.sp(16.0),
                color: isDarkMode ? Colors.white : const Color(0xFF333333),
              ),
              dropdownColor: isDarkMode ? const Color(0xFF383838) : Colors.white,
              onChanged: (String? newValue) {
                if (newValue != null) {
                  setState(() {
                    _selectedSemester = newValue;
                  });
                }
              },
              items: _semesters.map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            adaptive,
            isDarkMode,
          ),
          
          // Faculty Name
          _buildFormGroup(
            'Faculty Name',
            TextFormField(
              controller: _facultyController,
              readOnly: true,
              decoration: _getInputDecoration(isDarkMode, adaptive).copyWith(
                fillColor: isDarkMode ? const Color(0xFF2D2D2D) : const Color(0xFFF8F9FA),
              ),
              style: TextStyle(
                fontSize: adaptive.sp(16.0),
                color: isDarkMode ? Colors.white : const Color(0xFF333333),
              ),
            ),
            adaptive,
            isDarkMode,
          ),
          
          // Default Session Duration
          _buildFormGroup(
            'Default Session Duration (minutes)',
            TextFormField(
              controller: _sessionDurationController,
              keyboardType: TextInputType.number,
              decoration: _getInputDecoration(isDarkMode, adaptive),
              style: TextStyle(
                fontSize: adaptive.sp(16.0),
                color: isDarkMode ? Colors.white : const Color(0xFF333333),
              ),
            ),
            adaptive,
            isDarkMode,
          ),
          
          // Geofence Default Radius
          _buildFormGroup(
            'Geofence Default Radius (meters)',
            TextFormField(
              controller: _geofenceRadiusController,
              keyboardType: TextInputType.number,
              decoration: _getInputDecoration(isDarkMode, adaptive),
              style: TextStyle(
                fontSize: adaptive.sp(16.0),
                color: isDarkMode ? Colors.white : const Color(0xFF333333),
              ),
            ),
            adaptive,
            isDarkMode,
          ),
          
          // Face Recognition Confidence Threshold
          _buildFormGroup(
            'Face Recognition Confidence Threshold',
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Slider(
                  value: _confidenceThreshold,
                  min: 0.7,
                  max: 0.99,
                  divisions: 29,
                  activeColor: const Color(0xFF667EEA),
                  inactiveColor: isDarkMode ? const Color(0xFF404040) : const Color(0xFFE0E0E0),
                  onChanged: (double value) {
                    setState(() {
                      _confidenceThreshold = value;
                    });
                  },
                ),
                Text(
                  'Current: ${(_confidenceThreshold * 100).round()}%',
                  style: TextStyle(
                    fontSize: adaptive.sp(12.0),
                    color: isDarkMode ? const Color(0xFF888888) : const Color(0xFF666666),
                  ),
                ),
              ],
            ),
            adaptive,
            isDarkMode,
          ),
          
          // App Theme
          _buildFormGroup(
            'App Theme',
            DropdownButtonFormField<String>(
              value: _selectedTheme,
              decoration: _getInputDecoration(isDarkMode, adaptive),
              style: TextStyle(
                fontSize: adaptive.sp(16.0),
                color: isDarkMode ? Colors.white : const Color(0xFF333333),
              ),
              dropdownColor: isDarkMode ? const Color(0xFF383838) : Colors.white,
              onChanged: (String? newValue) {
                if (newValue != null) {
                  _changeThemeFromSettings(newValue);
                }
              },
              items: _themes.map<DropdownMenuItem<String>>((Map<String, String> theme) {
                return DropdownMenuItem<String>(
                  value: theme['value'],
                  child: Text(theme['display']!),
                );
              }).toList(),
            ),
            adaptive,
            isDarkMode,
          ),
          
          SizedBox(height: adaptive.scale(30.0)),
          
          // Save Button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _saveSettings,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF28A745),
                foregroundColor: Colors.white,
                padding: adaptive.responsivePadding(vertical: 12.0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: Text(
                'Save Settings',
                style: TextStyle(
                  fontSize: adaptive.sp(16.0),
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFormGroup(String label, Widget child, adaptive, bool isDarkMode) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: adaptive.sp(14.0),
            fontWeight: FontWeight.w500,
            color: isDarkMode ? Colors.white : const Color(0xFF333333),
          ),
        ),
        SizedBox(height: adaptive.scale(8.0)),
        child,
        SizedBox(height: adaptive.scale(20.0)),
      ],
    );
  }

  InputDecoration _getInputDecoration(bool isDarkMode, adaptive) {
    return InputDecoration(
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(
          color: isDarkMode ? const Color(0xFF404040) : const Color(0xFFE0E0E0),
          width: 2,
        ),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(
          color: Color(0xFF667EEA),
          width: 2,
        ),
      ),
      contentPadding: adaptive.responsivePadding(all: 12.0),
      filled: true,
      fillColor: isDarkMode ? const Color(0xFF383838) : Colors.white,
    );
  }
}
