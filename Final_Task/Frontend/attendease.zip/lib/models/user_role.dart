import 'package:flutter/material.dart';

enum UserRole {
  student,
  lecturer,
  admin,
}

extension UserRoleExtension on UserRole {
  String get displayName {
    switch (this) {
      case UserRole.student:
        return 'Student';
      case UserRole.lecturer:
        return 'Lecturer';
      case UserRole.admin:
        return 'System Admin';
    }
  }

  String get emoji {
    switch (this) {
      case UserRole.student:
        return '👨‍🎓';
      case UserRole.lecturer:
        return '👨‍🏫';
      case UserRole.admin:
        return '👨‍💼';
    }
  }

  String get description {
    switch (this) {
      case UserRole.student:
        return 'Check-in to classes';
      case UserRole.lecturer:
        return 'Manage attendance';
      case UserRole.admin:
        return 'System management';
    }
  }

  Color get primaryColor {
    switch (this) {
      case UserRole.student:
        return const Color(0xFF5D3BE3);
      case UserRole.lecturer:
        return const Color(0xFF3B82E3);
      case UserRole.admin:
        return const Color(0xFF9C3BE3);
    }
  }

  Color get lightColor {
    switch (this) {
      case UserRole.student:
        return const Color(0xFFF0EBFF);
      case UserRole.lecturer:
        return const Color(0xFFEBF5FF);
      case UserRole.admin:
        return const Color(0xFFF5EBFF);
    }
  }
}
