import 'package:flutter/material.dart';
import '../utils/responsive_manager.dart';
import 'dart:math' as math;

/// A wrapper widget that automatically handles responsive behavior
/// and prevents overflow issues
class ResponsiveWrapper extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  final EdgeInsets? margin;
  final bool preventOverflow;
  final bool enableSafeArea;
  final CrossAxisAlignment crossAxisAlignment;
  final MainAxisAlignment mainAxisAlignment;

  const ResponsiveWrapper({
    super.key,
    required this.child,
    this.padding,
    this.margin,
    this.preventOverflow = true,
    this.enableSafeArea = true,
    this.crossAxisAlignment = CrossAxisAlignment.center,
    this.mainAxisAlignment = MainAxisAlignment.start,
  });

  @override
  Widget build(BuildContext context) {
    final responsive = context.responsive;
    
    Widget wrappedChild = child;
    
    // Apply safe area if enabled
    if (enableSafeArea) {
      wrappedChild = SafeArea(child: wrappedChild);
    }
    
    // Prevent overflow if enabled
    if (preventOverflow) {
      wrappedChild = SingleChildScrollView(
        physics: const ClampingScrollPhysics(),
        child: ConstrainedBox(
          constraints: BoxConstraints(
            minHeight: responsive.availableHeight,
            maxWidth: responsive.screenWidth,
          ),
          child: IntrinsicHeight(
            child: Column(
              crossAxisAlignment: crossAxisAlignment,
              mainAxisAlignment: mainAxisAlignment,
              children: [wrappedChild],
            ),
          ),
        ),
      );
    }
    
    // Apply responsive padding and margin
    return Container(
      margin: margin ?? responsive.responsiveMargin(all: 0),
      padding: padding ?? responsive.responsivePadding(all: 16),
      child: wrappedChild,
    );
  }
}

/// A responsive container that automatically adjusts its size
class ResponsiveContainer extends StatelessWidget {
  final Widget? child;
  final double? width;
  final double? height;
  final EdgeInsets? padding;
  final EdgeInsets? margin;
  final Decoration? decoration;
  final AlignmentGeometry? alignment;
  final bool autoResize;
  final BoxConstraints? constraints;

  const ResponsiveContainer({
    super.key,
    this.child,
    this.width,
    this.height,
    this.padding,
    this.margin,
    this.decoration,
    this.alignment,
    this.autoResize = true,
    this.constraints,
  });

  @override
  Widget build(BuildContext context) {
    final responsive = context.responsive;
    
    double? containerWidth = width;
    double? containerHeight = height;
    
    if (autoResize) {
      // Auto-resize based on screen size
      if (width != null) {
        containerWidth = math.min(responsive.scale(width!), responsive.screenWidth * 0.95);
      }
      if (height != null) {
        containerHeight = math.min(responsive.scale(height!), responsive.availableHeight * 0.9);
      }
    }
    
    return Container(
      width: containerWidth,
      height: containerHeight,
      constraints: constraints,
      padding: padding != null 
          ? EdgeInsets.only(
              top: responsive.scale(padding!.top),
              bottom: responsive.scale(padding!.bottom),
              left: responsive.scale(padding!.left),
              right: responsive.scale(padding!.right),
            )
          : null,
      margin: margin != null
          ? EdgeInsets.only(
              top: responsive.scale(margin!.top),
              bottom: responsive.scale(margin!.bottom),
              left: responsive.scale(margin!.left),
              right: responsive.scale(margin!.right),
            )
          : null,
      decoration: decoration,
      alignment: alignment,
      child: child,
    );
  }
}

/// A responsive text widget that automatically scales font size
class ResponsiveText extends StatelessWidget {
  final String text;
  final double? fontSize;
  final FontWeight? fontWeight;
  final Color? color;
  final TextAlign? textAlign;
  final int? maxLines;
  final TextOverflow? overflow;
  final TextStyle? style;

  const ResponsiveText(
    this.text, {
    super.key,
    this.fontSize,
    this.fontWeight,
    this.color,
    this.textAlign,
    this.maxLines,
    this.overflow,
    this.style,
  });

  @override
  Widget build(BuildContext context) {
    final responsive = context.responsive;
    
    return Text(
      text,
      style: (style ?? const TextStyle()).copyWith(
        fontSize: fontSize != null ? responsive.sp(fontSize!) : null,
        fontWeight: fontWeight,
        color: color,
      ),
      textAlign: textAlign,
      maxLines: maxLines,
      overflow: overflow ?? TextOverflow.ellipsis,
    );
  }
}

/// A responsive row that prevents overflow
class ResponsiveRow extends StatelessWidget {
  final List<Widget> children;
  final MainAxisAlignment mainAxisAlignment;
  final CrossAxisAlignment crossAxisAlignment;
  final bool preventOverflow;
  final double? spacing;

  const ResponsiveRow({
    super.key,
    required this.children,
    this.mainAxisAlignment = MainAxisAlignment.start,
    this.crossAxisAlignment = CrossAxisAlignment.center,
    this.preventOverflow = true,
    this.spacing,
  });

  @override
  Widget build(BuildContext context) {
    final responsive = context.responsive;
    
    List<Widget> processedChildren = _buildChildrenWithSpacing(responsive);
    
    if (preventOverflow) {
      return LayoutBuilder(
        builder: (context, constraints) {
          // Check if content would overflow
          bool needsScrolling = _checkIfNeedsScrolling(processedChildren, constraints.maxWidth);
          
          if (needsScrolling) {
            // Use horizontal scrolling with intrinsic dimensions
            return SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: mainAxisAlignment,
                crossAxisAlignment: crossAxisAlignment,
                children: _buildNonFlexChildren(processedChildren),
              ),
            );
          } else {
            // Use normal row layout
            return Row(
              mainAxisAlignment: mainAxisAlignment,
              crossAxisAlignment: crossAxisAlignment,
              children: processedChildren,
            );
          }
        },
      );
    }
    
    return Row(
      mainAxisAlignment: mainAxisAlignment,
      crossAxisAlignment: crossAxisAlignment,
      children: processedChildren,
    );
  }
  
  bool _checkIfNeedsScrolling(List<Widget> children, double availableWidth) {
    // Simple heuristic: if we have more than 3 children or very limited width
    return children.length > 3 || availableWidth < 300;
  }
  
  List<Widget> _buildNonFlexChildren(List<Widget> children) {
    // Convert Expanded/Flexible widgets to regular widgets for scrolling
    return children.map((child) {
      Widget innerChild;
      if (child is Expanded) {
        innerChild = child.child;
      } else if (child is Flexible) {
        innerChild = child.child;
      } else {
        innerChild = child;
      }
        
      // Wrap in a container with intrinsic width
      return IntrinsicWidth(child: innerChild);
    }).toList();
  }
  
  List<Widget> _buildChildrenWithSpacing(ResponsiveManager responsive) {
    if (spacing == null || children.isEmpty) return children;
    
    List<Widget> spacedChildren = [];
    for (int i = 0; i < children.length; i++) {
      spacedChildren.add(children[i]);
      if (i < children.length - 1) {
        spacedChildren.add(SizedBox(width: responsive.scale(spacing!)));
      }
    }
    return spacedChildren;
  }
}

/// A responsive column that prevents overflow
class ResponsiveColumn extends StatelessWidget {
  final List<Widget> children;
  final MainAxisAlignment mainAxisAlignment;
  final CrossAxisAlignment crossAxisAlignment;
  final bool preventOverflow;
  final double? spacing;

  const ResponsiveColumn({
    super.key,
    required this.children,
    this.mainAxisAlignment = MainAxisAlignment.start,
    this.crossAxisAlignment = CrossAxisAlignment.center,
    this.preventOverflow = true,
    this.spacing,
  });

  @override
  Widget build(BuildContext context) {
    final responsive = context.responsive;
    
    List<Widget> processedChildren = _buildChildrenWithSpacing(responsive);
    
    if (preventOverflow) {
      return SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: mainAxisAlignment,
          crossAxisAlignment: crossAxisAlignment,
          children: processedChildren,
        ),
      );
    }
    
    return Column(
      mainAxisAlignment: mainAxisAlignment,
      crossAxisAlignment: crossAxisAlignment,
      children: processedChildren,
    );
  }
  
  List<Widget> _buildChildrenWithSpacing(ResponsiveManager responsive) {
    if (spacing == null || children.isEmpty) return children;
    
    List<Widget> spacedChildren = [];
    for (int i = 0; i < children.length; i++) {
      spacedChildren.add(children[i]);
      if (i < children.length - 1) {
        spacedChildren.add(SizedBox(height: responsive.scale(spacing!)));
      }
    }
    return spacedChildren;
  }
}

/// A safe responsive row that automatically handles flex constraints
class SafeResponsiveRow extends StatelessWidget {
  final List<Widget> children;
  final MainAxisAlignment mainAxisAlignment;
  final CrossAxisAlignment crossAxisAlignment;
  final double? spacing;

  const SafeResponsiveRow({
    super.key,
    required this.children,
    this.mainAxisAlignment = MainAxisAlignment.start,
    this.crossAxisAlignment = CrossAxisAlignment.center,
    this.spacing,
  });

  @override
  Widget build(BuildContext context) {
    final responsive = context.responsive;
    
    return LayoutBuilder(
      builder: (context, constraints) {
        List<Widget> processedChildren = _buildSafeChildren(responsive);
        
        return Wrap(
          direction: Axis.horizontal,
          alignment: _getWrapAlignment(mainAxisAlignment),
          crossAxisAlignment: _getWrapCrossAlignment(crossAxisAlignment),
          spacing: spacing != null ? responsive.scale(spacing!) : 0,
          children: processedChildren,
        );
      },
    );
  }
  
  WrapAlignment _getWrapAlignment(MainAxisAlignment mainAxis) {
    switch (mainAxis) {
      case MainAxisAlignment.start:
        return WrapAlignment.start;
      case MainAxisAlignment.end:
        return WrapAlignment.end;
      case MainAxisAlignment.center:
        return WrapAlignment.center;
      case MainAxisAlignment.spaceBetween:
        return WrapAlignment.spaceBetween;
      case MainAxisAlignment.spaceAround:
        return WrapAlignment.spaceAround;
      case MainAxisAlignment.spaceEvenly:
        return WrapAlignment.spaceEvenly;
    }
  }
  
  WrapCrossAlignment _getWrapCrossAlignment(CrossAxisAlignment crossAxis) {
    switch (crossAxis) {
      case CrossAxisAlignment.start:
        return WrapCrossAlignment.start;
      case CrossAxisAlignment.end:
        return WrapCrossAlignment.end;
      case CrossAxisAlignment.center:
        return WrapCrossAlignment.center;
      case CrossAxisAlignment.stretch:
        return WrapCrossAlignment.center; // Wrap doesn't support stretch
      case CrossAxisAlignment.baseline:
        return WrapCrossAlignment.center; // Wrap doesn't support baseline
    }
  }
  
  List<Widget> _buildSafeChildren(ResponsiveManager responsive) {
    return children.map((child) {
      Widget innerChild;
      if (child is Expanded) {
        innerChild = child.child;
      } else if (child is Flexible) {
        innerChild = child.child;
      } else {
        innerChild = child;
      }
      return innerChild;
    }).toList();
  }
}
