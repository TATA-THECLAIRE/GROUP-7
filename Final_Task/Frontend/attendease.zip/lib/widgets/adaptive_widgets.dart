import 'package:flutter/material.dart';
import '../utils/adaptive_screen_manager.dart';

/// Adaptive container that automatically fits screen size
class AdaptiveContainer extends StatelessWidget {
  final Widget? child;
  final double? width;
  final double? height;
  final EdgeInsets? padding;
  final EdgeInsets? margin;
  final Decoration? decoration;
  final AlignmentGeometry? alignment;

  const AdaptiveContainer({
    super.key,
    this.child,
    this.width,
    this.height,
    this.padding,
    this.margin,
    this.decoration,
    this.alignment,
  });

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    
    return Container(
      width: width != null ? adaptive.adaptiveWidth(width!) : null,
      height: height != null ? adaptive.adaptiveHeight(height!) : null,
      padding: padding != null 
          ? EdgeInsets.only(
              top: adaptive.adaptiveSpacing(padding!.top),
              bottom: adaptive.adaptiveSpacing(padding!.bottom),
              left: adaptive.adaptiveSpacing(padding!.left),
              right: adaptive.adaptiveSpacing(padding!.right),
            )
          : null,
      margin: margin != null
          ? EdgeInsets.only(
              top: adaptive.adaptiveSpacing(margin!.top),
              bottom: adaptive.adaptiveSpacing(margin!.bottom),
              left: adaptive.adaptiveSpacing(margin!.left),
              right: adaptive.adaptiveSpacing(margin!.right),
            )
          : null,
      decoration: decoration,
      alignment: alignment,
      child: child,
    );
  }
}

/// Adaptive text that scales perfectly with screen size
class AdaptiveText extends StatelessWidget {
  final String text;
  final double? fontSize;
  final FontWeight? fontWeight;
  final Color? color;
  final TextAlign? textAlign;
  final int? maxLines;
  final TextOverflow? overflow;
  final TextStyle? style;

  const AdaptiveText(
    this.text, {
    super.key,
    this.fontSize,
    this.fontWeight,
    this.color,
    this.textAlign,
    this.maxLines,
    this.overflow,
    this.style,
  });

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    
    return Text(
      text,
      style: (style ?? const TextStyle()).copyWith(
        fontSize: fontSize != null ? adaptive.adaptiveFont(fontSize!) : null,
        fontWeight: fontWeight,
        color: color,
      ),
      textAlign: textAlign,
      maxLines: maxLines,
      overflow: overflow ?? TextOverflow.ellipsis,
    );
  }
}

/// Adaptive button that fits perfectly on any screen
class AdaptiveButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;
  final Color? backgroundColor;
  final Color? textColor;
  final bool isSecondary;
  final bool isLoading;
  final double? width;
  final double? height;
  final double? fontSize;

  const AdaptiveButton({
    super.key,
    required this.text,
    this.onPressed,
    this.backgroundColor,
    this.textColor,
    this.isSecondary = false,
    this.isLoading = false,
    this.width,
    this.height,
    this.fontSize,
  });

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    final primaryColor = backgroundColor ?? const Color(0xFF5D3BE3);
    
    final buttonSize = adaptive.buttonSize;
    final buttonWidth = width != null ? adaptive.adaptiveWidth(width!) : buttonSize.width;
    final buttonHeight = height != null ? adaptive.adaptiveHeight(height!) : buttonSize.height;
    
    return Container(
      width: buttonWidth,
      height: buttonHeight,
      margin: adaptive.adaptiveMargin(bottom: 15),
      child: ElevatedButton(
        onPressed: isLoading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: isSecondary 
              ? primaryColor.withAlpha(51) // 0.2 * 255 = ~51
              : primaryColor,
          foregroundColor: isSecondary 
              ? primaryColor 
              : (textColor ?? Colors.white),
          padding: adaptive.adaptivePadding(horizontal: 16, vertical: 12),
          shape: RoundedRectangleBorder(
            borderRadius: adaptive.adaptiveBorderRadius(12),
            side: isSecondary 
                ? BorderSide(color: primaryColor.withAlpha(77), width: 2) // 0.3 * 255 = ~77
                : BorderSide.none,
          ),
          elevation: 0,
        ),
        child: isLoading
            ? SizedBox(
                height: adaptive.adaptiveIcon(20),
                width: adaptive.adaptiveIcon(20),
                child: const CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                ),
              )
            : AdaptiveText(
                text,
                fontSize: fontSize ?? 16,
                fontWeight: FontWeight.w600,
                color: isSecondary 
                    ? primaryColor 
                    : (textColor ?? Colors.white),
              ),
      ),
    );
  }
}

/// Adaptive row that prevents overflow intelligently
class AdaptiveRow extends StatelessWidget {
  final List<Widget> children;
  final MainAxisAlignment mainAxisAlignment;
  final CrossAxisAlignment crossAxisAlignment;
  final double? spacing;

  const AdaptiveRow({
    super.key,
    required this.children,
    this.mainAxisAlignment = MainAxisAlignment.start,
    this.crossAxisAlignment = CrossAxisAlignment.center,
    this.spacing,
  });

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    
    return LayoutBuilder(
      builder: (context, constraints) {
        // Calculate if content will fit
        double estimatedWidth = _estimateContentWidth(adaptive);
        bool willOverflow = estimatedWidth > constraints.maxWidth;
        
        if (willOverflow) {
          // Use wrap layout for overflow prevention
          return Wrap(
            direction: Axis.horizontal,
            alignment: _getWrapAlignment(mainAxisAlignment),
            crossAxisAlignment: _getWrapCrossAlignment(crossAxisAlignment),
            spacing: spacing != null ? adaptive.adaptiveSpacing(spacing!) : 0,
            runSpacing: adaptive.adaptiveSpacing(8),
            children: children,
          );
        } else {
          // Use normal row layout
          return Row(
            mainAxisAlignment: mainAxisAlignment,
            crossAxisAlignment: crossAxisAlignment,
            children: _buildChildrenWithSpacing(adaptive),
          );
        }
      },
    );
  }
  
  double _estimateContentWidth(AdaptiveScreenManager adaptive) {
    // Simple estimation based on number of children and spacing
    double estimatedWidth = children.length * adaptive.adaptiveWidth(100);
    if (spacing != null) {
      estimatedWidth += (children.length - 1) * adaptive.adaptiveSpacing(spacing!);
    }
    return estimatedWidth;
  }
  
  WrapAlignment _getWrapAlignment(MainAxisAlignment mainAxis) {
    switch (mainAxis) {
      case MainAxisAlignment.start:
        return WrapAlignment.start;
      case MainAxisAlignment.end:
        return WrapAlignment.end;
      case MainAxisAlignment.center:
        return WrapAlignment.center;
      case MainAxisAlignment.spaceBetween:
        return WrapAlignment.spaceBetween;
      case MainAxisAlignment.spaceAround:
        return WrapAlignment.spaceAround;
      case MainAxisAlignment.spaceEvenly:
        return WrapAlignment.spaceEvenly;
    }
  }
  
  WrapCrossAlignment _getWrapCrossAlignment(CrossAxisAlignment crossAxis) {
    switch (crossAxis) {
      case CrossAxisAlignment.start:
        return WrapCrossAlignment.start;
      case CrossAxisAlignment.end:
        return WrapCrossAlignment.end;
      case CrossAxisAlignment.center:
        return WrapCrossAlignment.center;
      case CrossAxisAlignment.stretch:
        return WrapCrossAlignment.center;
      case CrossAxisAlignment.baseline:
        return WrapCrossAlignment.center;
    }
  }
  
  List<Widget> _buildChildrenWithSpacing(AdaptiveScreenManager adaptive) {
    if (spacing == null || children.isEmpty) return children;
    
    List<Widget> spacedChildren = [];
    for (int i = 0; i < children.length; i++) {
      spacedChildren.add(children[i]);
      if (i < children.length - 1) {
        spacedChildren.add(SizedBox(width: adaptive.adaptiveSpacing(spacing!)));
      }
    }
    return spacedChildren;
  }
}

/// Adaptive column that prevents overflow
class AdaptiveColumn extends StatelessWidget {
  final List<Widget> children;
  final MainAxisAlignment mainAxisAlignment;
  final CrossAxisAlignment crossAxisAlignment;
  final double? spacing;
  final bool scrollable;

  const AdaptiveColumn({
    super.key,
    required this.children,
    this.mainAxisAlignment = MainAxisAlignment.start,
    this.crossAxisAlignment = CrossAxisAlignment.center,
    this.spacing,
    this.scrollable = true,
  });

  @override
  Widget build(BuildContext context) {
    final adaptive = context.adaptive;
    
    List<Widget> spacedChildren = _buildChildrenWithSpacing(adaptive);
    
    Widget columnWidget = Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: mainAxisAlignment,
      crossAxisAlignment: crossAxisAlignment,
      children: spacedChildren,
    );
    
    if (scrollable) {
      return SingleChildScrollView(
        child: columnWidget,
      );
    }
    
    return columnWidget;
  }
  
  List<Widget> _buildChildrenWithSpacing(AdaptiveScreenManager adaptive) {
    if (spacing == null || children.isEmpty) return children;
    
    List<Widget> spacedChildren = [];
    for (int i = 0; i < children.length; i++) {
      spacedChildren.add(children[i]);
      if (i < children.length - 1) {
        spacedChildren.add(SizedBox(height: adaptive.adaptiveSpacing(spacing!)));
      }
    }
    return spacedChildren;
  }
}
