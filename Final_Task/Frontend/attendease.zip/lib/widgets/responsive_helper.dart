import 'package:flutter/material.dart';

class ResponsiveHelper {
  static double screenWidth(BuildContext context) => MediaQuery.of(context).size.width;
  static double screenHeight(BuildContext context) => MediaQuery.of(context).size.height;
  
  // Responsive width based on percentage
  static double wp(BuildContext context, double percentage) {
    return screenWidth(context) * percentage / 100;
  }
  
  // Responsive height based on percentage
  static double hp(BuildContext context, double percentage) {
    return screenHeight(context) * percentage / 100;
  }
  
  // Responsive font size
  static double sp(BuildContext context, double size) {
    return size * (screenWidth(context) / 375); // 375 is base width (iPhone X)
  }
  
  // Get device type
  static DeviceType getDeviceType(BuildContext context) {
    double width = screenWidth(context);
    if (width < 600) return DeviceType.mobile;
    if (width < 1200) return DeviceType.tablet;
    return DeviceType.desktop;
  }
  
  // Responsive padding
  static EdgeInsets responsivePadding(BuildContext context, {
    double? all,
    double? horizontal,
    double? vertical,
    double? top,
    double? bottom,
    double? left,
    double? right,
  }) {
    return EdgeInsets.only(
      top: top != null ? hp(context, top) : (vertical != null ? hp(context, vertical) : (all != null ? wp(context, all) : 0)),
      bottom: bottom != null ? hp(context, bottom) : (vertical != null ? hp(context, vertical) : (all != null ? wp(context, all) : 0)),
      left: left != null ? wp(context, left) : (horizontal != null ? wp(context, horizontal) : (all != null ? wp(context, all) : 0)),
      right: right != null ? wp(context, right) : (horizontal != null ? wp(context, horizontal) : (all != null ? wp(context, all) : 0)),
    );
  }
  
  // Responsive margin
  static EdgeInsets responsiveMargin(BuildContext context, {
    double? all,
    double? horizontal,
    double? vertical,
    double? top,
    double? bottom,
    double? left,
    double? right,
  }) {
    return EdgeInsets.only(
      top: top != null ? hp(context, top) : (vertical != null ? hp(context, vertical) : (all != null ? wp(context, all) : 0)),
      bottom: bottom != null ? hp(context, bottom) : (vertical != null ? hp(context, vertical) : (all != null ? wp(context, all) : 0)),
      left: left != null ? wp(context, left) : (horizontal != null ? wp(context, horizontal) : (all != null ? wp(context, all) : 0)),
      right: right != null ? wp(context, right) : (horizontal != null ? wp(context, horizontal) : (all != null ? wp(context, all) : 0)),
    );
  }
  
  // Safe area height (excluding status bar, app bar, etc.)
  static double safeAreaHeight(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    return mediaQuery.size.height - 
           mediaQuery.padding.top - 
           mediaQuery.padding.bottom - 
           kToolbarHeight;
  }
}

enum DeviceType { mobile, tablet, desktop }
