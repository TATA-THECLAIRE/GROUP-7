import 'package:flutter/material.dart';

class ResponsiveImage extends StatelessWidget {
  final String imagePath;
  final double? width;
  final double? height;
  final BoxFit fit;
  final Alignment alignment;
  final Widget? fallback;

  const ResponsiveImage({
    super.key,
    required this.imagePath,
    this.width,
    this.height,
    this.fit = BoxFit.cover,
    this.alignment = Alignment.center,
    this.fallback,
  });

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    
    return SizedBox(
      width: width ?? screenWidth,
      height: height ?? screenHeight,
      child: LayoutBuilder(
        builder: (context, constraints) {
          return ClipRect(
            child: Image.asset(
              imagePath,
              width: constraints.maxWidth,
              height: constraints.maxHeight,
              fit: fit,
              alignment: alignment,
              errorBuilder: (context, error, stackTrace) {
                // ResponsiveImage failed to load: $imagePath - Error: $error
                return fallback ?? Container(
                  width: constraints.maxWidth,
                  height: constraints.maxHeight,
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [Color(0xFF667EEA), Color(0xFF764BA2)],
                    ),
                  ),
                  child: const Center(
                    child: Icon(
                      Icons.image_not_supported,
                      color: Colors.white,
                      size: 50,
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
