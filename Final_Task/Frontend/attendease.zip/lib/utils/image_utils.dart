// Utility functions for handling different image aspect ratios

import 'package:flutter/material.dart';

class ImageUtils {
  // Determine the best BoxFit for different image types
  static BoxFit getBestFitForImage(double containerWidth, double containerHeight) {
    final aspectRatio = containerWidth / containerHeight;
    
    // For mobile screens (typically portrait or square)
    if (aspectRatio <= 1.0) {
      return BoxFit.cover; // Fill the container
    }
    // For wide images (desktop/tablet screenshots)
    else if (aspectRatio > 1.5) {
      return BoxFit.fitHeight; // Fit height and crop sides
    }
    // For moderately wide images
    else {
      return BoxFit.cover; // Standard cover
    }
  }
  
  // Get optimal alignment for wide images on mobile
  static Alignment getOptimalAlignment(double imageAspectRatio, double containerAspectRatio) {
    if (imageAspectRatio > containerAspectRatio * 1.5) {
      // Very wide image - center it
      return Alignment.center;
    } else if (imageAspectRatio > containerAspectRatio) {
      // Moderately wide - slightly favor top
      return Alignment.topCenter;
    } else {
      // Normal aspect ratio
      return Alignment.center;
    }
  }
  
  // Calculate optimal image dimensions for mobile display
  static Size getOptimalImageSize(Size originalSize, Size containerSize) {
    final originalAspectRatio = originalSize.width / originalSize.height;
    final containerAspectRatio = containerSize.width / containerSize.height;
    
    if (originalAspectRatio > containerAspectRatio) {
      // Wide image - fit to height
      final newHeight = containerSize.height;
      final newWidth = newHeight * originalAspectRatio;
      return Size(newWidth, newHeight);
    } else {
      // Tall or square image - fit to width
      final newWidth = containerSize.width;
      final newHeight = newWidth / originalAspectRatio;
      return Size(newWidth, newHeight);
    }
  }
}
