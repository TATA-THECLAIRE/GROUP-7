import 'package:flutter/material.dart';
import 'dart:math' as math;

/// Device categories optimized for mobile devices only
enum DeviceCategory {
  smallMobile,   // < 360px width (older/smaller phones)
  mediumMobile,  // 360-400px width (standard phones)
  largeMobile,   // 400-500px width (larger phones)
  extraLarge,    // > 500px width (phablets/foldables)
}

/// Comprehensive adaptive screen manager optimized for mobile devices
class AdaptiveScreenManager {
  static AdaptiveScreenManager? _instance;
  static AdaptiveScreenManager get instance => _instance ??= AdaptiveScreenManager._();
  AdaptiveScreenManager._();

  // Mobile-optimized base design dimensions
  static const double _baseMobileWidth = 375.0; // iPhone 12/13 width
  static const double _baseMobileHeight = 812.0; // iPhone 12/13 height
  
  // Mobile breakpoints only
  static const double _smallMobileBreakpoint = 360;
  static const double _mediumMobileBreakpoint = 400;
  static const double _largeMobileBreakpoint = 500;
  
  late double _screenWidth;
  late double _screenHeight;
  late double _statusBarHeight;
  late double _bottomPadding;
  late double _scaleFactorWidth;
  late double _scaleFactorHeight;
  late double _textScaleFactor;
  late DeviceCategory _deviceCategory;
  late Orientation _orientation;
  late ScreenProfile _screenProfile;

  /// Initialize with mobile device screen analysis
  void initialize(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final size = mediaQuery.size;
    final devicePixelRatio = mediaQuery.devicePixelRatio;
    final padding = mediaQuery.padding;
    
    _screenWidth = size.width;
    _screenHeight = size.height;
    _statusBarHeight = padding.top;
    _bottomPadding = padding.bottom;
    _orientation = mediaQuery.orientation;
    
    // Calculate mobile-optimized scale factors
    _scaleFactorWidth = _screenWidth / _baseMobileWidth;
    _scaleFactorHeight = _screenHeight / _baseMobileHeight;
    
    // Calculate text scale factor for mobile readability
    _textScaleFactor = math.min(_scaleFactorWidth, _scaleFactorHeight);
    _textScaleFactor = math.max(_textScaleFactor, 0.85); // Minimum scale for readability
    _textScaleFactor = math.min(_textScaleFactor, 1.3); // Maximum scale to prevent oversized text
    
    // Determine mobile device category
    if (_screenWidth < _smallMobileBreakpoint) {
      _deviceCategory = DeviceCategory.smallMobile;
    } else if (_screenWidth < _mediumMobileBreakpoint) {
      _deviceCategory = DeviceCategory.mediumMobile;
    } else if (_screenWidth < _largeMobileBreakpoint) {
      _deviceCategory = DeviceCategory.largeMobile;
    } else {
      _deviceCategory = DeviceCategory.extraLarge;
    }

    // Create screen profile
    _screenProfile = ScreenProfile(
      width: _screenWidth,
      height: _screenHeight,
      availableHeight: _screenHeight - _statusBarHeight - _bottomPadding,
      diagonal: math.sqrt(_screenWidth * _screenWidth + _screenHeight * _screenHeight),
      aspectRatio: _screenWidth / _screenHeight,
      devicePixelRatio: devicePixelRatio,
      deviceCategory: _deviceCategory,
      scaleFactor: _calculateMobileScale(_screenWidth, _screenHeight, _deviceCategory),
      textScaleFactor: _textScaleFactor,
      buttonScaleFactor: _calculateButtonScale(_screenWidth, _screenHeight, _deviceCategory),
      spacingScaleFactor: _calculateSpacingScale(_screenWidth, _screenHeight, _deviceCategory),
      iconScaleFactor: _calculateIconScale(_screenWidth, _screenHeight, _deviceCategory),
      safeAreaTop: _statusBarHeight,
      safeAreaBottom: _bottomPadding,
    );
    
    // Mobile Device Analysis:
    // Size: ${size.width.toInt()}x${size.height.toInt()}
    // Category: ${_deviceCategory.name}
    // Scale: ${_scaleFactorWidth.toStringAsFixed(2)}
  }

  // Mobile-optimized scale calculations
  double _calculateMobileScale(double width, double height, DeviceCategory category) {
    double widthScale = width / _baseMobileWidth;
    double heightScale = height / _baseMobileHeight;
    double baseScale = math.sqrt(widthScale * heightScale);
    
    switch (category) {
      case DeviceCategory.smallMobile:
        return (baseScale * 0.9).clamp(0.8, 1.0);
      case DeviceCategory.mediumMobile:
        return baseScale.clamp(0.9, 1.1);
      case DeviceCategory.largeMobile:
        return (baseScale * 1.05).clamp(1.0, 1.2);
      case DeviceCategory.extraLarge:
        return (baseScale * 1.1).clamp(1.05, 1.25);
    }
  }

  double _calculateButtonScale(double width, double height, DeviceCategory category) {
    double baseButtonScale = width / _baseMobileWidth;
    
    switch (category) {
      case DeviceCategory.smallMobile:
        return (baseButtonScale * 0.9).clamp(0.8, 1.0);
      case DeviceCategory.mediumMobile:
        return (baseButtonScale * 0.95).clamp(0.85, 1.05);
      case DeviceCategory.largeMobile:
        return baseButtonScale.clamp(0.9, 1.15);
      case DeviceCategory.extraLarge:
        return (baseButtonScale * 1.05).clamp(1.0, 1.25);
    }
  }

  double _calculateSpacingScale(double width, double height, DeviceCategory category) {
    double baseSpacingScale = math.min(width / _baseMobileWidth, height / _baseMobileHeight);
    
    switch (category) {
      case DeviceCategory.smallMobile:
        return (baseSpacingScale * 0.8).clamp(0.6, 0.9);
      case DeviceCategory.mediumMobile:
        return (baseSpacingScale * 0.9).clamp(0.8, 1.0);
      case DeviceCategory.largeMobile:
        return baseSpacingScale.clamp(0.9, 1.1);
      case DeviceCategory.extraLarge:
        return (baseSpacingScale * 1.1).clamp(1.0, 1.3);
    }
  }

  double _calculateIconScale(double width, double height, DeviceCategory category) {
    double baseIconScale = width / _baseMobileWidth;
    
    switch (category) {
      case DeviceCategory.smallMobile:
        return (baseIconScale * 0.85).clamp(0.7, 0.95);
      case DeviceCategory.mediumMobile:
        return (baseIconScale * 0.9).clamp(0.8, 1.0);
      case DeviceCategory.largeMobile:
        return baseIconScale.clamp(0.9, 1.1);
      case DeviceCategory.extraLarge:
        return (baseIconScale * 1.1).clamp(1.0, 1.25);
    }
  }

  // Getters
  double get screenWidth => _screenWidth;
  double get screenHeight => _screenHeight;
  double get availableHeight => _screenHeight - _statusBarHeight - _bottomPadding;
  DeviceCategory get deviceCategory => _deviceCategory;
  bool get isPortrait => _orientation == Orientation.portrait;
  ScreenProfile get profile => _screenProfile;

  // Get optimal button size based on device category
  Size get buttonSize {
    switch (_deviceCategory) {
      case DeviceCategory.smallMobile:
        return Size(screenWidth * 0.9, scale(44.0));
      case DeviceCategory.mediumMobile:
        return Size(screenWidth * 0.9, scale(48.0));
      case DeviceCategory.largeMobile:
        return Size(screenWidth * 0.9, scale(52.0));
      case DeviceCategory.extraLarge:
        return Size(screenWidth * 0.9, scale(56.0));
    }
  }

  // Mobile-optimized responsive methods
  double wp(double percentage) => (_screenWidth * percentage / 100).clamp(0.0, _screenWidth);
  double hp(double percentage) => (_screenHeight * percentage / 100).clamp(0.0, _screenHeight);
  
  double sp(double fontSize) {
    double scaledSize = fontSize * _textScaleFactor;
    switch (_deviceCategory) {
      case DeviceCategory.smallMobile:
        return scaledSize.clamp(10.0, 28.0);
      case DeviceCategory.mediumMobile:
        return scaledSize.clamp(11.0, 32.0);
      case DeviceCategory.largeMobile:
        return scaledSize.clamp(12.0, 36.0);
      case DeviceCategory.extraLarge:
        return scaledSize.clamp(13.0, 40.0);
    }
  }

  double scale(double dimension) {
    double scaleFactor = _calculateMobileScale(_screenWidth, _screenHeight, _deviceCategory);
    return (dimension * scaleFactor).clamp(dimension * 0.7, dimension * 1.5);
  }

  // Adaptive methods
  double adaptiveWidth(double baseWidth) {
    return (baseWidth * _screenProfile.scaleFactor).clamp(
      baseWidth * 0.5, 
      _screenWidth * 0.95
    );
  }

  double adaptiveHeight(double baseHeight) {
    return (baseHeight * _screenProfile.scaleFactor).clamp(
      baseHeight * 0.5,
      availableHeight * 0.9
    );
  }

  double adaptiveFont(double baseFontSize) {
    return (baseFontSize * _screenProfile.textScaleFactor).clamp(
      baseFontSize * 0.7,
      baseFontSize * 1.8
    );
  }

  double adaptiveButton(double baseButtonSize) {
    return (baseButtonSize * _screenProfile.buttonScaleFactor).clamp(
      44.0, // Minimum touch target
      baseButtonSize * 2.0
    );
  }

  double adaptiveSpacing(double baseSpacing) {
    return (baseSpacing * _screenProfile.spacingScaleFactor).clamp(
      baseSpacing * 0.5,
      baseSpacing * 2.5
    );
  }

  double adaptiveIcon(double baseIconSize) {
    return (baseIconSize * _screenProfile.iconScaleFactor).clamp(
      16.0, // Minimum icon size
      baseIconSize * 2.0
    );
  }

  // Mobile-optimized button height
  double get buttonHeight {
    switch (_deviceCategory) {
      case DeviceCategory.smallMobile:
        return scale(44.0); // iOS minimum touch target
      case DeviceCategory.mediumMobile:
        return scale(48.0); // Android minimum
      case DeviceCategory.largeMobile:
        return scale(52.0);
      case DeviceCategory.extraLarge:
        return scale(56.0);
    }
  }

  // Mobile-optimized input height
  double get inputHeight {
    switch (_deviceCategory) {
      case DeviceCategory.smallMobile:
        return scale(48.0);
      case DeviceCategory.mediumMobile:
        return scale(52.0);
      case DeviceCategory.largeMobile:
        return scale(56.0);
      case DeviceCategory.extraLarge:
        return scale(60.0);
    }
  }

  EdgeInsets adaptivePadding({
    double? all,
    double? horizontal,
    double? vertical,
    double? top,
    double? bottom,
    double? left,
    double? right,
  }) {
    return EdgeInsets.only(
      top: adaptiveSpacing(top ?? vertical ?? all ?? 0),
      bottom: adaptiveSpacing(bottom ?? vertical ?? all ?? 0),
      left: adaptiveSpacing(left ?? horizontal ?? all ?? 0),
      right: adaptiveSpacing(right ?? horizontal ?? all ?? 0),
    );
  }

  EdgeInsets adaptiveMargin({
    double? all,
    double? horizontal,
    double? vertical,
    double? top,
    double? bottom,
    double? left,
    double? right,
  }) {
    return EdgeInsets.only(
      top: adaptiveSpacing(top ?? vertical ?? all ?? 0),
      bottom: adaptiveSpacing(bottom ?? vertical ?? all ?? 0),
      left: adaptiveSpacing(left ?? horizontal ?? all ?? 0),
      right: adaptiveSpacing(right ?? horizontal ?? all ?? 0),
    );
  }

  // Other methods remain the same but with mobile-optimized constraints
  EdgeInsets responsivePadding({
    double? all,
    double? horizontal,
    double? vertical,
    double? top,
    double? bottom,
    double? left,
    double? right,
  }) {
    return EdgeInsets.only(
      top: scale(top ?? vertical ?? all ?? 0),
      bottom: scale(bottom ?? vertical ?? all ?? 0),
      left: scale(left ?? horizontal ?? all ?? 0),
      right: scale(right ?? horizontal ?? all ?? 0),
    );
  }

  EdgeInsets responsiveMargin({
    double? all,
    double? horizontal,
    double? vertical,
    double? top,
    double? bottom,
    double? left,
    double? right,
  }) {
    return EdgeInsets.only(
      top: scale(top ?? vertical ?? all ?? 0),
      bottom: scale(bottom ?? vertical ?? all ?? 0),
      left: scale(left ?? horizontal ?? all ?? 0),
      right: scale(right ?? horizontal ?? all ?? 0),
    );
  }

  BorderRadius responsiveBorderRadius(double radius) => BorderRadius.circular(scale(radius));
  BorderRadius adaptiveBorderRadius(double radius) => BorderRadius.circular(adaptiveSpacing(radius));

  double responsiveIconSize(double baseSize) => scale(baseSize).clamp(16.0, 48.0);

  BoxConstraints get dialogConstraints {
    double maxWidth = math.min(_screenWidth * 0.9, scale(350));
    double maxHeight = availableHeight * 0.8;
    
    return BoxConstraints(
      maxWidth: maxWidth,
      maxHeight: maxHeight,
      minWidth: math.min(scale(280), _screenWidth * 0.8),
      minHeight: scale(200),
    );
  }
}

/// Screen profile containing all analyzed screen information
class ScreenProfile {
  final double width;
  final double height;
  final double availableHeight;
  final double diagonal;
  final double aspectRatio;
  final double devicePixelRatio;
  final DeviceCategory deviceCategory;
  final double scaleFactor;
  final double textScaleFactor;
  final double buttonScaleFactor;
  final double spacingScaleFactor;
  final double iconScaleFactor;
  final double safeAreaTop;
  final double safeAreaBottom;

  ScreenProfile({
    required this.width,
    required this.height,
    required this.availableHeight,
    required this.diagonal,
    required this.aspectRatio,
    required this.devicePixelRatio,
    required this.deviceCategory,
    required this.scaleFactor,
    required this.textScaleFactor,
    required this.buttonScaleFactor,
    required this.spacingScaleFactor,
    required this.iconScaleFactor,
    required this.safeAreaTop,
    required this.safeAreaBottom,
  });
}

/// Extension for easy access to adaptive screen manager
extension AdaptiveContext on BuildContext {
  AdaptiveScreenManager get adaptive {
    AdaptiveScreenManager.instance.initialize(this);
    return AdaptiveScreenManager.instance;
  }
}

/// Extension methods for easy adaptive scaling
extension AdaptiveExtension on num {
  double get aw => AdaptiveScreenManager.instance.adaptiveWidth(toDouble());
  double get ah => AdaptiveScreenManager.instance.adaptiveHeight(toDouble());
  double get af => AdaptiveScreenManager.instance.adaptiveFont(toDouble());
  double get ab => AdaptiveScreenManager.instance.adaptiveButton(toDouble());
  double get as => AdaptiveScreenManager.instance.adaptiveSpacing(toDouble());
  double get ai => AdaptiveScreenManager.instance.adaptiveIcon(toDouble());
}
