/// University of Buea Faculty of Engineering and Technology
/// Custom validators matching backend validation logic
/// 
/// IMPORTANT: These validators should match the backend validators in:
/// - backend/utils/ub_validators.py
/// - backend/utils/validators.py
/// 
/// When updating validation rules, update both frontend and backend!
class FETValidators {
  
  /// Validate UB FET matricle number format: ABC/YYYY/NNNN
  /// Format: 3-letter department code + / + 4-digit year + / + 4-digit number
  /// 
  /// Backend equivalent: validate_ub_matricle_number() in backend/utils/ub_validators.py
  static String? validateUBMatricleNumber(String? value) {
    if (value == null || value.isEmpty) {
      return 'Matricle number is required';
    }
    
    // UB FET matricle pattern: ABC/YYYY/NNNN
    final RegExp pattern = RegExp(r'^[A-Z]{3}/\d{4}/\d{4}$');
    
    if (!pattern.hasMatch(value.toUpperCase())) {
      return 'Invalid matricle number format. Expected: ABC/YYYY/NNNN (e.g., CSC/2024/1179)';
    }
    
    // Extract and validate year
    final List<String> parts = value.split('/');
    final int year = int.parse(parts[1]);
    final int currentYear = DateTime.now().year;
    
    // Validate year is reasonable (not more than 1 year in future or 10 years in past)
    if (year > currentYear + 1 || year < currentYear - 10) {
      return 'Invalid year in matricle number. Year \'$year\' seems unrealistic';
    }
    
    return null;
  }
  
  /// Validate UB lecturer institutional email: firstname.lastname@ubuea.cm
  /// 
  /// Backend equivalent: validate_ub_lecturer_email() in backend/utils/ub_validators.py
  static String? validateUBLecturerEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Email is required';
    }
    
    // UB institutional email pattern for LECTURERS
    final RegExp pattern = RegExp(r'^[a-zA-Z]+\.[a-zA-Z]+@ubuea\.cm$');
    
    if (!pattern.hasMatch(value.toLowerCase())) {
      return 'Invalid UB lecturer email. Expected: firstname.lastname@ubuea.cm';
    }
    
    return null;
  }
  
  /// Validate student email - must NOT be @ubuea.cm (personal emails only)
  /// Enhanced validation to prevent double dots and other edge cases
  /// 
  /// Backend equivalent: validate_ub_student_email() in backend/utils/ub_validators.py
  static String? validateUBStudentEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Email is required';
    }
    
    // Check for double dots (not allowed)
    if (value.contains('..')) {
      return 'Email cannot contain consecutive dots';
    }
    
    // Check for leading/trailing dots
    if (value.startsWith('.') || value.endsWith('.')) {
      return 'Email cannot start or end with a dot';
    }
    
    // General email validation
    final RegExp emailPattern = RegExp(r'^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$');
    
    if (!emailPattern.hasMatch(value.toLowerCase())) {
      return 'Invalid email format';
    }
    
    // Students should NOT use institutional email
    if (value.toLowerCase().contains('@ubuea.cm')) {
      return 'Students should use personal emails. UB institutional emails are not active for students.';
    }
    
    return null;
  }
  
  /// Validate email based on user type (matches backend validate_email_by_user_type)
  /// 
  /// Backend equivalent: validate_email_by_user_type() in backend/utils/ub_validators.py
  static String? validateEmailByUserType(String? email, String userType) {
    switch (userType.toLowerCase()) {
      case 'lecturer':
        return validateUBLecturerEmail(email);
      case 'student':
        return validateUBStudentEmail(email);
      case 'admin':
        return validateGeneralEmail(email);
      default:
        return validateGeneralEmail(email);
    }
  }
  
  /// General email validation for admins with enhanced checks
  /// 
  /// Backend equivalent: validate_general_email() in backend/utils/validators.py
  static String? validateGeneralEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Email is required';
    }
    
    // Check for double dots (not allowed)
    if (value.contains('..')) {
      return 'Email cannot contain consecutive dots';
    }
    
    // Check for leading/trailing dots
    if (value.startsWith('.') || value.endsWith('.')) {
      return 'Email cannot start or end with a dot';
    }
    
    final RegExp pattern = RegExp(r'^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$');
    
    if (!pattern.hasMatch(value.toLowerCase())) {
      return 'Invalid email format';
    }
    
    return null;
  }
  
  /// Validate UB FET course code format (enhanced to reject spaces)
  /// Format: 3-letter department code + 3-digit number (no spaces allowed)
  /// 
  /// Backend equivalent: validate_ub_course_code() in backend/utils/ub_validators.py
  static String? validateUBCourseCode(String? value, {String? departmentCode}) {
    if (value == null || value.isEmpty) {
      return 'Course code is required';
    }
    
    // Check for spaces (not allowed)
    if (value.contains(' ')) {
      return 'Course code cannot contain spaces. Expected format: CSC476';
    }
    
    // Check for special characters (except allowed ones)
    if (RegExp(r'[^A-Za-z0-9]').hasMatch(value)) {
      return 'Course code can only contain letters and numbers';
    }
    
    // Valid department prefixes for UB FET
    final List<String> validPrefixes = ['CSC', 'ENG', 'MTH', 'PHY', 'CHM', 'CEF', 'EEF', 'MEF', 'CIV'];
    
    // Course code pattern: 3-letter prefix + 3-digit number
    final RegExp pattern = RegExp(r'^([A-Z]{3})(\d{3})$');
    final RegExpMatch? match = pattern.firstMatch(value.toUpperCase());
    
    if (match == null) {
      return 'Invalid course code format. Expected: 3-letter department code + 3-digit number (e.g., CSC476)';
    }
    
    final String prefix = match.group(1)!;
    final String number = match.group(2)!;
    final int numberInt = int.parse(number);
    
    // Validate department prefix
    if (!validPrefixes.contains(prefix)) {
      return 'Invalid department code \'$prefix\'. Valid codes: ${validPrefixes.join(', ')}';
    }
    
    // Validate department code matches if provided
    if (departmentCode != null && prefix != departmentCode) {
      return 'Course code prefix \'$prefix\' doesn\'t match department code \'$departmentCode\'';
    }
    
    // Validate number range (100-599 for undergraduate courses)
    if (numberInt < 100 || numberInt > 599) {
      return 'Course number should be between 100-599 for undergraduate courses';
    }
    
    return null;
  }
  
  /// Enhanced password validation (matches backend validate_password)
  /// 
  /// Backend equivalent: validate_password() in backend/utils/validators.py
  static String? validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Password is required';
    }
    
    if (value.length < 8) {
      return 'Password must be at least 8 characters long';
    }
    
    if (value.length > 128) {
      return 'Password must be less than 128 characters long';
    }
    
    if (!RegExp(r'[A-Za-z]').hasMatch(value)) {
      return 'Password must contain at least one letter';
    }
    
    if (!RegExp(r'\d').hasMatch(value)) {
      return 'Password must contain at least one number';
    }
    
    if (!RegExp(r'[!@#$%^&*(),.?":{}|<>]').hasMatch(value)) {
      return 'Password must contain at least one special character (!@#\$%^&*(),.?":{}|<>)';
    }
    
    // Check for common weak patterns
    final String lowerValue = value.toLowerCase();
    final List<String> weakPatterns = [
      'password', '12345678', 'qwerty', 'abc123', 'letmein', 
      'welcome', 'monkey', 'dragon', 'master', 'admin'
    ];
    
    for (String pattern in weakPatterns) {
      if (lowerValue.contains(pattern)) {
        return 'Password contains common weak pattern. Please choose a stronger password';
      }
    }
    
    return null;
  }
  
  /// Validate phone number (enhanced with Cameroon format)
  /// 
  /// Backend equivalent: validate_phone_number() in backend/utils/validators.py
  static String? validatePhoneNumber(String? value) {
    if (value == null || value.isEmpty) {
      return null; // Phone is optional
    }
    
    // Remove spaces and common separators for validation
    final String cleanValue = value.replaceAll(RegExp(r'[\s\-()]'), '');
    
    // Cameroon phone number patterns
    if (cleanValue.startsWith('+237')) {
      // International format: +237 6XX XXX XXX
      if (!RegExp(r'^\+237[67]\d{8}$').hasMatch(cleanValue)) {
        return 'Invalid Cameroon phone number. Expected: +237 6XX XXX XXX';
      }
    } else if (cleanValue.startsWith('237')) {
      // Without + prefix: 237 6XX XXX XXX
      if (!RegExp(r'^237[67]\d{8}$').hasMatch(cleanValue)) {
        return 'Invalid Cameroon phone number. Expected: 237 6XX XXX XXX';
      }
    } else if (cleanValue.startsWith('6')) {
      // Local format: 6XX XXX XXX
      if (!RegExp(r'^[67]\d{8}$').hasMatch(cleanValue)) {
        return 'Invalid Cameroon phone number. Expected: 6XX XXX XXX';
      }
    } else {
      // General international format
      if (!RegExp(r'^\+?[\d]{10,15}$').hasMatch(cleanValue)) {
        return 'Invalid phone number format';
      }
    }
    
    return null;
  }
  
  /// Validate UB FET classroom names (updated list)
  /// 
  /// Backend equivalent: validate_ub_classroom() in backend/utils/ub_validators.py
  static String? validateUBClassroom(String? value) {
    if (value == null || value.isEmpty) {
      return 'Classroom is required';
    }
    
    final List<String> validClassrooms = [
      'FET-BGFL',
      'FET-Hall 1', 'FET-Hall 2', 'FET-Hall 3',
      'Tech 1', 'Tech 2', 'Tech 3', 'Tech 4', 'Tech 5',
      'Lab 1', 'Lab 2', 'Lab 3',
      'Amphitheatre 1', 'Amphitheatre 2'
    ];
    
    if (!validClassrooms.contains(value)) {
      return 'Invalid classroom. Valid options: ${validClassrooms.join(', ')}';
    }
    
    return null;
  }
  
  /// Validate required fields
  /// 
  /// Backend equivalent: validate_required() in backend/utils/validators.py
  static String? validateRequired(String? value, String fieldName) {
    if (value == null || value.trim().isEmpty) {
      return '$fieldName is required';
    }
    return null;
  }
  
  /// Validate password confirmation
  /// 
  /// Backend equivalent: validate_password_confirmation() in backend/utils/validators.py
  static String? validatePasswordConfirmation(String? value, String? password) {
    if (value == null || value.isEmpty) {
      return 'Please confirm your password';
    }
    
    if (value != password) {
      return 'Passwords do not match';
    }
    
    return null;
  }
  
  /// Validate full name (enhanced)
  static String? validateFullName(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Full name is required';
    }
    
    if (value.trim().length < 2) {
      return 'Full name must be at least 2 characters long';
    }
    
    if (value.trim().length > 100) {
      return 'Full name must be less than 100 characters long';
    }
    
    // Check for valid characters (letters, spaces, hyphens, apostrophes)
    if (!RegExp(r"^[a-zA-Z\s\-']+$").hasMatch(value.trim())) {
      return 'Full name can only contain letters, spaces, hyphens, and apostrophes';
    }
    
    return null;
  }
  
  /// Validate lecturer ID format
  static String? validateLecturerID(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Lecturer ID is required';
    }
    
    // Simple format validation - can be customized based on institution requirements
    if (value.trim().length < 3) {
      return 'Lecturer ID must be at least 3 characters long';
    }
    
    if (value.trim().length > 20) {
      return 'Lecturer ID must be less than 20 characters long';
    }
    
    return null;
  }
  
  /// Validate admin ID format
  static String? validateAdminID(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Admin ID is required';
    }
    
    // Simple format validation - can be customized based on institution requirements
    if (value.trim().length < 3) {
      return 'Admin ID must be at least 3 characters long';
    }
    
    if (value.trim().length > 20) {
      return 'Admin ID must be less than 20 characters long';
    }
    
    return null;
  }
  
  /// Get department info from course code
  /// 
  /// Backend equivalent: get_department_from_course_code() in backend/utils/ub_validators.py
  static Map<String, String>? getDepartmentFromCourseCode(String courseCode) {
    final Map<String, Map<String, String>> departmentMapping = {
      'CSC': {
        'name': 'Computer Science',
        'full_name': 'Department of Computer Science'
      },
      'CEF': {
        'name': 'Computer Engineering',
        'full_name': 'Department of Computer Engineering'
      },
      'EEF': {
        'name': 'Electrical Engineering', 
        'full_name': 'Department of Electrical Engineering'
      },
      'CIV': {
        'name': 'Civil Engineering',
        'full_name': 'Department of Civil Engineering'
      },
      'MEF': {
        'name': 'Mechanical and Petroleum Engineering',
        'full_name': 'Department of Mechanical and Petroleum Engineering'
      },
      'ENG': {
        'name': 'English',
        'full_name': 'Department of English'
      },
      'MTH': {
        'name': 'Mathematics',
        'full_name': 'Department of Mathematics'
      },
      'PHY': {
        'name': 'Physics',
        'full_name': 'Department of Physics'
      },
      'CHM': {
        'name': 'Chemistry',
        'full_name': 'Department of Chemistry'
      }
    };
    
    if (courseCode.length >= 3) {
      final String prefix = courseCode.substring(0, 3).toUpperCase();
      return departmentMapping[prefix];
    }
    
    return null;
  }
  
  /// Validate department selection
  static String? validateDepartment(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Department is required';
    }
    
    final List<String> validDepartments = [
      'CE - Computer Engineering',
      'EE - Electrical Engineering', 
      'ME - Mechanical Engineering',
      'CVE - Civil Engineering',
      'CHE - Chemical Engineering',
      'CS - Computer Science',
      'MTH - Mathematics',
      'PHY - Physics',
      'CHM - Chemistry',
      'ENG - English'
    ];
    
    if (!validDepartments.contains(value)) {
      return 'Please select a valid department';
    }
    
    return null;
  }
  
  /// Validate level selection
  static String? validateLevel(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Level is required';
    }
    
    final List<String> validLevels = [
      'Level 100', 'Level 200', 'Level 300', 'Level 400', 'Level 500'
    ];
    
    if (!validLevels.contains(value)) {
      return 'Please select a valid level';
    }
    
    return null;
  }
  
  /// Validate gender selection
  static String? validateGender(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Gender is required';
    }
    
    final List<String> validGenders = ['Male', 'Female'];
    
    if (!validGenders.contains(value)) {
      return 'Please select a valid gender';
    }
    
    return null;
  }
}
