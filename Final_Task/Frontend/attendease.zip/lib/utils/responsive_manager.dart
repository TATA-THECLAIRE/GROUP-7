import 'package:flutter/material.dart';
import 'dart:math' as math;

/// Comprehensive responsive manager that automatically handles screen size adaptations
/// This is a singleton class that provides global access to responsive utilities
class ResponsiveManager {
  static ResponsiveManager? _instance;
  static ResponsiveManager get instance => _instance ??= ResponsiveManager._();
  ResponsiveManager._();

  // Base design dimensions (can be adjusted based on your design)
  static const double _baseWidth = 375.0; // iPhone X width
  static const double _baseHeight = 812.0; // iPhone X height
  
  // Screen size categories
  static const double _mobileBreakpoint = 600;
  static const double _tabletBreakpoint = 1024;
  
  late double _screenWidth;
  late double _screenHeight;
  late double _statusBarHeight;
  late double _bottomPadding;
  late double _scaleFactorWidth;
  late double _scaleFactorHeight;
  late double _textScaleFactor;
  late DeviceType _deviceType;
  late Orientation _orientation;

  /// Initialize the responsive manager with current context
  void init(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final size = mediaQuery.size;
    final padding = mediaQuery.padding;
    
    _screenWidth = size.width;
    _screenHeight = size.height;
    _statusBarHeight = padding.top;
    _bottomPadding = padding.bottom;
    _orientation = mediaQuery.orientation;
    
    // Calculate scale factors
    _scaleFactorWidth = _screenWidth / _baseWidth;
    _scaleFactorHeight = _screenHeight / _baseHeight;
    
    // Calculate text scale factor (more conservative scaling)
    _textScaleFactor = math.min(_scaleFactorWidth, _scaleFactorHeight);
    _textScaleFactor = math.max(_textScaleFactor, 0.8); // Minimum scale
    _textScaleFactor = math.min(_textScaleFactor, 1.4); // Maximum scale
    
    // Determine device type
    if (_screenWidth < _mobileBreakpoint) {
      _deviceType = DeviceType.mobile;
    } else if (_screenWidth < _tabletBreakpoint) {
      _deviceType = DeviceType.tablet;
    } else {
      _deviceType = DeviceType.desktop;
    }
  }

  // Getters for screen information
  double get screenWidth => _screenWidth;
  double get screenHeight => _screenHeight;
  double get statusBarHeight => _statusBarHeight;
  double get bottomPadding => _bottomPadding;
  double get availableHeight => _screenHeight - _statusBarHeight - _bottomPadding;
  DeviceType get deviceType => _deviceType;
  Orientation get orientation => _orientation;
  bool get isPortrait => _orientation == Orientation.portrait;
  bool get isLandscape => _orientation == Orientation.landscape;

  /// Responsive width based on percentage of screen width
  double wp(double percentage) {
    return (_screenWidth * percentage / 100).clamp(0.0, _screenWidth);
  }

  /// Responsive height based on percentage of screen height
  double hp(double percentage) {
    return (_screenHeight * percentage / 100).clamp(0.0, _screenHeight);
  }

  /// Responsive font size that scales with screen size
  double sp(double fontSize) {
    double scaledSize = fontSize * _textScaleFactor;
    
    // Apply device-specific adjustments
    switch (_deviceType) {
      case DeviceType.mobile:
        return scaledSize.clamp(10.0, 32.0);
      case DeviceType.tablet:
        return (scaledSize * 1.1).clamp(12.0, 40.0);
      case DeviceType.desktop:
        return (scaledSize * 1.2).clamp(14.0, 48.0);
    }
  }

  /// Responsive dimension that scales proportionally
  double scale(double dimension) {
    double scaleFactor = math.min(_scaleFactorWidth, _scaleFactorHeight);
    return (dimension * scaleFactor).clamp(dimension * 0.5, dimension * 2.0);
  }

  /// Responsive padding that adapts to screen size
  EdgeInsets responsivePadding({
    double? all,
    double? horizontal,
    double? vertical,
    double? top,
    double? bottom,
    double? left,
    double? right,
  }) {
    return EdgeInsets.only(
      top: scale(top ?? vertical ?? all ?? 0),
      bottom: scale(bottom ?? vertical ?? all ?? 0),
      left: scale(left ?? horizontal ?? all ?? 0),
      right: scale(right ?? horizontal ?? all ?? 0),
    );
  }

  /// Responsive margin that adapts to screen size
  EdgeInsets responsiveMargin({
    double? all,
    double? horizontal,
    double? vertical,
    double? top,
    double? bottom,
    double? left,
    double? right,
  }) {
    return EdgeInsets.only(
      top: scale(top ?? vertical ?? all ?? 0),
      bottom: scale(bottom ?? vertical ?? all ?? 0),
      left: scale(left ?? horizontal ?? all ?? 0),
      right: scale(right ?? horizontal ?? all ?? 0),
    );
  }

  /// Get responsive container constraints
  BoxConstraints responsiveConstraints({
    double? minWidth,
    double? maxWidth,
    double? minHeight,
    double? maxHeight,
  }) {
    return BoxConstraints(
      minWidth: minWidth != null ? scale(minWidth) : 0,
      maxWidth: maxWidth != null ? scale(maxWidth) : double.infinity,
      minHeight: minHeight != null ? scale(minHeight) : 0,
      maxHeight: maxHeight != null ? scale(maxHeight) : double.infinity,
    );
  }

  /// Get responsive border radius
  BorderRadius responsiveBorderRadius(double radius) {
    return BorderRadius.circular(scale(radius));
  }

  /// Get responsive icon size
  double responsiveIconSize(double baseSize) {
    return scale(baseSize).clamp(16.0, 64.0);
  }

  /// Calculate optimal button height
  double get buttonHeight {
    switch (_deviceType) {
      case DeviceType.mobile:
        return scale(48.0);
      case DeviceType.tablet:
        return scale(52.0);
      case DeviceType.desktop:
        return scale(56.0);
    }
  }

  /// Calculate optimal input field height
  double get inputHeight {
    switch (_deviceType) {
      case DeviceType.mobile:
        return scale(56.0);
      case DeviceType.tablet:
        return scale(60.0);
      case DeviceType.desktop:
        return scale(64.0);
    }
  }

  /// Get responsive spacing
  double spacing(SpacingSize size) {
    double baseSpacing;
    switch (size) {
      case SpacingSize.xs:
        baseSpacing = 4.0;
        break;
      case SpacingSize.sm:
        baseSpacing = 8.0;
        break;
      case SpacingSize.md:
        baseSpacing = 16.0;
        break;
      case SpacingSize.lg:
        baseSpacing = 24.0;
        break;
      case SpacingSize.xl:
        baseSpacing = 32.0;
        break;
      case SpacingSize.xxl:
        baseSpacing = 48.0;
        break;
    }
    return scale(baseSpacing);
  }

  /// Check if content fits in available space
  bool contentFits(double contentWidth, double contentHeight) {
    return contentWidth <= _screenWidth && contentHeight <= availableHeight;
  }

  /// Get safe area insets
  EdgeInsets get safeAreaInsets {
    return EdgeInsets.only(
      top: _statusBarHeight,
      bottom: _bottomPadding,
    );
  }

  /// Get responsive dialog constraints with better overflow prevention
  BoxConstraints get dialogConstraints {
    double maxWidth = math.min(_screenWidth * 0.85, 400);
    double maxHeight = availableHeight * 0.75;
    
    return BoxConstraints(
      maxWidth: maxWidth,
      maxHeight: maxHeight,
      minWidth: math.min(250, _screenWidth * 0.6),
      minHeight: 200,
    );
  }
}

/// Device type enumeration
enum DeviceType { mobile, tablet, desktop }

/// Spacing size enumeration
enum SpacingSize { xs, sm, md, lg, xl, xxl }

/// Extension methods for easy access to responsive utilities
extension ResponsiveExtension on num {
  /// Convert to responsive width percentage
  double get wp => ResponsiveManager.instance.wp(toDouble());
  
  /// Convert to responsive height percentage
  double get hp => ResponsiveManager.instance.hp(toDouble());
  
  /// Convert to responsive font size
  double get sp => ResponsiveManager.instance.sp(toDouble());
  
  /// Convert to responsive scaled dimension
  double get scale => ResponsiveManager.instance.scale(toDouble());
}

/// Extension for BuildContext to easily access responsive utilities
extension ResponsiveContext on BuildContext {
  ResponsiveManager get responsive {
    ResponsiveManager.instance.init(this);
    return ResponsiveManager.instance;
  }
}
