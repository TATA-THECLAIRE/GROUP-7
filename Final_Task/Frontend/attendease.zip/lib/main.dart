import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/homepage_screen.dart';
import 'screens/debug/pre_integration_check_screen.dart';
import 'utils/adaptive_screen_manager.dart';
import 'config/feature_flags.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Set preferred orientations
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  
  runApp(const AttendEaseApp());
}

class AttendEaseApp extends StatelessWidget {
  const AttendEaseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AttendEase',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        primaryColor: const Color(0xFF5D3BE3),
        fontFamily: 'Inter',
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: Builder(
        builder: (context) {
          // Initialize adaptive screen manager on first build
          context.adaptive;
          
          // Show debug screen in debug mode, otherwise show homepage
          return FeatureFlags.isDebugMode 
              ? const PreIntegrationCheckScreen()
              : const HomepageScreen();
        },
      ),
      routes: {
        '/home': (context) => const HomepageScreen(),
        '/debug': (context) => const PreIntegrationCheckScreen(),
      },
      debugShowCheckedModeBanner: false,
    );
  }
}
