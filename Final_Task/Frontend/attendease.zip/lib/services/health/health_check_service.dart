import 'package:dio/dio.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:developer' as developer;
import '../../config/api_config.dart';

class HealthCheckService {
  static Future<SystemHealthStatus> checkSystemHealth() async {
    final results = <String, HealthCheckResult>{};
    
    // Check network connectivity
    results['network'] = await _checkNetworkConnectivity();
    
    // Check backend connectivity with server wake-up
    results['backend'] = await _checkBackendConnectivity();
    
    // Check permissions
    results['permissions'] = await _checkPermissions();
    
    // Check storage
    results['storage'] = await _checkStorage();
    
    return SystemHealthStatus(
      results: results,
      timestamp: DateTime.now(),
    );
  }
  
  static Future<HealthCheckResult> _checkNetworkConnectivity() async {
    try {
      final connectivityResults = await Connectivity().checkConnectivity();
      
      // Check if no connectivity or only none
      if (connectivityResults.isEmpty || 
          connectivityResults.every((result) => result == ConnectivityResult.none)) {
        return HealthCheckResult.unhealthy(
          'No internet connection',
          'Please check your network connection',
        );
      }
      
      // Get the first non-none connection type
      final activeConnection = connectivityResults.firstWhere(
        (result) => result != ConnectivityResult.none,
        orElse: () => ConnectivityResult.none,
      );
      
      return HealthCheckResult.healthy(
        'Network connection available',
        'Connected via ${activeConnection.toString().split('.').last}',
      );
    } catch (e) {
      return HealthCheckResult.unhealthy(
        'Network check failed',
        e.toString(),
      );
    }
  }
  
  static Future<HealthCheckResult> _checkBackendConnectivity() async {
    try {
      final dio = Dio();
      
      // First attempt with longer timeout for server wake-up
      dio.options.connectTimeout = const Duration(seconds: 45);
      dio.options.receiveTimeout = const Duration(seconds: 45);
      dio.options.sendTimeout = const Duration(seconds: 45);
      
      // Try to wake up the server first
      try {
        developer.log('🌐 Attempting to wake up server...');
        final response = await dio.get(ApiConfig.buildUrl(ApiConfig.healthEndpoint));
        
        if (response.statusCode == 200) {
          return HealthCheckResult.healthy(
            'Backend is accessible',
            'Server responded: ${response.statusCode}',
          );
        } else {
          return HealthCheckResult.warning(
            'Backend responded with status ${response.statusCode}',
            'Backend may be experiencing issues',
          );
        }
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionTimeout || 
            e.type == DioExceptionType.receiveTimeout) {
          return HealthCheckResult.warning(
            'Backend server is sleeping',
            'Free tier servers sleep after inactivity. Try again in 30-60 seconds.',
          );
        } else if (e.type == DioExceptionType.connectionError) {
          return HealthCheckResult.unhealthy(
            'Cannot connect to backend',
            'Server may be down or URL incorrect: ${e.message}',
          );
        } else {
          return HealthCheckResult.unhealthy(
            'Backend connection failed',
            e.message ?? 'Unknown error',
          );
        }
      }
    } catch (e) {
      return HealthCheckResult.unhealthy(
        'Backend health check failed',
        e.toString(),
      );
    }
  }
  
  static Future<HealthCheckResult> _checkPermissions() async {
    try {
      final permissions = [
        Permission.camera,
        Permission.location,
        Permission.storage,
      ];
      
      final statuses = await permissions.request();
      final deniedPermissions = <String>[];
      final grantedPermissions = <String>[];
      
      for (final entry in statuses.entries) {
        if (entry.value.isGranted) {
          grantedPermissions.add(entry.key.toString().split('.').last);
        } else {
          deniedPermissions.add(entry.key.toString().split('.').last);
        }
      }
      
      if (deniedPermissions.isEmpty) {
        return HealthCheckResult.healthy(
          'All permissions granted',
          'Granted: ${grantedPermissions.join(', ')}',
        );
      } else if (grantedPermissions.isNotEmpty) {
        return HealthCheckResult.warning(
          'Some permissions missing',
          'Missing: ${deniedPermissions.join(', ')}',
        );
      } else {
        return HealthCheckResult.unhealthy(
          'Critical permissions denied',
          'Denied: ${deniedPermissions.join(', ')}',
        );
      }
    } catch (e) {
      return HealthCheckResult.warning(
        'Permission check failed',
        e.toString(),
      );
    }
  }
  
  static Future<HealthCheckResult> _checkStorage() async {
    try {
      // Test shared preferences
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('health_check', DateTime.now().toString());
      final testValue = prefs.getString('health_check');
      
      if (testValue != null) {
        return HealthCheckResult.healthy(
          'Storage is working',
          'SharedPreferences read/write successful',
        );
      } else {
        return HealthCheckResult.unhealthy(
          'Storage read failed',
          'Cannot read from SharedPreferences',
        );
      }
    } catch (e) {
      return HealthCheckResult.unhealthy(
        'Storage check failed',
        e.toString(),
      );
    }
  }
}

class SystemHealthStatus {
  final Map<String, HealthCheckResult> results;
  final DateTime timestamp;
  
  SystemHealthStatus({
    required this.results,
    required this.timestamp,
  });
  
  bool get isHealthy => results.values.every((result) => result.isHealthy);
  
  bool get hasErrors => results.values.any((result) => result.status == HealthItemStatus.unhealthy);
  
  bool get hasWarnings => results.values.any((result) => result.status == HealthItemStatus.warning);
  
  List<String> get failedServices => results.entries
      .where((entry) => entry.value.status == HealthItemStatus.unhealthy)
      .map((entry) => entry.key)
      .toList();
  
  List<String> get warningServices => results.entries
      .where((entry) => entry.value.status == HealthItemStatus.warning)
      .map((entry) => entry.key)
      .toList();
  
  bool get isReadyForIntegration {
    // Must have network and backend connectivity (or at least backend warning for sleeping server)
    final networkOk = results['network']?.isHealthy ?? false;
    final backendOk = results['backend']?.isHealthy ?? false;
    final backendWarning = results['backend']?.status == HealthItemStatus.warning;
    
    return networkOk && (backendOk || backendWarning);
  }
  
  String get statusSummary {
    if (isHealthy) return 'All systems healthy';
    if (hasErrors) return 'System has errors';
    if (hasWarnings) return 'System has warnings (server may be sleeping)';
    return 'Unknown status';
  }
}

class HealthCheckResult {
  final HealthItemStatus status;
  final String message;
  final String? details;
  
  HealthCheckResult._(this.status, this.message, this.details);
  
  factory HealthCheckResult.healthy(String message, [String? details]) {
    return HealthCheckResult._(HealthItemStatus.healthy, message, details);
  }
  
  factory HealthCheckResult.warning(String message, [String? details]) {
    return HealthCheckResult._(HealthItemStatus.warning, message, details);
  }
  
  factory HealthCheckResult.unhealthy(String message, [String? details]) {
    return HealthCheckResult._(HealthItemStatus.unhealthy, message, details);
  }
  
  bool get isHealthy => status == HealthItemStatus.healthy;
}

enum HealthItemStatus {
  healthy,
  warning,
  unhealthy,
}
