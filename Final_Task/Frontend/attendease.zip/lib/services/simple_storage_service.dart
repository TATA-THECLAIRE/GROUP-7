import 'package:flutter/foundation.dart';

// Simple in-memory storage that persists during app session
class SimpleStorageService {
  static final Map<String, String> _storage = {};
  
  static Future<void> setString(String key, String value) async {
    _storage[key] = value;
    if (kDebugMode) {
      print('Stored: $key = $value');
    }
  }
  
  static Future<String?> getString(String key) async {
    final value = _storage[key];
    if (kDebugMode) {
      print('Retrieved: $key = $value');
    }
    return value;
  }
  
  static Future<void> setBool(String key, bool value) async {
    _storage[key] = value.toString();
  }
  
  static Future<bool> getBool(String key) async {
    final value = _storage[key];
    return value?.toLowerCase() == 'true';
  }
  
  static Future<void> clear() async {
    _storage.clear();
  }
}
