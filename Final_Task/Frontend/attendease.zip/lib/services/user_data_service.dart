import '../models/user_role.dart';
import 'simple_storage_service.dart';

class UserData {
  final UserRole role;
  final String id;
  final String fullName;
  final String email;
  final String password;
  final String? department;
  final String? level;
  final String? phoneNumber;
  final String? institution;
  
  UserData({
    required this.role,
    required this.id,
    required this.fullName,
    required this.email,
    required this.password,
    this.department,
    this.level,
    this.phoneNumber,
    this.institution,
  });
  
  Map<String, dynamic> toJson() {
    return {
      'role': role.toString(),
      'id': id,
      'fullName': fullName,
      'email': email,
      'password': password,
      'department': department,
      'level': level,
      'phoneNumber': phoneNumber,
      'institution': institution,
    };
  }
  
  static UserData fromJson(Map<String, dynamic> json) {
    UserRole role;
    try {
      role = UserRole.values.firstWhere(
        (e) => e.toString() == json['role'],
        orElse: () => UserRole.student,
      );
    } catch (_) {
      role = UserRole.student;
    }
    
    return UserData(
      role: role,
      id: json['id'] ?? '',
      fullName: json['fullName'] ?? '',
      email: json['email'] ?? '',
      password: json['password'] ?? '',
      department: json['department'],
      level: json['level'],
      phoneNumber: json['phoneNumber'],
      institution: json['institution'],
    );
  }
}

class UserDataService {
  static const String _keyIsSignedUp = 'is_signed_up';
  static const String _keyAutoLoginEnabled = 'auto_login_enabled';
  static const String _keyCurrentUserRole = 'current_user_role';

  // Store multiple users by role
  static const String _keyStudentData = 'student_data';
  static const String _keyLecturerData = 'lecturer_data';
  static const String _keyAdminData = 'admin_data';

  static Future<void> setAutoLoginEnabled(bool enabled) async {
    await SimpleStorageService.setBool(_keyAutoLoginEnabled, enabled);
  }

  static Future<bool> isAutoLoginEnabled() async {
    return await SimpleStorageService.getBool(_keyAutoLoginEnabled);
  }

  static Future<void> setCurrentUserRole(UserRole role) async {
    await SimpleStorageService.setString(_keyCurrentUserRole, role.toString());
  }

  static Future<UserRole?> getCurrentUserRole() async {
    final roleString = await SimpleStorageService.getString(_keyCurrentUserRole);
    if (roleString == null) return null;
    
    try {
      return UserRole.values.firstWhere(
        (e) => e.toString() == roleString,
      );
    } catch (_) {
      return null;
    }
  }
  
  static Future<void> saveUser(UserData userData) async {
    await SimpleStorageService.setBool(_keyIsSignedUp, true);
    
    // Store user data by role
    String key;
    switch (userData.role) {
      case UserRole.student:
        key = _keyStudentData;
        break;
      case UserRole.lecturer:
        key = _keyLecturerData;
        break;
      case UserRole.admin:
        key = _keyAdminData;
        break;
    }
    
    // Simple string storage for demo purposes
    String userDataString = '${userData.role}|${userData.id}|${userData.fullName}|${userData.email}|${userData.password}|${userData.department ?? ''}|${userData.level ?? ''}|${userData.phoneNumber ?? ''}|${userData.institution ?? ''}';
    await SimpleStorageService.setString(key, userDataString);
    
    // Set as current user
    await setCurrentUserRole(userData.role);
  }
  
  static Future<UserData?> getUser(UserRole role) async {
    String key;
    switch (role) {
      case UserRole.student:
        key = _keyStudentData;
        break;
      case UserRole.lecturer:
        key = _keyLecturerData;
        break;
      case UserRole.admin:
        key = _keyAdminData;
        break;
    }
    
    final userDataStr = await SimpleStorageService.getString(key);
    if (userDataStr == null) return null;
    
    try {
      final parts = userDataStr.split('|');
      if (parts.length >= 5) {
        return UserData(
          role: UserRole.values.firstWhere(
            (e) => e.toString() == parts[0],
            orElse: () => role,
          ),
          id: parts[1],
          fullName: parts[2],
          email: parts[3],
          password: parts[4],
          department: parts.length > 5 && parts[5].isNotEmpty ? parts[5] : null,
          level: parts.length > 6 && parts[6].isNotEmpty ? parts[6] : null,
          phoneNumber: parts.length > 7 && parts[7].isNotEmpty ? parts[7] : null,
          institution: parts.length > 8 && parts[8].isNotEmpty ? parts[8] : null,
        );
      }
    } catch (e) {
      // Error parsing user data for $role: $e
    }
    
    return null;
  }

  static Future<UserData?> getCurrentUser() async {
    final currentRole = await getCurrentUserRole();
    if (currentRole == null) return null;
    return await getUser(currentRole);
  }
  
  static Future<bool> isUserRegistered(UserRole role) async {
    final userData = await getUser(role);
    return userData != null;
  }

  static Future<bool> validateLogin(UserRole role, String id, String password) async {
    final userData = await getUser(role);
    if (userData == null) return false;
    
    return userData.id == id && userData.password == password;
  }
  
  static Future<bool> isUserSignedUp() async {
    return await SimpleStorageService.getBool(_keyIsSignedUp);
  }
  
  static Future<void> clearUser() async {
    await SimpleStorageService.clear();
  }

  static Future<void> clearUserByRole(UserRole role) async {
    String key;
    switch (role) {
      case UserRole.student:
        key = _keyStudentData;
        break;
      case UserRole.lecturer:
        key = _keyLecturerData;
        break;
      case UserRole.admin:
        key = _keyAdminData;
        break;
    }
    await SimpleStorageService.setString(key, '');
  }
}
