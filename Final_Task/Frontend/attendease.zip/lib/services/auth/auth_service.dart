import 'package:dio/dio.dart';
import 'dart:developer' as developer;
import '../../models/user_role.dart';
import '../../config/feature_flags.dart';
import '../../config/api_config.dart';
import '../api/api_service.dart';

/// Enhanced Authentication Service with improved validation
/// This service handles all authentication-related operations including:
/// - User registration with enhanced validation
/// - User login with proper error handling
/// - Email and matricle number validation
/// - Backend health checks
/// - Mock data fallback for development
class AuthService {
  
  /// Check if the backend is healthy and responsive
  static Future<Map<String, dynamic>> checkBackendHealth() async {
    try {
      developer.log('🏥 Checking backend health...', name: 'AUTH_SERVICE');
      
      if (!FeatureFlags.USE_REAL_API) {
        return {
          'success': true,
          'message': 'Mock backend is always healthy',
          'is_mock': true,
        };
      }
      
      final response = await ApiService.healthCheck();
      
      if (response['status'] == 'healthy') {
        developer.log('✅ Backend health check passed', name: 'AUTH_SERVICE');
        return {
          'success': true,
          'message': 'Backend is healthy and ready',
          'data': response,
          'is_api_call': true,
        };
      } else {
        developer.log('⚠️ Backend health check returned non-healthy status', name: 'AUTH_SERVICE');
        return {
          'success': false,
          'message': 'Backend is not fully healthy',
          'data': response,
          'is_api_call': true,
        };
      }
    } catch (e) {
      developer.log('❌ Backend health check failed: $e', name: 'AUTH_SERVICE');
      
      if (FeatureFlags.USE_MOCK_DATA_FALLBACK) {
        return {
          'success': true,
          'message': 'Using mock data due to backend unavailability',
          'error': e.toString(),
          'is_fallback': true,
        };
      }
      
      return {
        'success': false,
        'message': 'Backend health check failed',
        'error': e.toString(),
      };
    }
  }
  
  /// Validate FET email format based on user type
  static Future<Map<String, dynamic>> validateFETEmail(String email, String userType) async {
    try {
      developer.log('📧 Validating FET email: $email for $userType', name: 'AUTH_SERVICE');
      
      if (!FeatureFlags.USE_REAL_API) {
        // Mock validation logic
        if (userType.toLowerCase() == 'lecturer') {
          if (!email.contains('@ubuea.cm') || !email.contains('.')) {
            return {
              'success': false,
              'error': 'Lecturer email must be firstname.lastname@ubuea.cm format',
              'is_mock': true,
            };
          }
        } else if (userType.toLowerCase() == 'student') {
          if (email.contains('@ubuea.cm')) {
            return {
              'success': false,
              'error': 'Students should use personal emails, not @ubuea.cm',
              'is_mock': true,
            };
          }
        }
        
        return {
          'success': true,
          'message': 'Email format is valid (mock validation)',
          'is_mock': true,
        };
      }
      
      final response = await ApiService.post(
        ApiConfig.validateEmailEndpoint,
        data: {
          'email': email,
          'user_type': userType,
        },
      );
      
      if (response.statusCode == 200) {
        return {
          'success': true,
          'message': response.data['message'] ?? 'Email format is valid',
          'is_api_call': true,
        };
      } else {
        return {
          'success': false,
          'error': response.data['error'] ?? 'Email validation failed',
          'is_api_call': true,
        };
      }
    } catch (e) {
      developer.log('❌ Email validation error: $e', name: 'AUTH_SERVICE');
      
      if (FeatureFlags.USE_MOCK_DATA_FALLBACK) {
        return {
          'success': true,
          'message': 'Email validation skipped (fallback mode)',
          'error': e.toString(),
          'is_fallback': true,
        };
      }
      
      return {
        'success': false,
        'error': 'Email validation failed: ${e.toString()}',
      };
    }
  }
  
  /// Validate FET matricle number format
  static Future<Map<String, dynamic>> validateFETMatricle(String matricleNumber) async {
    try {
      developer.log('🎓 Validating FET matricle: $matricleNumber', name: 'AUTH_SERVICE');
      
      if (!FeatureFlags.USE_REAL_API) {
        // Mock validation logic
        final RegExp pattern = RegExp(r'^[A-Z]{3}/\d{4}/\d{4}$');
        if (!pattern.hasMatch(matricleNumber.toUpperCase())) {
          return {
            'success': false,
            'error': 'Invalid matricle format. Expected: ABC/YYYY/NNNN',
            'is_mock': true,
          };
        }
        
        return {
          'success': true,
          'message': 'Matricle number format is valid (mock validation)',
          'is_mock': true,
        };
      }
      
      final response = await ApiService.post(
        ApiConfig.validateMatricleEndpoint,
        data: {
          'matricle_number': matricleNumber,
        },
      );
      
      if (response.statusCode == 200) {
        return {
          'success': true,
          'message': response.data['message'] ?? 'Matricle number format is valid',
          'is_api_call': true,
        };
      } else {
        return {
          'success': false,
          'error': response.data['error'] ?? 'Matricle validation failed',
          'is_api_call': true,
        };
      }
    } catch (e) {
      developer.log('❌ Matricle validation error: $e', name: 'AUTH_SERVICE');
      
      if (FeatureFlags.USE_MOCK_DATA_FALLBACK) {
        return {
          'success': true,
          'message': 'Matricle validation skipped (fallback mode)',
          'error': e.toString(),
          'is_fallback': true,
        };
      }
      
      return {
        'success': false,
        'error': 'Matricle validation failed: ${e.toString()}',
      };
    }
  }
  
  /// Enhanced user signup with comprehensive validation
  static Future<Map<String, dynamic>> signup({
    required String fullName,
    required String email,
    required String password,
    required UserRole role,
    Map<String, dynamic>? additionalData,
  }) async {
    try {
      developer.log('🚀 Starting signup process...', name: 'AUTH_SERVICE');
      developer.log('📧 Email: $email', name: 'AUTH_SERVICE');
      developer.log('👤 Role: $role', name: 'AUTH_SERVICE');
      developer.log('🔧 API Enabled: ${FeatureFlags.USE_REAL_API}', name: 'AUTH_SERVICE');
      
      if (!FeatureFlags.USE_REAL_API) {
        // Enhanced mock signup logic
        await Future.delayed(const Duration(seconds: 2)); // Simulate network delay
        
        // Mock validation checks
        if (email.isEmpty || !email.contains('@')) {
          return {
            'success': false,
            'message': 'Invalid email format',
            'field': 'email',
            'is_mock': true,
          };
        }
        
        if (password.length < 8) {
          return {
            'success': false,
            'message': 'Password must be at least 8 characters long',
            'field': 'password',
            'is_mock': true,
          };
        }
        
        if (fullName.trim().length < 2) {
          return {
            'success': false,
            'message': 'Full name must be at least 2 characters long',
            'field': 'full_name',
            'is_mock': true,
          };
        }
        
        // Role-specific mock validation
        if (role == UserRole.student && additionalData != null) {
          final matricle = additionalData['matricle_number'] as String?;
          if (matricle == null || !RegExp(r'^[A-Z]{3}/\d{4}/\d{4}$').hasMatch(matricle.toUpperCase())) {
            return {
              'success': false,
              'message': 'Invalid matricle number format. Expected: ABC/YYYY/NNNN',
              'field': 'matricle_number',
              'is_mock': true,
            };
          }
        }
        
        return {
          'success': true,
          'message': 'Account created successfully (mock)',
          'user': {
            'id': 'mock_${DateTime.now().millisecondsSinceEpoch}',
            'email': email,
            'full_name': fullName,
            'role': role.toString().split('.').last,
            'created_at': DateTime.now().toIso8601String(),
          },
          'is_mock': true,
        };
      }
      
      // Prepare signup data
      final signupData = {
        'full_name': fullName.trim(),
        'email': email.trim().toLowerCase(),
        'password': password,
        'user_type': role.toString().split('.').last,
        ...?additionalData,
      };
      
      developer.log('📤 Sending signup request...', name: 'AUTH_SERVICE');
      
      final response = await ApiService.post(
        ApiConfig.registerEndpoint,
        data: signupData,
      );
      
      developer.log('📥 Signup response: ${response.statusCode}', name: 'AUTH_SERVICE');
      
      if (response.statusCode == 201) {
        developer.log('✅ Signup successful', name: 'AUTH_SERVICE');
        return {
          'success': true,
          'message': response.data['message'] ?? 'Account created successfully',
          'user': response.data['user'],
          'is_api_call': true,
        };
      } else if (response.statusCode == 400) {
        developer.log('⚠️ Signup validation error', name: 'AUTH_SERVICE');
        return {
          'success': false,
          'message': response.data['error'] ?? 'Validation failed',
          'field': response.data['field'],
          'is_api_call': true,
        };
      } else {
        developer.log('❌ Signup failed with status: ${response.statusCode}', name: 'AUTH_SERVICE');
        return {
          'success': false,
          'message': response.data['error'] ?? 'Signup failed',
          'is_api_call': true,
        };
      }
    } on DioException catch (e) {
      developer.log('💥 Signup DioException: ${e.message}', name: 'AUTH_SERVICE');
      
      if (e.response?.statusCode == 400) {
        return {
          'success': false,
          'message': e.response?.data['error'] ?? 'Validation failed',
          'field': e.response?.data['field'],
          'is_api_call': true,
        };
      }
      
      if (FeatureFlags.USE_MOCK_DATA_FALLBACK) {
        developer.log('🔄 Falling back to mock signup...', name: 'AUTH_SERVICE');
        
        // Fallback to mock signup
        await Future.delayed(const Duration(seconds: 1));
        
        return {
          'success': true,
          'message': 'Account created successfully (fallback mode)',
          'user': {
            'id': 'fallback_${DateTime.now().millisecondsSinceEpoch}',
            'email': email,
            'full_name': fullName,
            'role': role.toString().split('.').last,
            'created_at': DateTime.now().toIso8601String(),
          },
          'is_fallback': true,
          'original_error': e.message,
        };
      }
      
      return {
        'success': false,
        'message': 'Network error: ${e.message}',
        'error': e.toString(),
      };
    } catch (e) {
      developer.log('💥 Signup unexpected error: $e', name: 'AUTH_SERVICE');
      
      if (FeatureFlags.USE_MOCK_DATA_FALLBACK) {
        return {
          'success': true,
          'message': 'Account created successfully (fallback mode)',
          'user': {
            'id': 'fallback_${DateTime.now().millisecondsSinceEpoch}',
            'email': email,
            'full_name': fullName,
            'role': role.toString().split('.').last,
            'created_at': DateTime.now().toIso8601String(),
          },
          'is_fallback': true,
          'original_error': e.toString(),
        };
      }
      
      return {
        'success': false,
        'message': 'Unexpected error: ${e.toString()}',
        'error': e.toString(),
      };
    }
  }
  
  /// Enhanced user login with proper error handling
  static Future<Map<String, dynamic>> login({
    required String email,
    required String password,
    required UserRole role,
  }) async {
    try {
      developer.log('🔐 Starting login process...', name: 'AUTH_SERVICE');
      developer.log('📧 Email: $email', name: 'AUTH_SERVICE');
      developer.log('👤 Role: $role', name: 'AUTH_SERVICE');
      
      if (!FeatureFlags.USE_REAL_API) {
        // Enhanced mock login logic
        await Future.delayed(const Duration(seconds: 1)); // Simulate network delay
        
        // Mock validation
        if (email.isEmpty || !email.contains('@')) {
          return {
            'success': false,
            'message': 'Invalid email format',
            'is_mock': true,
          };
        }
        
        if (password.length < 8) {
          return {
            'success': false,
            'message': 'Invalid password',
            'is_mock': true,
          };
        }
        
        return {
          'success': true,
          'message': 'Login successful (mock)',
          'user': {
            'id': 'mock_user_${DateTime.now().millisecondsSinceEpoch}',
            'email': email,
            'role': role.toString().split('.').last,
            'last_login': DateTime.now().toIso8601String(),
          },
          'token': 'mock_token_${DateTime.now().millisecondsSinceEpoch}',
          'session_token': 'mock_session_${DateTime.now().millisecondsSinceEpoch}',
          'is_mock': true,
        };
      }
      
      final loginData = {
        'email': email.trim().toLowerCase(),
        'password': password,
        'user_type': role.toString().split('.').last,
      };
      
      final response = await ApiService.post(
        ApiConfig.loginEndpoint,
        data: loginData,
      );
      
      if (response.statusCode == 200) {
        developer.log('✅ Login successful', name: 'AUTH_SERVICE');
        return {
          'success': true,
          'message': response.data['message'] ?? 'Login successful',
          'user': response.data['user'],
          'token': response.data['token'],
          'session_token': response.data['session_token'],
          'is_api_call': true,
        };
      } else if (response.statusCode == 401) {
        developer.log('🚫 Login failed - invalid credentials', name: 'AUTH_SERVICE');
        return {
          'success': false,
          'message': response.data['error'] ?? 'Invalid email or password',
          'is_api_call': true,
        };
      } else {
        developer.log('❌ Login failed with status: ${response.statusCode}', name: 'AUTH_SERVICE');
        return {
          'success': false,
          'message': response.data['error'] ?? 'Login failed',
          'is_api_call': true,
        };
      }
    } on DioException catch (e) {
      developer.log('💥 Login DioException: ${e.message}', name: 'AUTH_SERVICE');
      
      if (e.response?.statusCode == 401) {
        return {
          'success': false,
          'message': 'Invalid email or password',
          'is_api_call': true,
        };
      }
      
      if (FeatureFlags.USE_MOCK_DATA_FALLBACK) {
        developer.log('🔄 Falling back to mock login...', name: 'AUTH_SERVICE');
        
        await Future.delayed(const Duration(seconds: 1));
        
        return {
          'success': true,
          'message': 'Login successful (fallback mode)',
          'user': {
            'id': 'fallback_user_${DateTime.now().millisecondsSinceEpoch}',
            'email': email,
            'role': role.toString().split('.').last,
            'last_login': DateTime.now().toIso8601String(),
          },
          'token': 'fallback_token_${DateTime.now().millisecondsSinceEpoch}',
          'session_token': 'fallback_session_${DateTime.now().millisecondsSinceEpoch}',
          'is_fallback': true,
          'original_error': e.message,
        };
      }
      
      return {
        'success': false,
        'message': 'Network error: ${e.message}',
        'error': e.toString(),
      };
    } catch (e) {
      developer.log('💥 Login unexpected error: $e', name: 'AUTH_SERVICE');
      
      if (FeatureFlags.USE_MOCK_DATA_FALLBACK) {
        return {
          'success': true,
          'message': 'Login successful (fallback mode)',
          'user': {
            'id': 'fallback_user_${DateTime.now().millisecondsSinceEpoch}',
            'email': email,
            'role': role.toString().split('.').last,
            'last_login': DateTime.now().toIso8601String(),
          },
          'token': 'fallback_token_${DateTime.now().millisecondsSinceEpoch}',
          'session_token': 'fallback_session_${DateTime.now().millisecondsSinceEpoch}',
          'is_fallback': true,
          'original_error': e.toString(),
        };
      }
      
      return {
        'success': false,
        'message': 'Unexpected error: ${e.toString()}',
        'error': e.toString(),
      };
    }
  }
  
  /// Verify 2FA code
  static Future<Map<String, dynamic>> verify2FA({
    required String email,
    required String code,
    required UserRole role,
  }) async {
    try {
      developer.log('🔐 Verifying 2FA code...', name: 'AUTH_SERVICE');
      
      if (!FeatureFlags.USE_REAL_API) {
        await Future.delayed(const Duration(seconds: 1));
        
        // Mock 2FA verification
        if (code == '123456' || code == '000000') {
          return {
            'success': true,
            'message': '2FA verification successful (mock)',
            'is_mock': true,
          };
        } else {
          return {
            'success': false,
            'message': 'Invalid 2FA code (mock)',
            'is_mock': true,
          };
        }
      }
      
      final response = await ApiService.post(
        ApiConfig.verify2FAEndpoint,
        data: {
          'email': email.trim().toLowerCase(),
          'code': code,
          'user_type': role.toString().split('.').last,
        },
      );
      
      if (response.statusCode == 200) {
        return {
          'success': true,
          'message': response.data['message'] ?? '2FA verification successful',
          'is_api_call': true,
        };
      } else {
        return {
          'success': false,
          'message': response.data['error'] ?? '2FA verification failed',
          'is_api_call': true,
        };
      }
    } catch (e) {
      developer.log('❌ 2FA verification error: $e', name: 'AUTH_SERVICE');
      
      if (FeatureFlags.USE_MOCK_DATA_FALLBACK) {
        return {
          'success': true,
          'message': '2FA verification successful (fallback)',
          'is_fallback': true,
          'original_error': e.toString(),
        };
      }
      
      return {
        'success': false,
        'message': '2FA verification failed: ${e.toString()}',
        'error': e.toString(),
      };
    }
  }
  
  /// Send 2FA code
  static Future<Map<String, dynamic>> send2FACode({
    required String email,
    required UserRole role,
  }) async {
    try {
      developer.log('📱 Sending 2FA code...', name: 'AUTH_SERVICE');
      
      if (!FeatureFlags.USE_REAL_API) {
        await Future.delayed(const Duration(seconds: 1));
        
        return {
          'success': true,
          'message': '2FA code sent successfully (mock)',
          'code': '123456', // For testing purposes
          'is_mock': true,
        };
      }
      
      final response = await ApiService.post(
        ApiConfig.send2FAEndpoint,
        data: {
          'email': email.trim().toLowerCase(),
          'user_type': role.toString().split('.').last,
        },
      );
      
      if (response.statusCode == 200) {
        return {
          'success': true,
          'message': response.data['message'] ?? '2FA code sent successfully',
          'is_api_call': true,
        };
      } else {
        return {
          'success': false,
          'message': response.data['error'] ?? 'Failed to send 2FA code',
          'is_api_call': true,
        };
      }
    } catch (e) {
      developer.log('❌ Send 2FA code error: $e', name: 'AUTH_SERVICE');
      
      if (FeatureFlags.USE_MOCK_DATA_FALLBACK) {
        return {
          'success': true,
          'message': '2FA code sent successfully (fallback)',
          'code': '123456',
          'is_fallback': true,
          'original_error': e.toString(),
        };
      }
      
      return {
        'success': false,
        'message': 'Failed to send 2FA code: ${e.toString()}',
        'error': e.toString(),
      };
    }
  }
  
  /// Logout user
  static Future<Map<String, dynamic>> logout() async {
    try {
      developer.log('👋 Logging out user...', name: 'AUTH_SERVICE');
      
      if (!FeatureFlags.USE_REAL_API) {
        await Future.delayed(const Duration(milliseconds: 500));
        
        return {
          'success': true,
          'message': 'Logout successful (mock)',
          'is_mock': true,
        };
      }
      
      final response = await ApiService.post(ApiConfig.logoutEndpoint);
      
      if (response.statusCode == 200) {
        return {
          'success': true,
          'message': response.data['message'] ?? 'Logout successful',
          'is_api_call': true,
        };
      } else {
        return {
          'success': false,
          'message': response.data['error'] ?? 'Logout failed',
          'is_api_call': true,
        };
      }
    } catch (e) {
      developer.log('❌ Logout error: $e', name: 'AUTH_SERVICE');
      
      // Logout should always succeed locally even if API fails
      return {
        'success': true,
        'message': 'Logout successful (local)',
        'is_fallback': true,
        'original_error': e.toString(),
      };
    }
  }
  
  /// Logout from all sessions
  static Future<Map<String, dynamic>> logoutAll() async {
    try {
      developer.log('👋 Logging out from all sessions...', name: 'AUTH_SERVICE');
      
      if (!FeatureFlags.USE_REAL_API) {
        await Future.delayed(const Duration(milliseconds: 500));
        
        return {
          'success': true,
          'message': 'Logged out from all sessions (mock)',
          'is_mock': true,
        };
      }
      
      final response = await ApiService.post(ApiConfig.logoutAllEndpoint);
      
      if (response.statusCode == 200) {
        return {
          'success': true,
          'message': response.data['message'] ?? 'Logged out from all sessions successfully',
          'is_api_call': true,
        };
      } else {
        return {
          'success': false,
          'message': response.data['error'] ?? 'Logout from all sessions failed',
          'is_api_call': true,
        };
      }
    } catch (e) {
      developer.log('❌ Logout all sessions error: $e', name: 'AUTH_SERVICE');
      
      // Logout should always succeed locally even if API fails
      return {
        'success': true,
        'message': 'Logged out from all sessions (local)',
        'is_fallback': true,
        'original_error': e.toString(),
      };
    }
  }
}
