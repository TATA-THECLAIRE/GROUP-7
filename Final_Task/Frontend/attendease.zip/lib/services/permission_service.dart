import 'package:flutter/material.dart';
import '../utils/adaptive_screen_manager.dart';
import '../widgets/adaptive_widgets.dart';

class PermissionService {
  static Future<bool> requestCameraPermission(BuildContext context) async {
    return await _showPermissionDialog(
      context,
      'Camera Permission',
      'AttendEase needs camera access for face registration. This helps verify your identity during attendance.',
      Icons.camera_alt,
    );
  }

  static Future<bool> requestLocationPermission(BuildContext context) async {
    return await _showPermissionDialog(
      context,
      'Location Permission',
      'AttendEase needs location access to verify you are in the classroom when marking attendance.',
      Icons.location_on,
    );
  }

  static Future<bool> _showPermissionDialog(
    BuildContext context,
    String title,
    String message,
    IconData icon,
  ) async {
    final adaptive = context.adaptive;
    
    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: adaptive.adaptiveBorderRadius(15),
          ),
          child: AdaptiveContainer(
            width: adaptive.profile.width * 0.9,
            padding: adaptive.adaptivePadding(all: 20),
            child: AdaptiveColumn(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              spacing: 15,
              scrollable: true,
              children: [
                // Title row with icon
                AdaptiveRow(
                  spacing: 10,
                  children: [
                    Icon(
                      icon, 
                      color: const Color(0xFF5D3BE3),
                      size: adaptive.adaptiveIcon(24),
                    ),
                    Expanded(
                      child: AdaptiveText(
                        title,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        maxLines: 2,
                      ),
                    ),
                  ],
                ),
                // Message text
                AdaptiveText(
                  message,
                  fontSize: 16,
                  maxLines: 4,
                ),
                // Demo notice
                AdaptiveContainer(
                  padding: adaptive.adaptivePadding(all: 15),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF0EBFF),
                    borderRadius: adaptive.adaptiveBorderRadius(10),
                    border: Border.all(color: const Color(0xFF5D3BE3)),
                  ),
                  child: const AdaptiveText(
                    'This is a demo app. In a real app, this would request actual device permissions.',
                    fontSize: 12,
                    textAlign: TextAlign.center,
                    color: Color(0xFF666666),
                    maxLines: 3,
                  ),
                ),
                // Action buttons
                AdaptiveRow(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  spacing: 15,
                  children: [
                    Expanded(
                      child: AdaptiveButton(
                        text: 'Deny',
                        isSecondary: true,
                        backgroundColor: Colors.red,
                        fontSize: 14,
                        height: 44,
                        onPressed: () => Navigator.of(context).pop(false),
                      ),
                    ),
                    Expanded(
                      child: AdaptiveButton(
                        text: 'Allow',
                        backgroundColor: const Color(0xFF5D3BE3),
                        fontSize: 14,
                        height: 44,
                        onPressed: () => Navigator.of(context).pop(true),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
    
    return result ?? false;
  }
}
