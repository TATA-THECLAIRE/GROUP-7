import 'package:dio/dio.dart';
import 'dart:developer' as developer;
import '../../config/api_config.dart';
import '../../config/feature_flags.dart';

/// Central API service for all HTTP requests
/// This service handles:
/// - HTTP client configuration
/// - Request/Response logging
/// - Error handling
/// - Connection testing
/// - Health checks
class ApiService {
  static final Dio _dio = Dio();
  static bool _initialized = false;
  
  /// Initialize the API service with configuration
  static void initialize() {
    if (_initialized) return;
    
    _dio.options.baseUrl = ApiConfig.BASE_URL;
    _dio.options.connectTimeout = ApiConfig.connectTimeout;
    _dio.options.receiveTimeout = ApiConfig.receiveTimeout;
    _dio.options.sendTimeout = ApiConfig.sendTimeout;
    
    // Add default headers
    _dio.options.headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
    
    if (FeatureFlags.ENABLE_API_LOGGING) {
      _dio.interceptors.add(LogInterceptor(
        requestBody: true,
        responseBody: true,
        requestHeader: true,
        responseHeader: true,
        error: true,
        logPrint: (obj) => developer.log(obj.toString(), name: 'API_SERVICE'),
      ));
    }
    
    _initialized = true;
    developer.log('API Service initialized with base URL: ${ApiConfig.BASE_URL}', name: 'API_SERVICE');
  }
  
  /// Get configured Dio instance
  static Dio get dio {
    if (!_initialized) initialize();
    return _dio;
  }
  
  /// Test endpoint to verify API connectivity
  static Future<Map<String, dynamic>> testConnection() async {
    try {
      if (!FeatureFlags.USE_REAL_API) {
        return {
          'status': 'success',
          'message': 'Mock API connection',
          'timestamp': DateTime.now().toIso8601String(),
          'is_mock': true,
        };
      }
      
      final response = await dio.get(ApiConfig.healthEndpoint);
      
      return {
        'status': 'success',
        'message': 'Real API connection successful',
        'data': response.data,
        'timestamp': DateTime.now().toIso8601String(),
        'is_api_call': true,
      };
    } on DioException catch (e) {
      developer.log('API Connection Error: ${e.message}', name: 'API_ERROR');
      
      if (FeatureFlags.USE_MOCK_DATA_FALLBACK) {
        return {
          'status': 'fallback',
          'message': 'Using mock data due to API error',
          'error': e.message,
          'timestamp': DateTime.now().toIso8601String(),
          'is_fallback': true,
        };
      }
      
      rethrow;
    } catch (e) {
      developer.log('Unexpected API Error: $e', name: 'API_ERROR');
      rethrow;
    }
  }
  
  /// Health check endpoint
  static Future<Map<String, dynamic>> healthCheck() async {
    try {
      if (!FeatureFlags.USE_REAL_API) {
        return {
          'status': 'healthy',
          'message': 'Mock health check',
          'services': {
            'database': 'healthy',
            'api': 'healthy',
          },
          'is_mock': true,
        };
      }
      
      final response = await dio.get(ApiConfig.healthEndpoint);
      return {
        ...response.data,
        'is_api_call': true,
      };
    } catch (e) {
      if (FeatureFlags.USE_MOCK_DATA_FALLBACK) {
        return {
          'status': 'degraded',
          'message': 'Fallback health check',
          'error': e.toString(),
          'is_fallback': true,
        };
      }
      rethrow;
    }
  }
  
  /// Generic GET request
  static Future<Response> get(String endpoint, {Map<String, dynamic>? queryParameters}) async {
    return await dio.get(endpoint, queryParameters: queryParameters);
  }
  
  /// Generic POST request
  static Future<Response> post(String endpoint, {dynamic data}) async {
    return await dio.post(endpoint, data: data);
  }
  
  /// Generic PUT request
  static Future<Response> put(String endpoint, {dynamic data}) async {
    return await dio.put(endpoint, data: data);
  }
  
  /// Generic DELETE request
  static Future<Response> delete(String endpoint) async {
    return await dio.delete(endpoint);
  }
  
  /// Get all available endpoints for debugging
  static Map<String, String> getEndpoints() {
    return ApiConfig.getAllEndpoints();
  }
}
