import 'package:flutter/material.dart';

class SimulatedPermissionService {
  static Future<bool> requestLocationPermission(BuildContext context) async {
    return await _showPermissionDialog(
      context,
      'Location Permission',
      'AttendEase needs access to your location to verify you are in the classroom when marking attendance.',
      '📍',
    );
  }

  static Future<bool> requestCameraPermission(BuildContext context) async {
    return await _showPermissionDialog(
      context,
      'Camera Permission',
      'AttendEase needs access to your camera for facial recognition during attendance verification.',
      '📷',
    );
  }

  static Future<bool> _showPermissionDialog(
    BuildContext context,
    String title,
    String message,
    String emoji,
  ) async {
    return await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          title: Row(
            children: [
              Text(emoji, style: const TextStyle(fontSize: 24)),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                message,
                style: const TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.blue.withAlpha(26), // 0.1 * 255 = ~26
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  'This is a simulated permission request for demonstration purposes.',
                  style: TextStyle(
                    fontSize: 12,
                    fontStyle: FontStyle.italic,
                    color: Colors.blue,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text(
                'Deny',
                style: TextStyle(color: Colors.red),
              ),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(context).pop(true),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF5D3BE3),
                foregroundColor: Colors.white,
              ),
              child: const Text('Allow'),
            ),
          ],
        );
      },
    ) ?? false;
  }
}
